"""PRIZE SHOOTER (Dutch: "Altijd Prijs!") - pygame edition for Batocera (Raspberry Pi 5 & PC).

Sinden gun = absolute mouse: trigger = left click, pump / right button (and side buttons) = reload,
middle button = pause. Shooting into the white border / off-screen also reloads.
"""
import math
import os
import random
import sys
import time

import pygame

from . import settings as S
from . import lg
from . import gfx as G
from . import audio as A
from . import game as Game
from .lang import T

W, H = 1280, 720
screen = None      # the real display surface (logical size, scaled to the monitor by SDL)
canvas = None      # 1280x720 game area inside the Sinden border
_border = 0
_pad = (0, 0)
_mode_key = None


def setup_display():
    """(Re)create the window. The game keeps its 1280x720 layout; when a Sinden border is on,
    the logical screen is made a little bigger (same 16:9 shape) so the white frame sits
    around the game instead of covering it. SDL does the scaling on the GPU."""
    global screen, canvas, _border, _pad, _mode_key
    b = int(S.BORDER_PCT.get(S.border, 0) * H + 0.5)
    gap = max(2, int(0.006 * H)) if b > 0 else 0
    py = b + gap
    px = int(round(py * W / H))
    key = (px, py, S.fullscreen)
    if key != _mode_key:
        flags = pygame.SCALED | (pygame.FULLSCREEN if S.fullscreen == 1 else 0)
        size = (W + 2 * px, H + 2 * py)
        try:
            screen = pygame.display.set_mode(size, flags, vsync=1)
        except pygame.error:
            screen = pygame.display.set_mode(size, flags)
        _mode_key = key
        pygame.mouse.set_visible(False)
    _border, _pad = b, (px, py)
    canvas = screen.subsurface((px, py, W, H)) if (px or py) else screen
    lg.set_target(canvas)


def apply_settings():
    global _border
    G.evening = (S.theme == "evening")
    G.kids = (S.kids == 1)
    G.hitR = 1.4 if G.kids else 1.0
    G.symbols = (S.symbols == 1)
    G.cache_tag = (S.lang, S.theme)
    pygame.display.set_caption(T("window_title"))
    A.set_volumes(S.music if S.musicOn == 1 else 0, S.sfx)
    setup_display()


Game.apply_settings = apply_settings


def to_game(pos):
    return pos[0] - _pad[0], pos[1] - _pad[1]


def is_offscreen(x, y):
    """x, y in game coordinates: True when the gun points into the white border or off the screen."""
    sx, sy = x + _pad[0], y + _pad[1]
    lw, lh = W + 2 * _pad[0], H + 2 * _pad[1]
    edge = max(_border, 3)
    if sx <= edge or sy <= edge or sx >= lw - 1 - edge or sy >= lh - 1 - edge:
        return True
    return x < 0 or y < 0 or x > W or y > H


def fire(x, y, physical):
    off = is_offscreen(x, y) if physical else False
    st = Game.state
    # the play state decides itself whether a pellet actually leaves the gun (empty / reloading = just a click)
    if not getattr(st, "ownsShotFX", False):
        Game.flash = 0.08
        if not off:
            G.FX.shot(x, y)
    if st is not None and hasattr(st, "shoot"):
        st.shoot(x, y, off)


def reload():
    st = Game.state
    if st is not None and hasattr(st, "reload"):
        st.reload()


def back():
    st = Game.state
    if st is not None and hasattr(st, "back"):
        st.back()


def draw_border():
    """Solid white Sinden frame on the very edge of the screen (black gap between it and the game)."""
    b = _border
    if b <= 0:
        return
    lw, lh = screen.get_size()
    white = (255, 255, 255)
    screen.fill(white, (0, 0, lw, b))
    screen.fill(white, (0, lh - b, lw, b))
    screen.fill(white, (0, 0, b, lh))
    screen.fill(white, (lw - b, 0, b, lh))


def take_photos():
    if not Game.photo_requests:
        return
    reqs, Game.photo_requests[:] = list(Game.photo_requests), []
    snap = canvas.copy()
    stamp = time.strftime("%Y%m%d_%H%M%S")
    ext = ".png" if pygame.image.get_extended() else ".bmp"
    try:
        pygame.image.save(snap, os.path.join(S.SAVE_DIR, "photo_%s%s" % (stamp, ext)))
    except Exception:
        try:
            pygame.image.save(snap, os.path.join(S.SAVE_DIR, "photo_%s.bmp" % stamp))
        except Exception:
            pass
    small = pygame.transform.smoothscale(snap, (320, 180))
    for cb in reqs:
        cb(small)


def main():
    global screen
    os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
    pygame.mixer.pre_init(22050, -16, 2, 512)
    pygame.init()
    S.load()
    if S.difficulty != "custom":
        S.setDifficulty(S.difficulty)
    setup_display()
    G.loadFonts()
    screen.fill((26, 5, 10))
    G.text(T("loading"), W / 2, H / 2 - 20, G.F["ui34"], G.C["cream"], 900, 2)
    pygame.display.flip()
    A.init()
    pygame.joystick.init()
    joys = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
    for j in joys:
        j.init()

    from .states.menu import Menu
    from .states.settings_screen import SettingsScreen
    from .states.play import Play
    from .states.results import Results
    from .states.shelf import Shelf
    from .states.counter import Counter
    from .states.room import Room
    from .states.album import Album
    Game.states.update({"menu": Menu(), "settings": SettingsScreen(), "play": Play(), "results": Results(),
                        "shelf": Shelf(), "counter": Counter(), "room": Room(), "album": Album()})
    apply_settings()
    Game.switch("menu")

    clock = pygame.time.Clock()
    trig_down = {}
    running = True
    while running:
        dt = min(clock.tick(60) / 1000.0, 1 / 20)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif ev.type == pygame.MOUSEMOTION:
                Game.padActive = False
                Game.aim[0], Game.aim[1] = to_game(ev.pos)
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                Game.idle = 0
                Game.padActive = False
                gx, gy = to_game(ev.pos)
                Game.aim[0], Game.aim[1] = gx, gy
                if ev.button == 1:
                    fire(gx, gy, True)
                elif ev.button in (2,):
                    back()
                elif ev.button in (3, 6, 7, 8, 9):   # right / side buttons = pump action
                    reload()
            elif ev.type == pygame.KEYDOWN:
                Game.idle = 0
                k = ev.key
                if k in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_p):
                    back()
                elif k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_z, pygame.K_LCTRL):
                    fire(Game.aim[0], Game.aim[1], False)
                elif k in (pygame.K_r, pygame.K_x, pygame.K_LALT):
                    reload()
                elif k == pygame.K_F11:
                    S.fullscreen = 0 if S.fullscreen == 1 else 1
                    S.save()
                    apply_settings()
            elif ev.type == pygame.JOYBUTTONDOWN:
                Game.idle = 0
                if ev.button in (0, 5):
                    fire(Game.aim[0], Game.aim[1], False)
                elif ev.button in (1, 2, 4):
                    reload()
                elif ev.button in (6, 7):
                    back()
            elif ev.type == pygame.JOYAXISMOTION and ev.axis in (5,):
                jid = ev.instance_id if hasattr(ev, "instance_id") else ev.joy
                if ev.value > 0.6 and not trig_down.get(jid):
                    trig_down[jid] = True
                    fire(Game.aim[0], Game.aim[1], False)
                elif ev.value < 0.3:
                    trig_down[jid] = False
            elif ev.type == pygame.JOYDEVICEADDED:
                try:
                    j = pygame.joystick.Joystick(ev.device_index)
                    j.init()
                    joys.append(j)
                except pygame.error:
                    pass
        if Game.state is None:
            break

        G.T += dt
        Game.flash = max(0.0, Game.flash - dt)
        # gamepad / keyboard aiming fallback
        dx = dy = 0.0
        for j in joys:
            try:
                if j.get_numaxes() >= 2:
                    ax, ay = j.get_axis(0), j.get_axis(1)
                    if abs(ax) > 0.2:
                        dx += ax
                    if abs(ay) > 0.2:
                        dy += ay
                if j.get_numhats() > 0:
                    hx, hy = j.get_hat(0)
                    dx += hx
                    dy -= hy
            except pygame.error:
                pass
        keys = pygame.key.get_pressed()
        dx += (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT])
        dy += (keys[pygame.K_DOWN] - keys[pygame.K_UP])
        if dx or dy:
            Game.padActive = True
            Game.aim[0] = max(0, min(W, Game.aim[0] + dx * 900 * dt))
            Game.aim[1] = max(0, min(H, Game.aim[1] + dy * 900 * dt))

        G.FX.update(dt)
        Game.idle += dt
        if Game.state is Game.states["menu"] and Game.idle > 60:
            Game.idle = 0
            Game.startDemo()
        Game.state.update(dt)
        if Game.state is None:
            break

        # draw
        lg.set_target(canvas)
        if G.FX.shake > 0:
            canvas.fill((0, 0, 0))
        if _pad != (0, 0):   # black gap between the game and the white border
            screen.fill((0, 0, 0), (0, 0, screen.get_width(), _pad[1]))
            screen.fill((0, 0, 0), (0, H + _pad[1], screen.get_width(), _pad[1]))
            screen.fill((0, 0, 0), (0, 0, _pad[0], screen.get_height()))
            screen.fill((0, 0, 0), (W + _pad[0], 0, _pad[0], screen.get_height()))
        lg.origin()
        sh = G.FX.shake
        if sh > 0:
            lg.translate((random.random() - 0.5) * sh, (random.random() - 0.5) * sh)
        Game.state.draw()
        G.FX.draw()
        G.FX.drawShots()
        # the reticle follows the setting while shooting a stand; on every menu screen it is always shown
        play = Game.states.get("play")
        in_menu = Game.state is not play or play.paused or play.phase == "ready"
        if S.crosshair > 0 or Game.padActive or in_menu:
            G.crosshair(Game.aim[0], Game.aim[1], max(1, S.crosshair), Game.flash > 0)
        lg.origin()
        take_photos()
        draw_border()
        pygame.display.flip()
        if getattr(Game, "quit_requested", False):
            running = False
    S.save()
    pygame.quit()


if __name__ == "__main__":
    main()
