"""English / Dutch text. T("key", *args) formats with %-style arguments."""
import json
import os
from . import settings as S

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "lang.json"), encoding="utf-8") as _f:
    L = json.load(_f)


def T(key, *args):
    t = L.get(S.lang) or L["en"]
    s = t.get(key) or L["en"].get(key) or key
    if args:
        try:
            return s % args
        except (TypeError, ValueError):
            return s
    return s
