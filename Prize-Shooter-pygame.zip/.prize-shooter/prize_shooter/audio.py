"""Sound effects and music: pre-rendered WAVs (synthesized by the original LÖVE build)."""
import os
import pygame

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "sounds")
sfxVol, musicVol = 0.9, 0.7
pools = {}
tracks = {}
current = None
ok = False


def init():
    global ok
    try:
        pygame.mixer.pre_init(22050, -16, 2, 512)
        pygame.mixer.init()
        pygame.mixer.set_num_channels(24)
        pygame.mixer.set_reserved(1)  # channel 0 = music
        ok = True
    except pygame.error:
        ok = False
        return
    for fn in os.listdir(HERE):
        if not fn.endswith(".wav"):
            continue
        name = fn[:-4]
        try:
            snd = pygame.mixer.Sound(os.path.join(HERE, fn))
        except pygame.error:
            continue
        if name.startswith("music_"):
            tracks[name[6:]] = snd
        else:
            pools[name] = snd


def play(name, vol=1.0, pitch=1.0):
    # pygame can't repitch on the fly; volume carries the variation
    if not ok:
        return
    s = pools.get(name)
    if not s:
        return
    ch = pygame.mixer.find_channel(True)
    if ch:
        ch.set_volume(min(1.0, (vol if vol is not None else 1.0) * sfxVol))
        ch.play(s)


_music_ch = None


def music(name):
    global current, _music_ch
    if not ok or current == name:
        return
    if _music_ch:
        _music_ch.stop()
    current = name
    t = tracks.get(name) if name else None
    if t:
        _music_ch = pygame.mixer.Channel(0)
        _music_ch.set_volume(musicVol * 0.55)
        _music_ch.play(t, loops=0 if name == "fanfare" else -1)


def set_volumes(music10, sfx10):
    global musicVol, sfxVol
    musicVol = music10 / 10.0
    sfxVol = sfx10 / 10.0
    if _music_ch:
        _music_ch.set_volume(musicVol * 0.55)


def play_fanfare():
    global current
    music(None)
    current = None
    t = tracks.get("fanfare")
    if ok and t:
        ch = pygame.mixer.Channel(0)
        ch.set_volume(musicVol * 0.7)
        ch.play(t)
