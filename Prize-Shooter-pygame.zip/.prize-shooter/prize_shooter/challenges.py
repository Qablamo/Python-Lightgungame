"""Five challenges per stand; each wins a toy (tier 1 squishy ... tier 5 Grand Prize)."""
from . import settings as S

MODES = ["stars", "shark", "ducks", "rails", "cans", "hearts", "pyramid", "balloons"]


def _m(r, k, default=0):
    return (r.get("m") or {}).get(k, default)


LIST = {
    "stars": [
        lambda r: r["score"] >= 1500,
        lambda r: _m(r, "called") >= 10,
        lambda r: r["bestCombo"] >= 12,
        lambda r: r["score"] >= 8000,
        lambda r: r["shots"] >= 40 and r["misses"] == 0 and r.get("penalties", 0) == 0,
    ],
    "shark": [
        lambda r: _m(r, "teeth") >= 10,
        lambda r: _m(r, "dazed") >= 3,
        lambda r: _m(r, "sharks") >= 2,
        lambda r: _m(r, "gold") >= 5,
        lambda r: _m(r, "sharks") >= 3 and r["misses"] == 0 and r.get("penalties", 0) == 0,
    ],
    "ducks": [
        lambda r: _m(r, "ducks") >= 15,
        lambda r: _m(r, "gold") >= 2,
        lambda r: _m(r, "flyers") >= 1,
        lambda r: r["score"] >= 9000 and _m(r, "bombs") == 0,
        lambda r: _m(r, "ducks") >= 30 and r["misses"] == 0 and _m(r, "bombs") == 0,
    ],
    "rails": [
        lambda r: _m(r, "bulls") >= 5,
        lambda r: _m(r, "pops") >= 4,
        lambda r: _m(r, "bulls") >= 12,
        lambda r: r["bestCombo"] >= 20,
        lambda r: _m(r, "bulls") >= 20 and r["misses"] == 0 and r.get("penalties", 0) == 0,
    ],
    "cans": [
        lambda r: _m(r, "stacks") >= 1,
        lambda r: _m(r, "photos") >= 1,
        lambda r: _m(r, "bestStack", 999) <= 4,
        lambda r: _m(r, "stacks") >= 5,
        lambda r: _m(r, "stacks") >= 5 and r["misses"] == 0,
    ],
    "hearts": [
        lambda r: _m(r, "hearts") >= 15,
        lambda r: _m(r, "centers") >= 3,
        lambda r: _m(r, "big") >= 2,
        lambda r: r["score"] >= 8000,
        lambda r: _m(r, "hearts") >= 30 and r["misses"] == 0,
    ],
    "pyramid": [
        lambda r: _m(r, "blocks") >= 10,
        lambda r: _m(r, "pyramids") >= 1,
        lambda r: _m(r, "pyramids") >= 3,
        lambda r: _m(r, "perfect") >= 1,
        lambda r: _m(r, "pyramids") >= 4 and r["misses"] == 0 and _m(r, "early") == 0,
    ],
    "balloons": [
        lambda r: _m(r, "popped") >= 20,
        lambda r: _m(r, "tickets") >= 2,
        lambda r: _m(r, "floaters") >= 3,
        lambda r: r["bestCombo"] >= 15,
        lambda r: _m(r, "popped") >= 40 and r["misses"] == 0 and r.get("penalties", 0) == 0,
    ],
}


def has(id_):
    return id_ in S.collect


def count(mode=None):
    if mode is None:
        return sum(1 for m in MODES for i in range(1, 6) if has("%s%d" % (m, i)))
    return sum(1 for i in range(1, 6) if has("%s%d" % (mode, i)))


def evaluate(mode, r):
    new = []
    lst = LIST.get(mode)
    if not lst:
        return new
    kids = r.get("kids")
    if kids:
        m2 = {k: (v if k == "bestStack" else v * 2) for k, v in (r.get("m") or {}).items()}
        r = {"score": r["score"] * 2, "hits": r["hits"], "shots": r["shots"], "misses": r["misses"],
             "bestCombo": r["bestCombo"] * 2, "penalties": r.get("penalties", 0), "m": m2}
    for i in range(5, 0, -1):
        id_ = "%s%d" % (mode, i)
        res = False
        if not kids or i <= 2:
            try:
                res = lst[i - 1](r)
            except Exception:
                res = False
        if res and not has(id_):
            S.collect.add(id_)
            new.append(id_)
    if new:
        S.save()
    return new
