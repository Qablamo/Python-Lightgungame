"""Persistent settings, best scores, tickets and the toy collection."""
import os

def _save_dir():
    for d in ("/userdata/saves/pygame/prize_shooter",
              os.path.join(os.path.expanduser("~"), ".local", "share", "prize_shooter"),
              os.path.join(os.path.dirname(os.path.abspath(__file__)), "save")):
        try:
            os.makedirs(d, exist_ok=True)
            test = os.path.join(d, ".w")
            with open(test, "w") as f:
                f.write("1")
            os.remove(test)
            return d
        except OSError:
            continue
    return "."

SAVE_DIR = _save_dir()
FILE = os.path.join(SAVE_DIR, "settings.txt")

border = 2        # 0 off, 1 thin, 2 medium, 3 thick (Sinden white border)
crosshair = 1     # 0 hidden, 1 small, 2 large
reload = "auto"   # "auto", "manual" or "pump"
music = 7         # 0..10
musicOn = 1
sfx = 9
fullscreen = 1
lang = "en"
theme = "evening"
kids = 0
players = 1
symbols = 1
tickets = 0
difficulty = "medium"   # "easy", "medium", "hard" or "custom" (presets for kids / reload / reticle)
cust_kids, cust_reload, cust_crosshair = 0, "auto", 1   # the CUSTOM choices, kept while a preset is active
collect = set()
best = {}               # best scores per difficulty: best["hard_stars"], best["easy_tour"], ...
DIFFICULTIES = ["easy", "medium", "hard", "custom"]

BORDER_PCT = {0: 0, 1: 0.015, 2: 0.025, 3: 0.04}
_NUM = ("border", "crosshair", "music", "musicOn", "sfx", "fullscreen", "kids", "players", "symbols", "tickets",
        "cust_kids", "cust_crosshair")


def load():
    g = globals()
    if not os.path.exists(FILE):
        return
    had_difficulty = False
    try:
        with open(FILE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k.startswith("best_"):
                    key = k[5:]
                    if "_" not in key:   # scores from before the levels existed count as CUSTOM
                        key = "custom_" + key
                    try:
                        best[key] = int(float(v))
                    except ValueError:
                        pass
                elif k in ("reload", "cust_reload"):
                    g[k] = v if v in ("manual", "pump") else "auto"
                elif k == "difficulty":
                    g["difficulty"] = v if v in DIFFICULTIES else "medium"
                    had_difficulty = True
                elif k == "collect":
                    collect.update(x for x in v.split(",") if x)
                elif k == "lang":
                    g["lang"] = "nl" if v == "nl" else "en"
                elif k == "theme":
                    g["theme"] = "day" if v == "day" else "evening"
                elif k in _NUM:
                    try:
                        g[k] = int(float(v))
                    except ValueError:
                        pass
    except OSError:
        pass
    if not had_difficulty:   # an older save: keep the player's own setup as CUSTOM
        g["difficulty"] = "custom"


def bestKey(mode):
    return difficulty + "_" + mode


def getBest(mode):
    return best.get(bestKey(mode), 0)


def setDifficulty(d):
    """EASY = Kids mode, MEDIUM = reload yourself + reticle + bombs,
    HARD = no reticle + pump after every shot + bombs, CUSTOM = your own settings."""
    global difficulty, kids, reload, crosshair, cust_kids, cust_reload, cust_crosshair
    if difficulty == "custom":
        cust_kids, cust_reload, cust_crosshair = kids, reload, crosshair
    difficulty = d
    ret = cust_crosshair if cust_crosshair > 0 else 1
    if d == "easy":
        kids, reload, crosshair = 1, "auto", ret
    elif d == "medium":
        kids, reload, crosshair = 0, "manual", ret
    elif d == "hard":
        kids, reload, crosshair = 0, "pump", 0
    else:
        kids, reload, crosshair = cust_kids, cust_reload, cust_crosshair


def nextDifficulty():
    if difficulty in DIFFICULTIES:
        return DIFFICULTIES[(DIFFICULTIES.index(difficulty) + 1) % len(DIFFICULTIES)]
    return "medium"


def toCustom():
    """Changing kids / reload / reticle by hand turns the level into CUSTOM."""
    global difficulty
    difficulty = "custom"


def save():
    g = globals()
    out = ["%s=%s" % (k, g[k]) for k in ("border", "crosshair", "reload", "music", "sfx", "fullscreen", "theme", "lang",
                                           "kids", "players", "symbols", "tickets", "musicOn",
                                           "difficulty", "cust_kids", "cust_reload", "cust_crosshair")]
    out.append("collect=" + ",".join(sorted(collect)))
    for m, v in best.items():
        out.append("best_%s=%d" % (m, v))
    try:
        with open(FILE, "w", encoding="utf-8") as f:
            f.write("\n".join(out) + "\n")
    except OSError:
        pass
