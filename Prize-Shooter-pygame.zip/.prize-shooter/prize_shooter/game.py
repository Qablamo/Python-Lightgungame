"""Shared game state: current screen, aim, tour / duel / demo bookkeeping."""
import random
from . import settings as S

states = {}
state = None
aim = [640.0, 360.0]
flash = 0.0
padActive = False
tour = None
duel = None
demo = None
idle = 0.0
quit_requested = False
apply_settings = None    # set by main
photo_requests = []      # callbacks waiting for a screenshot of the next frame

TOUR = ["stars", "shark", "ducks", "rails", "cans", "hearts", "pyramid", "balloons"]


def switch(name, *args):
    global state
    s = states[name]
    if state is not None and hasattr(state, "leave"):
        state.leave()
    state = s
    if hasattr(s, "enter"):
        s.enter(*args)


def playStand(id_):
    global tour, duel
    tour = None
    duel = {"mode": id_, "round": 1, "res": {}} if S.players == 2 else None
    switch("play", id_)


def startDemo():
    global tour, duel, demo
    tour, duel = None, None
    demo = {"idx": random.randrange(len(TOUR))}
    switch("play", TOUR[demo["idx"]])


def nextDemo():
    if not demo:
        return switch("menu")
    demo["idx"] = (demo["idx"] + 1) % len(TOUR)
    switch("play", TOUR[demo["idx"]])


def startTour():
    global tour, duel
    duel = None
    tour = {"list": TOUR, "idx": 1, "total": 0}
    switch("play", TOUR[0])


def request_photo(cb):
    photo_requests.append(cb)
