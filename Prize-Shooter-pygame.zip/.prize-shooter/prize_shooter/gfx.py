"""Drawing helpers, the fairground booth and shared particle effects (port of gfx.lua)."""
import math
import os
import random
import pygame
from . import lg

sin, cos, pi, floor = math.sin, math.cos, math.pi, math.floor

W, H = 1280, 720
INNER = {"x": 80, "y": 150, "w": 1120, "h": 480}
T = 0.0
hitR = 1.0
kids = False
symbols = True
evening = True

C = {
    "red": (0.86, 0.12, 0.14), "darkred": (0.5, 0.05, 0.07),
    "yellow": (1.0, 0.82, 0.12), "gold": (1.0, 0.75, 0.15),
    "blue": (0.15, 0.45, 0.95), "green": (0.2, 0.78, 0.3),
    "pink": (1.0, 0.4, 0.72), "orange": (1.0, 0.55, 0.1),
    "teal": (0.13, 0.55, 0.55), "white": (1, 1, 1), "black": (0, 0, 0),
    "cream": (1.0, 0.95, 0.82), "wood": (0.55, 0.36, 0.2), "tan": (0.78, 0.66, 0.46),
    "purple": (0.6, 0.3, 0.85), "sky": (0.45, 0.8, 1.0),
}

HERE = os.path.dirname(os.path.abspath(__file__))
F = {}
FAM = {}
SIZES = [96, 80, 64, 56, 46, 40, 34, 30, 26, 22, 20, 18, 16, 14, 12]


def loadFonts():
    sign = os.path.join(HERE, "assets", "fonts", "DejaVuSerifCondensed-Bold.ttf")
    ui = os.path.join(HERE, "assets", "fonts", "Poppins-Bold.ttf")
    for s in SIZES:
        F["ui%d" % s] = lg.Font(ui, s)
        F["sign%d" % s] = lg.Font(sign, s)
        FAM[id(F["ui%d" % s])] = ("ui", s)
        FAM[id(F["sign%d" % s])] = ("sign", s)


def fit(s, font, maxw):
    if font.getWidth(s) <= maxw:
        return font
    fam = FAM.get(id(font))
    if not fam:
        return font
    for sz in SIZES:
        if sz < fam[1]:
            f = F["%s%d" % (fam[0], sz)]
            if f.getWidth(s) <= maxw:
                return f
    return F["%s%d" % (fam[0], SIZES[-1])]


def col(c, a=None):
    lg.set_color(c[0], c[1], c[2], (c[3] if len(c) > 3 else 1) if a is None else a)


def shade(c, f, a=1):
    lg.set_color(c[0] * f, c[1] * f, c[2] * f, a)


def _rgb(c):
    return (lg._c255(c[0]), lg._c255(c[1]), lg._c255(c[2]))


def text(s, x, y, font, color, w=None, outline=None, olc=None):
    if s is None or s == "":
        return
    s = str(s)
    if w:
        f = fit(s, font, w - 6)
        if f is not font:
            y = y + (font.getHeight() - f.getHeight()) / 2
            font = f
    if outline is None:
        outline = 2
    o = olc or (0.1, 0.03, 0.05)
    surf = lg.text_surface(s, font, _rgb(color), outline, _rgb(o))
    tw = surf.get_width() - outline * 2
    left = (x - tw / 2) if w else x
    a = color[3] if len(color) > 3 else 1
    lg.set_color(1, 1, 1, a)
    lg.draw_surface(surf, left - outline, y - outline)


def starPoly(x, y, r, points=5, inner=0.45, rot=-pi / 2):
    v = []
    for i in range(points * 2):
        rr = r if i % 2 == 0 else r * inner
        a = rot + i * pi / points
        v.append((x + cos(a) * rr, y + sin(a) * rr))
    return v


def _star(x, y, r, color, rot=-pi / 2, points=5, inner=0.45):
    v = starPoly(x, y, r, points, inner, rot)
    shade(color, 0.55)
    lg.polygon("fill", [(px + 2, py + 3) for px, py in v])
    col(color)
    lg.polygon("fill", v)
    shade(color, 0.6)
    lg.set_line_width(2)
    lg.polygon("line", v)
    lg.set_color(1, 1, 1, 0.45)
    lg.circle("fill", x - r * 0.15, y - r * 0.2, r * 0.18)


def star(x, y, r, color, rot=-pi / 2, points=5, inner=0.45):
    if rot is None:
        rot = -pi / 2
    if r <= 0.5:
        return
    rq = round(r * 2) / 2
    sym = 2 * pi / points
    steps = 24
    rotq = round(((rot % sym) / sym) * steps) % steps * sym / steps
    key = ("star", rq, tuple(color[:3]), rotq, points, inner)
    sprite(key, lambda: _star(0, 0, rq, color, rotq, points, inner), rq + 5, rq + 5, x, y)


def heartShape(x, y, r, mode="fill"):
    lg.circle(mode, x - r * 0.5, y - r * 0.22, r * 0.56)
    lg.circle(mode, x + r * 0.5, y - r * 0.22, r * 0.56)
    lg.polygon(mode, x - r * 1.03, y - r * 0.05, x + r * 1.03, y - r * 0.05, x, y + r * 1.0)


def _heart(r, color, rot, sx):
    lg.push(); lg.rotate(rot); lg.scale(sx, 1)
    shade(color, 0.55); heartShape(2, 3, r)
    col(color); heartShape(0, 0, r)
    lg.set_color(1, 1, 1, 0.5); lg.ellipse("fill", -r * 0.45, -r * 0.35, r * 0.2, r * 0.13)
    lg.pop()


def heart(x, y, r, color, rot=0, sx=1):
    if r <= 0.5:
        return
    rq = round(r * 2) / 2
    rotq = round((rot or 0) / 0.02) * 0.02
    sx = sx or 1
    key = ("heart", rq, tuple(color[:3]), rotq, sx)
    sprite(key, lambda: _heart(rq, color, rotq, sx), rq * 1.5 + 6, rq * 1.5 + 6, x, y)


def colorSymbol(idx, x, y, r):
    if not symbols or not idx or idx < 1:
        return
    sprite(("sym", idx, r), lambda: _colorSymbol(idx, 0, 0, r), r * 1.4 + 4, r * 1.4 + 4, x, y)


def _colorSymbol(idx, x, y, r):
    def shape(mode):
        if idx == 1:
            lg.circle(mode, x, y, r)
        elif idx == 2:
            lg.polygon(mode, x, y - r * 1.1, x + r, y + r * 0.7, x - r, y + r * 0.7)
        elif idx == 3:
            lg.rectangle(mode, x - r * 0.85, y - r * 0.85, r * 1.7, r * 1.7)
        elif idx == 4:
            lg.polygon(mode, x, y - r * 1.15, x + r, y, x, y + r * 1.15, x - r, y)
        elif idx == 5:
            heartShape(x, y - r * 0.15, r * 0.95, mode)
        else:
            lg.rectangle(mode, x - r * 0.35, y - r, r * 0.7, r * 2)
            lg.rectangle(mode, x - r, y - r * 0.35, r * 2, r * 0.7)
    lg.set_color(0.1, 0.05, 0.1, 0.8); lg.set_line_width(3); shape("line")
    lg.set_color(1, 1, 1, 0.95); shape("fill")


# ---------------------------------------------------------------- bulbs (sprite cached)
_bulb_cache = {}


def _bulb_sprite(color, r, on, eve):
    key = (tuple(round(v, 3) for v in color), r, on, eve)
    spr = _bulb_cache.get(key)
    if spr:
        return spr
    size = int(r * 3 * 2 + 6)
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    add = None
    c = size / 2
    lg.push_target(surf); lg.push(); lg.origin()
    if on:
        lg.set_color(color[0], color[1], color[2], 0.25); lg.circle("fill", c, c, r * 2.4)
        col(color); lg.circle("fill", c, c, r)
        lg.set_color(1, 1, 1, 0.9); lg.circle("fill", c - r * 0.3, c - r * 0.3, r * 0.35)
    else:
        shade(color, 0.35); lg.circle("fill", c, c, r)
    lg.pop(); lg.pop_target()
    if on and eve:
        add = pygame.Surface((size, size))
        add.fill((0, 0, 0))
        k = 0.14
        pygame.draw.circle(add, (int(color[0] * 255 * k), int(color[1] * 255 * k), int(color[2] * 255 * k)), (int(c), int(c)), int(r * 3))
        add = add.convert() if pygame.display.get_surface() else add
    spr = (lg.finalize(surf), add, size)
    _bulb_cache[key] = spr
    return spr


def bulb(x, y, on, color=None, r=6):
    color = color or (1, 0.85, 0.4)
    surf, add, size = _bulb_sprite(color, r, bool(on), evening)
    sc = lg.uniform_scale()
    if abs(lg.rotation()) < 1e-3 and abs(sc - 1) < 1e-3:
        X, Y = lg.tp(x, y)
        tgt = lg.get_target()
        if add is not None:
            if tgt.get_flags() & pygame.SRCALPHA:
                lg.set_color(color[0], color[1], color[2], 0.22)
                lg.circle("fill", x, y, r * 3)
            else:
                tgt.blit(add, (int(X - size / 2), int(Y - size / 2)), special_flags=pygame.BLEND_RGB_ADD)
        tgt.blit(surf, (int(X - size / 2), int(Y - size / 2)))
    else:
        lg.set_color(1, 1, 1, 1)
        lg.draw_surface(surf, x, y, centered=True)


def sign(x, y, w, h, label=None, font=None, bg=None, fg=None, t=None, hot=False):
    bg = bg or C["red"]
    fg = fg or C["cream"]
    phase = floor((T if t is None else t) * 9) % 3
    key = ("sign", w, h, tuple(bg[:3]), bool(hot), phase)
    sprite(key, lambda: _sign_board(-w / 2, -h / 2, w, h, bg, phase, hot), w / 2 + 18, h / 2 + 18, x + w / 2, y + h / 2)
    if label:
        fh = font.getHeight()
        text(label, x + w / 2, y + (h - fh) / 2, font, fg, w - 20, 2)


def _sign_board(x, y, w, h, bg, chase, hot):
    lg.set_color(0, 0, 0, 0.35)
    lg.rectangle("fill", x + 6, y + 8, w, h, 14)
    shade(bg, 1.25 if hot else 1)
    lg.rectangle("fill", x, y, w, h, 14)
    shade(bg, 0.55)
    lg.set_line_width(5)
    lg.rectangle("line", x + 7, y + 7, w - 14, h - 14, 10)
    col(C["gold"])
    lg.set_line_width(4)
    lg.rectangle("line", x, y, w, h, 14)
    step = 26
    idx = [0]

    def b(bx, by):
        idx[0] += 1
        bulb(bx, by, ((idx[0] + chase) % 3 != 0) or hot, None, 4)
    bx = x + 14
    while bx <= x + w - 10:
        b(bx, y + 1); bx += step
    by = y + 14
    while by <= y + h - 10:
        b(x + w - 1, by); by += step
    bx = x + w - 14
    while bx >= x + 10:
        b(bx, y + h - 1); bx -= step
    by = y + h - 14
    while by >= y + 10:
        b(x + 1, by); by -= step


def bullseye(x, y, r, flip=1, rings=5):
    fq = round(flip if flip else 1, 1) or 0.05
    sprite(("bull", r, fq, rings), lambda: _bullseye(0, 0, r, fq, rings), r + 6, r + 6, x, y)


def _bullseye(x, y, r, flip=1, rings=5):
    lg.push()
    lg.translate(x, y)
    lg.scale(1, flip if flip else 1)
    lg.set_color(0, 0, 0, 0.3)
    lg.circle("fill", 4, 5, r)
    for i in range(rings, 0, -1):
        col(C["red"] if i % 2 == 1 else C["cream"])
        lg.circle("fill", 0, 0, r * i / rings)
    lg.set_color(0.35, 0.02, 0.05)
    lg.set_line_width(2)
    lg.circle("line", 0, 0, r)
    lg.set_color(1, 1, 1, 0.35)
    lg.arc("fill", 0, 0, r * 0.95, pi * 1.1, pi * 1.45)
    lg.pop()


_spr_cache = {}


def sprite(key, painter, hw, hh, x, y):
    """Draw painter() (which draws around 0,0 within +-hw/+-hh) via a cached bitmap.

    Falls back to direct drawing when the current transform is rotated."""
    if abs(lg.rotation()) > 1e-3:
        lg.push(); lg.translate(x, y); painter(); lg.pop()
        return
    k = lg.uniform_scale()
    ck = (key, round(k, 2), evening)
    surf = _spr_cache.get(ck)
    if surf is None:
        if len(_spr_cache) > 900:
            _spr_cache.clear()
        w, h = max(2, int(hw * 2 * k) + 4), max(2, int(hh * 2 * k) + 4)
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        lg.push_target(surf); lg.push(); lg.origin()
        lg.translate(w / 2, h / 2); lg.scale(k, k)
        painter()
        lg.pop(); lg.pop_target()
        surf = lg.finalize(surf)
        _spr_cache[ck] = surf
    X, Y = lg.tp(x, y)
    lg.get_target().blit(surf, (int(X - surf.get_width() / 2), int(Y - surf.get_height() / 2)))


def duck(x, y, s, d, body=None, flip=1):
    body = body or C["yellow"]
    flip = 1 if flip is None else flip
    s = round(s, 2)
    fq = round(flip, 1) or (0.05 if flip >= 0 else -0.05)
    key = ("duck", s, d, tuple(body[:3]), fq)
    sprite(key, lambda: _duck(0, 0, s, d, body, fq), 70 * s, 66 * s, x, y)


def _duck(x, y, s, d, body=None, flip=1):
    body = body or C["yellow"]
    lg.push()
    lg.translate(x, y)
    lg.scale(s * d, s * (flip if flip is not None else 1))
    lg.set_color(0, 0, 0, 0.25)
    lg.ellipse("fill", 4, 6, 44, 26)
    col(body)
    lg.ellipse("fill", 0, 0, 44, 26)
    lg.ellipse("fill", -30, -14, 18, 18)
    lg.circle("fill", 22, -34, 22)
    shade(body, 0.8)
    lg.ellipse("fill", -6, 2, 24, 12)
    col(C["orange"])
    lg.polygon("fill", 40, -36, 62, -30, 40, -24)
    lg.set_color(0.05, 0.05, 0.08)
    lg.circle("fill", 28, -40, 4.5)
    lg.set_color(1, 1, 1)
    lg.circle("fill", 29.5, -41.5, 1.6)
    lg.set_color(1, 1, 1, 0.5)
    lg.ellipse("fill", 12, -44, 8, 5)
    lg.pop()


def plush(x, y, kind, color, swing, s=1):
    lg.push()
    lg.translate(x, y)
    lg.rotate(swing)
    lg.scale(s, s)
    lg.set_color(0.9, 0.9, 0.8)
    lg.set_line_width(2)
    lg.line(0, -40, 0, 0)
    if kind == 1:
        col(color); lg.circle("fill", 0, 28, 24); lg.circle("fill", -17, 12, 9); lg.circle("fill", 17, 12, 9)
        lg.ellipse("fill", 0, 62, 20, 16)
        shade(color, 1.25); lg.ellipse("fill", 0, 36, 10, 8)
        lg.set_color(0.1, 0.07, 0.05); lg.circle("fill", -8, 24, 3); lg.circle("fill", 8, 24, 3); lg.circle("fill", 0, 34, 3)
    elif kind == 2:
        lg.set_color(0.97, 0.97, 0.97); lg.circle("fill", 0, 28, 24)
        lg.set_color(0.08, 0.08, 0.1); lg.circle("fill", -17, 10, 8); lg.circle("fill", 17, 10, 8)
        lg.ellipse("fill", -9, 26, 6, 8); lg.ellipse("fill", 9, 26, 6, 8)
        lg.set_color(0.97, 0.97, 0.97); lg.ellipse("fill", 0, 62, 20, 16)
        lg.set_color(1, 1, 1); lg.circle("fill", -9, 25, 2); lg.circle("fill", 9, 25, 2)
    else:
        col(color); lg.ellipse("fill", 0, 34, 18, 30)
        lg.polygon("fill", -14, 64, 14, 64, 0, 50)
        for i in range(6):
            lg.set_color(1, 1, 1, 0.5)
            lg.circle("fill", -8 + (i % 3) * 8, 20 + floor(i / 3) * 14, 3)
        lg.set_color(0.05, 0.05, 0.1); lg.circle("fill", -6, 14, 3); lg.circle("fill", 6, 14, 3)
    lg.pop()


# ---------------------------------------------------------------- the booth frame
_rng = random.Random(77)
_plushes = []
for _i in range(17):
    _plushes.append({
        "x": 100 + _i * 67 + _rng.randint(-10, 10), "y": 64 + _rng.randint(0, 18),
        "kind": _rng.randint(1, 3),
        "color": _rng.choice([C["pink"], C["tan"], C["sky"], C["purple"], C["cream"], C["green"], C["orange"]]),
        "ph": _rng.random() * 6, "s": 0.8 + _rng.random() * 0.35,
    })

_cache = {}


cache_tag = None   # (language, theme): cached layers with text/colours are rebuilt when it changes


def _cached_entry(key, size, painter):
    key = (key, cache_tag)
    e = _cache.get(key)
    if e is None:
        surf = pygame.Surface(size, pygame.SRCALPHA)
        lg.push_target(surf); lg.push(); lg.origin()
        painter()
        lg.pop(); lg.pop_target()
        # crop away the empty part so blits only touch real pixels
        r = surf.get_bounding_rect()
        if r.w == 0 or r.h == 0:
            r = pygame.Rect(0, 0, 1, 1)
        crop = lg.finalize(surf.subsurface(r).copy())
        if len(_cache) > 60:
            _cache.clear()
        e = (lg.finalize(surf), crop, r.x, r.y)
        _cache[key] = e
    return e


def cached(key, size, painter):
    """Render `painter()` once into a surface of `size` and return it."""
    return _cached_entry(key, size, painter)[0]


def blit_cached(key, painter, x=0, y=0, size=(W, H)):
    _, crop, ox, oy = _cached_entry(key, size, painter)
    X, Y = lg.tp(x + ox, y + oy)
    lg.get_target().blit(crop, (int(X), int(Y)))


def wall(color, pattern=None):
    def paint():
        I = INNER
        col(color)
        lg.rectangle("fill", 0, 0, W, H)
        if pattern == "planks":
            py = I["y"]
            while py <= I["y"] + I["h"]:
                shade(color, 0.85); lg.rectangle("fill", I["x"], py, I["w"], 2)
                py += 40
        elif pattern == "diamond":
            shade(color, 1.12)
            gx = I["x"]
            while gx <= I["x"] + I["w"]:
                gy = I["y"]
                while gy <= I["y"] + I["h"]:
                    lg.polygon("fill", gx, gy - 12, gx + 12, gy, gx, gy + 12, gx - 12, gy)
                    gy += 60
                gx += 60
    blit_cached(("wall", tuple(color), pattern), paint)


NEON = [(0.25, 0.85, 1), (0.85, 0.95, 1), (1, 0.3, 0.9), (1, 0.2, 0.35)]
_neon_glow = {}


def _glow_sprite(rgb_key):
    spr = _neon_glow.get(rgb_key)
    if spr is None:
        r, g, b = rgb_key
        spr = pygame.Surface((32, 32))
        spr.fill((0, 0, 0))
        for rad, k in ((15, 0.22), (10, 0.12)):
            pygame.draw.circle(spr, (min(255, int(r * k * 255)), min(255, int(g * k * 255)), min(255, int(b * k * 255))), (16, 16), rad)
        _neon_glow[rgb_key] = spr
    return spr


def neonFacade(t):
    from .lang import T as tr

    def sky():
        for i in range(8):
            k = i / 7
            lg.set_color(0.1 + 0.18 * k, 0.11 + 0.1 * k, 0.24 + 0.16 * k)
            lg.rectangle("fill", 0, i * 8, W, 9)
    blit_cached("neon_sky", sky, 0, 0, (W, 72))
    lg.set_color(0.32, 0.3, 0.45, 0.6)
    for i in range(6):
        cx = (i * 260 + t * 8) % (W + 300) - 150
        lg.ellipse("fill", cx, 14 + (i % 3) * 8, 90, 12)
    tgt = lg.get_target()
    ox, oy = lg.tp(0, 0)
    for x in range(-10, W + 13, 12):
        y = 26 + sin(x * 0.009 + t * 0.6) * 16 + sin(x * 0.03 + 1) * 4
        f = (x / W * 4 + t * 0.12) % 4
        i0 = int(floor(f)) % 4
        i1 = (i0 + 1) % 4
        m = f - floor(f)
        c0, c1 = NEON[i0], NEON[i1]
        r, g, b = c0[0] + (c1[0] - c0[0]) * m, c0[1] + (c1[1] - c0[1]) * m, c0[2] + (c1[2] - c0[2]) * m
        br = 0.55 + 0.45 * sin(x * 0.045 - t * 7)
        q = 4
        key = (round(r * q) / q, round(g * q) / q, round(b * q) / q)
        tgt.blit(_glow_sprite(key), (int(ox + x - 16), int(oy + y - 16)), special_flags=pygame.BLEND_RGB_ADD)
        k = 0.9 * br + 0.1
        pygame.draw.circle(tgt, (min(255, int((r * k + (1 - k) * 0.2) * 255)), min(255, int((g * k + (1 - k) * 0.15) * 255)),
                                 min(255, int((b * k + (1 - k) * 0.35) * 255))), (int(ox + x), int(oy + y)), 5)
    lg.set_color(0.98, 0.78, 0.15); lg.rectangle("fill", 0, 50, W, 34)
    lg.set_color(0.75, 0.5, 0.05); lg.rectangle("fill", 0, 80, W, 4)
    lg.set_color(0.45, 0.3, 0.05); lg.rectangle("fill", 0, 50, W, 2)
    fasc = tr("fascia")
    surf = lg.text_surface(fasc, F["sign22"], (107, 31, 128))
    tw = surf.get_width()
    off = (t * 40) % tw
    for k in range(-1, 3):
        X, Y = lg.tp(k * tw - off, 54)
        tgt.blit(surf, (int(X), int(Y)))
    chase = floor(t * 6)
    for i in range(int(W / 40) + 1):
        bulb(i * 40 + 20, 90, (i + chase) % 3 != 0, (1, 0.85, 0.45), 4)


def _paint_plush_row():
    for p in _plushes:
        plush(p["x"], p["y"], p["kind"], p["color"], 0, p["s"])


def _paint_posts():
    for side in (0, 1):
        x = 0 if side == 0 else W - 80
        col(C["yellow"]); lg.rectangle("fill", x, 60, 80, 600)
        shade(C["yellow"], 0.75); lg.rectangle("fill", x + (64 if side == 0 else 0), 60, 16, 600)
        col(C["red"]); lg.rectangle("fill", x + 18, 60, 44, 600)


def _paint_awning():
    sw = 64
    for i in range(int(W / sw) + 1):
        col(C["red"] if i % 2 == 0 else C["cream"])
        lg.rectangle("fill", i * sw, 0, sw, 56)
        lg.circle("fill", i * sw + sw / 2, 56, sw / 2)
    lg.set_color(0, 0, 0, 0.18)
    lg.rectangle("fill", 0, 0, W, 10)


def boothFront(title, t):
    blit_cached("plush_row", _paint_plush_row, 0, math.sin(t * 1.3) * 1.5, (W, 200))
    blit_cached("posts", _paint_posts)
    chase = floor(t * 8)
    for side in (0, 1):
        x = 0 if side == 0 else W - 80
        i = 0
        by = 100
        while by <= 630:
            i += 1
            bc = (1, 0.9, 0.5)
            if evening:
                bc = (0.3, 0.9, 1) if i % 2 == 0 else (1, 0.3, 0.85)
            bulb(x + 40, by, (i + chase) % 3 == (0 if side == 0 else 1), bc, 7)
            by += 32
    if evening:
        neonFacade(t)
    else:
        blit_cached("awning", _paint_awning, 0, 0, (W, 100))
        ch = floor(t * 6)
        sw = 64
        for i in range(int(W / sw) + 1):
            bulb(i * sw + sw / 2, 80, (i + ch) % 2 == 0, (1, 0.95, 0.6), 5)
    if title:
        sign(W / 2 - 230, 54, 460, 64, title, F["sign34"], C["blue"], C["cream"], t)


def _paint_counter():
    y = 630
    lg.set_color(0.62, 0.47, 0.3)
    lg.rectangle("fill", 0, y, W, H - y)
    for i in range(13):
        lg.set_color(0.5, 0.36, 0.22, 0.35)
        lg.rectangle("fill", i * 110 + 20, y + 10, 70, H - y - 20, 10)
    lg.set_color(0.85, 0.85, 0.88)
    lg.rectangle("fill", 0, y - 6, W, 10)
    col(C["yellow"])
    lg.rectangle("fill", 0, y + 2, W, 4)


def counter():
    blit_cached("counter", _paint_counter)


def crosshair(x, y, size, flash):
    s = 26 if size == 2 else 15
    lg.set_line_width(3 if size == 2 else 2)
    lg.set_color(0, 0, 0, 0.7)
    lg.circle("line", x, y, s + 1)
    lg.set_color(1, 1 if flash else 0.25, 1 if flash else 0.2, 1)
    lg.circle("line", x, y, s)
    lg.line(x - s - 8, y, x - s * 0.4, y)
    lg.line(x + s * 0.4, y, x + s + 8, y)
    lg.line(x, y - s - 8, x, y - s * 0.4)
    lg.line(x, y + s * 0.4, x, y + s + 8)
    lg.circle("fill", x, y, 2)


# ---------------------------------------------------------------- effects
PALETTE = [C["red"], C["yellow"], C["blue"], C["green"], C["pink"], C["orange"], C["purple"]]
PELLET_T = 0.05


class _FX:
    def __init__(self):
        self.clear()

    def clear(self):
        self.parts, self.pops, self.marks, self.rings, self.shots = [], [], [], [], []
        self.shake = 0.0

    def shot(self, x, y):
        sx = W / 2 + (x - W / 2) * 0.6
        self.shots.append({"x": x, "y": y, "sx": sx, "sy": H + 40, "t": 0.0, "rot": random.random() * pi})
        if len(self.shots) > 12:
            self.shots.pop(0)

    def burst(self, x, y, n, colors=None, speed=300, kind="confetti", grav=700):
        colors = colors or PALETTE
        speed = speed or 300
        if len(self.parts) > 260:
            n = max(1, n // 3)
        for _ in range(n):
            a = random.random() * pi * 2
            sp = (0.3 + random.random()) * speed
            self.parts.append({
                "x": x, "y": y, "vx": cos(a) * sp, "vy": sin(a) * sp - speed * 0.3,
                "life": 0.6 + random.random() * 0.7, "t": 0.0, "size": 3 + random.random() * 5,
                "color": random.choice(colors), "kind": kind or "confetti",
                "rot": random.random() * 6, "vr": (random.random() - 0.5) * 14, "g": 700 if grav is None else grav,
            })

    def popup(self, txt, x, y, color=None, big=False):
        self.pops.append({"text": txt, "x": x, "y": y, "t": 0.0, "life": 1.4 if big else 0.9,
                          "color": color or C["yellow"], "big": big})
        return self.pops[-1]

    def mark(self, x, y):
        self.marks.append({"x": x, "y": y, "t": 0.0})
        if len(self.marks) > 40:
            self.marks.pop(0)

    def ring(self, x, y, color=None, r=40):
        self.rings.append({"x": x, "y": y, "t": 0.0, "color": color or (1, 1, 1), "r": r or 40})

    def addShake(self, a):
        self.shake = max(self.shake, a)

    def update(self, dt):
        keep = []
        for p in self.parts:
            p["t"] += dt
            p["vy"] += p["g"] * dt
            p["vx"] *= (1 - dt * 1.2)
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["rot"] += p["vr"] * dt
            if p["t"] <= p["life"]:
                keep.append(p)
        self.parts = keep
        for lst, lim in ((self.pops, None), (self.marks, 3.0), (self.rings, 0.35)):
            for p in lst:
                p["t"] += dt
        self.pops = [p for p in self.pops if p["t"] <= p["life"]]
        self.marks = [m for m in self.marks if m["t"] <= 3]
        self.rings = [r for r in self.rings if r["t"] <= 0.35]
        keep = []
        for s in self.shots:
            before = s["t"]
            s["t"] += dt
            if before < PELLET_T <= s["t"]:
                self.burst(s["x"], s["y"], 7, [(1, 0.95, 0.6), (1, 0.7, 0.2), C["white"]], 260, "spark", 300)
            if s["t"] <= 1.1:
                keep.append(s)
        self.shots = keep
        self.shake = max(0.0, self.shake - dt * 30)

    def drawShots(self):
        for s in self.shots:
            if s["t"] < PELLET_T:
                k = s["t"] / PELLET_T
                px, py = s["sx"] + (s["x"] - s["sx"]) * k, s["sy"] + (s["y"] - s["sy"]) * k
                k2 = max(0, k - 0.35)
                tx, ty = s["sx"] + (s["x"] - s["sx"]) * k2, s["sy"] + (s["y"] - s["sy"]) * k2
                lg.set_line_width(5); lg.set_color(1, 0.9, 0.6, 0.5); lg.line(tx, ty, px, py)
                lg.set_color(0.85, 0.65, 0.4); lg.circle("fill", px, py, 6 + 6 * (1 - k))
            else:
                k = s["t"] - PELLET_T
                if k < 0.16:
                    a = 1 - k / 0.16
                    r = 18 + 46 * (k / 0.16)
                    lg.set_blend("add")
                    lg.set_color(1, 0.9, 0.5, a * 0.9)
                    lg.push(); lg.translate(s["x"], s["y"]); lg.rotate(s["rot"])
                    lg.polygon("fill", starPoly(0, 0, r, 8, 0.35, 0))
                    lg.pop()
                    lg.set_color(1, 1, 1, a)
                    lg.circle("fill", s["x"], s["y"], 10 * a + 3)
                    lg.set_blend("alpha")
                if k < 0.4:
                    a = 1 - k / 0.4
                    lg.set_line_width(4)
                    lg.set_color(0, 0, 0, a * 0.5); lg.circle("line", s["x"], s["y"], 8 + k * 110 + 1.5)
                    lg.set_color(1, 1, 0.85, a); lg.circle("line", s["x"], s["y"], 8 + k * 110)
                a = max(0, 1 - k)
                if a > 0.05:
                    lg.set_color(1, 1, 1, a)
                    lg.set_line_width(2)
                    x, y = s["x"], s["y"]
                    lg.line(x - 9, y - 9, x - 4, y - 4); lg.line(x + 9, y + 9, x + 4, y + 4)
                    lg.line(x + 9, y - 9, x + 4, y - 4); lg.line(x - 9, y + 9, x - 4, y + 4)

    def drawMarks(self):
        for m in self.marks:
            a = 1 - m["t"] / 3
            lg.set_color(0.1, 0.07, 0.05, 0.55 * a)
            lg.circle("fill", m["x"], m["y"], 4)

    def draw(self):
        for r in self.rings:
            k = r["t"] / 0.35
            c = r["color"]
            lg.set_color(c[0], c[1], c[2], 1 - k)
            lg.set_line_width(4 * (1 - k) + 1)
            lg.circle("line", r["x"], r["y"], r["r"] * (0.3 + k))
        for p in self.parts:
            a = min(1, (p["life"] - p["t"]) / 0.3)
            c = p["color"]
            lg.set_color(c[0], c[1], c[2], a)
            kind = p["kind"]
            if kind == "star":
                lg.push(); lg.translate(p["x"], p["y"]); lg.rotate(p["rot"])
                lg.polygon("fill", starPoly(0, 0, p["size"] * 1.6, 5, 0.5))
                lg.pop()
            elif kind == "dust":
                lg.set_color(0.9, 0.85, 0.75, a * 0.6)
                lg.circle("fill", p["x"], p["y"], p["size"] * (1 + p["t"] * 2))
            elif kind == "spark":
                lg.set_line_width(2)
                lg.line(p["x"], p["y"], p["x"] - p["vx"] * 0.03, p["y"] - p["vy"] * 0.03)
            elif kind == "drop":
                lg.circle("fill", p["x"], p["y"], p["size"] * 0.7)
            else:
                lg.push(); lg.translate(p["x"], p["y"]); lg.rotate(p["rot"])
                lg.rectangle("fill", -p["size"], -p["size"] * 0.5, p["size"] * 2, p["size"])
                lg.pop()
        for p in self.pops:
            k = p["t"] / p["life"]
            s = (1 + 0.4 * max(0, 1 - p["t"] * 5)) if p["big"] else (1 + 0.5 * max(0, 1 - p["t"] * 8))
            font = F["ui46"] if p["big"] else F["ui26"]
            a = (1 - (k - 0.7) / 0.3) if k > 0.7 else 1
            c = p["color"]
            lg.push()
            lg.translate(p["x"], p["y"] - k * 60)
            lg.scale(s, s)
            text(p["text"], 0, -font.getHeight() / 2, font, (c[0], c[1], c[2], a), 600, 3)
            lg.pop()


FX = _FX()


# ---------------------------------------------------------------- hazard bombs (stars, balloons, rail targets)
def _bomb_icon(r):
    lg.set_color(0.1, 0.1, 0.12); lg.circle("fill", 0, 0, r)
    lg.set_color(0.35, 0.35, 0.4); lg.rectangle("fill", -r * 0.28, -r * 1.25, r * 0.56, r * 0.4)
    lg.set_color(0.6, 0.5, 0.3); lg.set_line_width(max(2, r * 0.12))
    lg.line(0, -r * 1.25, r * 0.25, -r * 1.6, r * 0.55, -r * 1.7)
    lg.set_color(1, 1, 1, 0.3); lg.circle("fill", -r * 0.35, -r * 0.35, r * 0.28)
    lg.set_color(0.9, 0.15, 0.15)
    lg.set_line_width(max(2, r * 0.18))
    lg.line(-r * 0.35, -r * 0.35, r * 0.35, r * 0.35)
    lg.line(r * 0.35, -r * 0.35, -r * 0.35, r * 0.35)


def bombIcon(x, y, r, t):
    """A round black bomb with a red X and a sizzling fuse: shooting it costs points."""
    rq = round(r)
    sprite(("bombicon", rq), lambda: _bomb_icon(rq), rq * 1.8 + 4, rq * 1.9 + 4, x, y)
    lg.set_color(1, 0.7 + 0.3 * sin(t * 30), 0.2)
    lg.circle("fill", x + rq * 0.55, y - rq * 1.7, max(2, rq * 0.18 + rq * 0.08 * sin(t * 25)))
