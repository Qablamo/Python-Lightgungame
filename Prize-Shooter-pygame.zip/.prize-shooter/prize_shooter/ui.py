"""Shootable signboard buttons."""
import math
from . import gfx as G
from . import lg
from . import audio as A


class Button:
    def __init__(self, x, y, w, h, label=None, font=None, bg=None, fg=None, onShoot=None, icon=None):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.label, self.bg, self.fg = label, bg, fg
        self.font = font or G.F["sign34"]
        self.onShoot = onShoot
        self.icon = icon
        self.wob = 0.0
        self.opt = None

    def contains(self, x, y):
        return self.x <= x <= self.x + self.w and self.y <= y <= self.y + self.h

    def update(self, dt):
        self.wob = max(0.0, self.wob - dt * 2.5)

    def draw(self, ax=None, ay=None):
        hot = ax is not None and self.contains(ax, ay)
        lg.push()
        cx, cy = self.x + self.w / 2, self.y
        if self.wob > 0:
            lg.translate(cx, cy)
            lg.rotate(math.sin(self.wob * 25) * self.wob * 0.15)
            lg.translate(-cx, -cy)
        G.sign(self.x, self.y, self.w, self.h, None if self.icon else self.label, self.font, self.bg, self.fg, None, hot)
        if self.icon:
            self.icon(self.x, self.y, self.w, self.h, hot)
        lg.pop()

    def shoot(self, x, y):
        if self.contains(x, y):
            self.wob = 1.0
            A.play("ding", 0.6)
            G.FX.burst(x, y, 14, None, 260)
            if self.onShoot:
                self.onShoot()
            return True
        return False
