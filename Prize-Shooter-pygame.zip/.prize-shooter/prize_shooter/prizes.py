"""The 40 collectible toys, drawn with shapes (port of prizes.lua)."""
import math
from . import lg
from . import gfx as G

sin, cos, pi = math.sin, math.cos, math.pi

TIER_SCALE = {1: 0.62, 2: 0.8, 3: 0.74, 4: 0.9, 5: 1.04}


def _it(tier, kind, shape_or_animal, color, acc=(), scale=1.0):
    d = {"tier": tier, "kind": kind, "color": color, "acc": set(acc), "scale": scale}
    d["shape" if kind == "squishy" else "animal"] = shape_or_animal
    d["grand"] = tier == 5
    return d


ITEMS = {
    "stars1": _it(1, "squishy", "star", (1, 0.85, 0.25)),
    "stars2": _it(2, "squishy", "moon", (1, 0.93, 0.6)),
    "stars3": _it(3, "plush", "unicorn", (0.98, 0.96, 1)),
    "stars4": _it(4, "plush", "unicorn", (1, 0.85, 0.95), ("sparkles",)),
    "stars5": _it(5, "plush", "rainbow", (0.98, 0.96, 1), ("wings", "sparkles")),
    "shark1": _it(1, "squishy", "fish", (0.3, 0.75, 0.85)),
    "shark2": _it(2, "squishy", "octopus", (0.75, 0.45, 0.9)),
    "shark3": _it(3, "plush", "dolphin", (0.45, 0.65, 0.9)),
    "shark4": _it(4, "plush", "shark", (0.55, 0.62, 0.72)),
    "shark5": _it(5, "plush", "megalodon", (0.32, 0.38, 0.48)),
    "ducks1": _it(1, "squishy", "duckling", (1, 0.88, 0.3)),
    "ducks2": _it(2, "squishy", "rubberduck", (1, 0.82, 0.15)),
    "ducks3": _it(3, "plush", "duck", (1, 0.85, 0.25)),
    "ducks4": _it(4, "plush", "mallard", (0.62, 0.5, 0.38)),
    "ducks5": _it(5, "plush", "duck", (1, 0.8, 0.2), ("cape", "crown")),
    "rails1": _it(1, "squishy", "sheriff", (1, 0.78, 0.25)),
    "rails2": _it(2, "squishy", "horseshoe", (0.75, 0.75, 0.8)),
    "rails3": _it(3, "plush", "pony", (0.95, 0.85, 0.7)),
    "rails4": _it(4, "plush", "pony", (0.6, 0.4, 0.25)),
    "rails5": _it(5, "plush", "teddy", (0.8, 0.6, 0.38), ("cowboy", "badge", "bandana")),
    "cans1": _it(1, "squishy", "cat", (0.85, 0.85, 0.9)),
    "cans2": _it(2, "squishy", "yarn", (0.95, 0.45, 0.6)),
    "cans3": _it(3, "plush", "cat", (0.97, 0.97, 0.97)),
    "cans4": _it(4, "plush", "cat", (1, 0.65, 0.3), ("stripes",)),
    "cans5": _it(5, "plush", "cat", (0.6, 0.62, 0.68), ("stripes", "bowtie", "can")),
    "hearts1": _it(1, "squishy", "heart", (1, 0.3, 0.45)),
    "hearts2": _it(2, "squishy", "heartcupcake", (1, 0.6, 0.75)),
    "hearts3": _it(3, "plush", "bunny", (1, 0.92, 0.95), ("heart",)),
    "hearts4": _it(4, "plush", "teddy", (1, 0.65, 0.78), ("heart",)),
    "hearts5": _it(5, "plush", "heartbear", (0.95, 0.35, 0.5), ("bigheart",)),
    "pyramid1": _it(1, "squishy", "sun", (1, 0.75, 0.2)),
    "pyramid2": _it(2, "squishy", "pyramid", (0.92, 0.75, 0.45)),
    "pyramid3": _it(3, "plush", "fox", (0.95, 0.82, 0.6)),
    "pyramid4": _it(4, "plush", "lion", (1, 0.78, 0.35)),
    "pyramid5": _it(5, "plush", "camel", (0.82, 0.62, 0.38), (), 1.35),
    "balloons1": _it(1, "squishy", "balloon", (0.95, 0.25, 0.35)),
    "balloons2": _it(2, "squishy", "rainbow", (1, 1, 1)),
    "balloons3": _it(3, "plush", "penguin", (0.15, 0.17, 0.25), ("party",)),
    "balloons4": _it(4, "plush", "teddy", (0.55, 0.7, 1), ("party", "bowtie")),
    "balloons5": _it(5, "plush", "dino", (0.4, 0.8, 0.45), ("party", "balloon")),
}

SIL = False
DARK = (0.08, 0.06, 0.08)
WHITE = (1, 1, 1)
PINK = (1, 0.55, 0.65)


def col(c, a=1, f=1):
    if SIL:
        lg.set_color(0.16, 0.09, 0.22, 0.8)
        return
    lg.set_color(c[0] * f, c[1] * f, c[2] * f, a)


def face(x, y, s, mouth=True):
    if SIL:
        return
    lg.set_color(0.08, 0.06, 0.08)
    lg.circle("fill", x - 10 * s, y, 3.5 * s); lg.circle("fill", x + 10 * s, y, 3.5 * s)
    lg.set_color(1, 1, 1); lg.circle("fill", x - 9 * s, y - 1.5 * s, 1.2 * s); lg.circle("fill", x + 11 * s, y - 1.5 * s, 1.2 * s)
    lg.set_color(0.08, 0.06, 0.08); lg.set_line_width(1.8 * s)
    if mouth:
        lg.arc("line", "open", x, y + 3 * s, 4 * s, 0.2, pi - 0.2)
    lg.set_color(1, 0.5, 0.6, 0.6)
    lg.ellipse("fill", x - 16 * s, y + 6 * s, 4 * s, 2.5 * s); lg.ellipse("fill", x + 16 * s, y + 6 * s, 4 * s, 2.5 * s)


def shine(x, y, r):
    if SIL:
        return
    lg.set_color(1, 1, 1, 0.45); lg.ellipse("fill", x, y, r, r * 0.6)


# ---------------------------------------------------------------- squishies
def sq_star(c):
    v = G.starPoly(0, 4, 50, 5, 0.58, -pi / 2)
    col(c, 1, 0.75); lg.polygon("fill", [(x + 2, y + 4) for x, y in v])
    col(c); lg.polygon("fill", v)
    shine(-12, -8, 7); face(0, 10, 1)


def sq_moon(c):
    col(c, 1, 0.8); lg.circle("fill", 2, 3, 42)
    col(c); lg.circle("fill", 0, 0, 42)
    col(c, 1, 0.88); lg.circle("fill", 18, -16, 7); lg.circle("fill", -22, 18, 5); lg.circle("fill", 24, 20, 4)
    shine(-16, -18, 8)
    if not SIL:
        lg.set_color(0.08, 0.06, 0.08); lg.set_line_width(2)
        lg.arc("line", "open", -10, 2, 5, 0.3, pi - 0.3); lg.arc("line", "open", 10, 2, 5, 0.3, pi - 0.3)
        lg.set_color(1, 0.5, 0.6, 0.6); lg.ellipse("fill", -18, 10, 4, 2.5); lg.ellipse("fill", 18, 10, 4, 2.5)


def sq_fish(c):
    col(c, 1, 0.8); lg.polygon("fill", 30, 0, 52, -22, 52, 22)
    col(c); lg.ellipse("fill", -4, 0, 40, 30)
    col(c, 1, 1.2); lg.ellipse("fill", -6, 12, 26, 12)
    col(c, 1, 0.8); lg.polygon("fill", -6, -26, 14, -40, 12, -24)
    shine(-18, -14, 6); face(-12, -2, 0.9)


def sq_octopus(c):
    col(c, 1, 0.85)
    for i in (-3, -1, 1, 3):
        lg.ellipse("fill", i * 9, 30, 8, 16)
    col(c); lg.circle("fill", 0, -4, 34)
    shine(-12, -20, 7); face(0, 2, 1)


def sq_duckling(c):
    col(c); lg.circle("fill", 0, 8, 38)
    col((1, 0.6, 0.15)); lg.ellipse("fill", 0, 10, 10, 6)
    col(c, 1, 0.85); lg.ellipse("fill", 26, 16, 10, 14); lg.ellipse("fill", -26, 16, 10, 14)
    col(c); lg.polygon("fill", -4, -30, 4, -42, 8, -28)
    shine(-14, -10, 7); face(0, 0, 1, False)


def sq_rubberduck(c):
    col(c, 1, 0.8); lg.ellipse("fill", 2, 22, 46, 26)
    col(c); lg.ellipse("fill", 0, 18, 46, 26); lg.circle("fill", 16, -14, 26)
    col((1, 0.5, 0.1)); lg.ellipse("fill", 42, -10, 14, 7)
    col(c, 1, 0.85); lg.ellipse("fill", -8, 20, 22, 11)
    shine(4, -28, 6); face(14, -16, 0.8, False)


def sq_sheriff(c):
    v = G.starPoly(0, 4, 48, 6, 0.6, -pi / 2)
    col(c, 1, 0.75); lg.polygon("fill", [(x + 2, y + 4) for x, y in v])
    col(c); lg.polygon("fill", v)
    for i in range(6):
        a = -pi / 2 + i * pi / 3
        lg.circle("fill", cos(a) * 48, 4 + sin(a) * 48, 7)
    col(c, 1, 0.85); lg.circle("fill", 0, 4, 24)
    shine(-14, -10, 6); face(0, 6, 0.9)


def sq_horseshoe(c):
    col(c, 1, 0.8); lg.set_line_width(26); lg.arc("line", "open", 2, 6, 34, pi * 0.95, pi * 2.05)
    col(c); lg.arc("line", "open", 0, 2, 34, pi * 0.95, pi * 2.05)
    lg.rectangle("fill", -47, 0, 26, 40, 8); lg.rectangle("fill", 21, 0, 26, 40, 8)
    if not SIL:
        lg.set_color(0.45, 0.45, 0.5)
        for px, py in ((-34, 16), (34, 16), (-28, -18), (28, -18)):
            lg.circle("fill", px, py, 3)
    face(0, -32, 0.75)


def sq_cat(c):
    col(c); lg.polygon("fill", -38, -6, -30, -42, -10, -26); lg.polygon("fill", 38, -6, 30, -42, 10, -26)
    lg.ellipse("fill", 0, 6, 44, 38)
    if not SIL:
        lg.set_color(1, 0.6, 0.7); lg.polygon("fill", -30, -16, -28, -34, -16, -24); lg.polygon("fill", 30, -16, 28, -34, 16, -24)
    shine(-18, -10, 7); face(0, 6, 1)
    if not SIL:
        lg.set_color(0.3, 0.3, 0.35); lg.set_line_width(1.5)
        lg.line(-22, 14, -40, 10); lg.line(-22, 18, -40, 20); lg.line(22, 14, 40, 10); lg.line(22, 18, 40, 20)


def sq_yarn(c):
    col(c, 1, 0.8); lg.circle("fill", 2, 6, 42)
    col(c); lg.circle("fill", 0, 2, 42)
    if not SIL:
        lg.set_color(c[0] * 0.75, c[1] * 0.75, c[2] * 0.75); lg.set_line_width(3)
        for i in range(-2, 3):
            lg.arc("line", "open", i * 12, 2, 40, -1.2, 1.2)
        lg.set_line_width(4); lg.line(30, 30, 46, 46, 40, 56, 54, 60)
        lg.set_color(0.8, 0.8, 0.85); lg.line(-30, -36, 10, 30); lg.line(-24, -40, 16, 26)
    face(-4, 4, 1)


def sq_heart(c):
    col(c, 1, 0.75); G.heartShape(2, 6, 46)
    col(c); G.heartShape(0, 2, 46)
    shine(-22, -14, 7); face(0, 4, 1)


def sq_heartcupcake(c):
    col((0.95, 0.75, 0.5)); lg.polygon("fill", -32, 8, 32, 8, 24, 48, -24, 48)
    if not SIL:
        lg.set_color(0.85, 0.6, 0.35)
        for i in range(-2, 3):
            lg.line(i * 12, 10, i * 9, 46)
    col(c); lg.circle("fill", -18, 0, 18); lg.circle("fill", 18, 0, 18); lg.circle("fill", 0, -10, 24)
    col((0.9, 0.1, 0.3)); G.heartShape(0, -40, 14)
    if not SIL:
        for i in range(8):
            lg.set_color(1, 1, 1); lg.circle("fill", -20 + i * 6, -2 + (i % 2) * 6, 1.6)
    face(0, -4, 0.85)


def sq_sun(c):
    col(c, 1, 0.9)
    for i in range(12):
        a = i / 12 * pi * 2
        lg.polygon("fill", cos(a - 0.15) * 36, sin(a - 0.15) * 36, cos(a + 0.15) * 36, sin(a + 0.15) * 36, cos(a) * 52, sin(a) * 52)
    col(c, 1, 0.8); lg.circle("fill", 2, 4, 36)
    col(c); lg.circle("fill", 0, 0, 36)
    shine(-12, -14, 6); face(0, 2, 1)


def sq_pyramid(c):
    col(c, 1, 0.8); lg.polygon("fill", -46, 46, 50, 46, 2, -44)
    col(c); lg.polygon("fill", -50, 42, 46, 42, -2, -48)
    col(c, 1, 0.82); lg.polygon("fill", -2, -48, 46, 42, 20, 42)
    if not SIL:
        lg.set_color(c[0] * 0.8, c[1] * 0.8, c[2] * 0.8)
        for i in range(1, 4):
            lg.line(-50 + i * 12, 42 - i * 22, 46 - i * 12, 42 - i * 22)
    face(-4, 14, 0.9)


def sq_balloon(c):
    if not SIL:
        lg.set_color(0.9, 0.9, 0.9); lg.set_line_width(2); lg.line(0, 40, 6, 52, -4, 60)
    col(c, 1, 0.8); lg.ellipse("fill", 2, 0, 36, 42)
    col(c); lg.ellipse("fill", 0, -2, 36, 42); lg.polygon("fill", -6, 40, 6, 40, 0, 34)
    shine(-14, -22, 8); face(0, 0, 1)


def sq_rainbow(c):
    bands = [G.C["red"], G.C["orange"], G.C["yellow"], G.C["green"], G.C["blue"], G.C["purple"]]
    for i, b in enumerate(bands):
        col(b); lg.arc("fill", 0, 22, 54 - i * 6, pi, 2 * pi)
    col((0.6, 0.45, 0.65), 1, 0.6); lg.arc("fill", 0, 22, 18, pi, 2 * pi)
    col((1, 1, 1)); lg.circle("fill", -42, 24, 14); lg.circle("fill", -28, 28, 12); lg.circle("fill", 42, 24, 14); lg.circle("fill", 28, 28, 12)
    face(0, -10, 0.85)


SQ = {k[3:]: v for k, v in globals().items() if k.startswith("sq_")}


# ---------------------------------------------------------------- plushies
def accBack(has):
    if "wings" in has:
        for sx in (-1, 1):
            lg.push(); lg.translate(sx * 26, 14); lg.rotate(sx * 0.35)
            for f in range(3):
                col((1, 0.92 - f * 0.06, 0.98))
                lg.ellipse("fill", sx * (22 + f * 8), -14 + f * 10, 24 - f * 4, 11)
            lg.pop()
    if "cape" in has:
        col((0.85, 0.1, 0.2)); lg.polygon("fill", -24, -4, 24, -4, 44, 54, -44, 54)
        col((1, 0.85, 0.3)); lg.rectangle("fill", -44, 50, 88, 5)
    if "balloon" in has:
        if not SIL:
            lg.set_color(0.9, 0.9, 0.9); lg.set_line_width(1.5); lg.line(34, 12, 46, -40)
        col(G.C["red"]); lg.ellipse("fill", 48, -62, 16, 20)


def accFront(has):
    if "bigheart" in has:
        col((0.9, 0.05, 0.25)); G.heartShape(0, 20, 26)
        if not SIL:
            lg.set_color(1, 1, 1, 0.45); lg.ellipse("fill", -12, 10, 6, 4)
        col((0.95, 0.35, 0.5), 1, 0.9); lg.circle("fill", -24, 20, 9); lg.circle("fill", 24, 20, 9)
    elif "heart" in has:
        col((0.9, 0.05, 0.25)); G.heartShape(0, 22, 15)
        if not SIL:
            lg.set_color(1, 1, 1, 0.5); lg.circle("fill", -6, 16, 3)
    if "bowtie" in has:
        col((0.9, 0.15, 0.25)); lg.polygon("fill", 0, 0, -14, -8, -14, 8); lg.polygon("fill", 0, 0, 14, -8, 14, 8)
        lg.circle("fill", 0, 0, 4)
    if "bandana" in has:
        col((0.85, 0.15, 0.15)); lg.polygon("fill", -20, -2, 20, -2, 0, 16)
        if not SIL:
            lg.set_color(1, 1, 1); lg.circle("fill", -6, 3, 1.5); lg.circle("fill", 6, 3, 1.5); lg.circle("fill", 0, 9, 1.5)
    if "badge" in has:
        if SIL:
            col((1, 1, 1)); lg.polygon("fill", G.starPoly(-12, 26, 8))
        else:
            G.star(-12, 26, 8, (1, 0.8, 0.2), -pi / 2)
    if "can" in has:
        col((0.76, 0.78, 0.82)); lg.rectangle("fill", 24, 4, 16, 22, 2)
        col(G.C["red"]); lg.rectangle("fill", 24, 10, 16, 10)
    if "crown" in has:
        col((1, 0.8, 0.15))
        lg.polygon("fill", -18, -50, -18, -66, -9, -58, 0, -72, 9, -58, 18, -66, 18, -50)
        if not SIL:
            lg.set_color(0.2, 0.5, 1); lg.circle("fill", 0, -58, 3)
    if "party" in has:
        col((0.3, 0.6, 1)); lg.polygon("fill", -14, -48, 14, -48, 4, -88)
        if not SIL:
            lg.set_color(1, 0.85, 0.2); lg.polygon("fill", -9, -62, 9, -62, 7, -56, -11, -56)
            lg.set_color(1, 0.4, 0.6); lg.circle("fill", 4, -90, 6)
    if "cowboy" in has:
        col((0.55, 0.35, 0.18)); lg.ellipse("fill", 0, -50, 46, 9)
        lg.rectangle("fill", -18, -76, 36, 26, 8)
        col((0.85, 0.15, 0.15)); lg.rectangle("fill", -18, -58, 36, 5)
    if "sparkles" in has and not SIL:
        for i in range(4):
            a = G.T * 2 + i * pi / 2
            lg.set_color(1, 1, 0.7, 0.6 + 0.4 * sin(G.T * 6 + i))
            lg.polygon("fill", G.starPoly(cos(a) * 54, -10 + sin(a) * 50, 6, 4, 0.35, 0))


def plush(a, c, has):
    accBack(has)
    belly = (min(1, c[0] * 1.15 + 0.1), min(1, c[1] * 1.15 + 0.1), min(1, c[2] * 1.15 + 0.1))
    limb = c
    # ears / back items
    if a == "camel":
        col(c, 1, 0.85); lg.ellipse("fill", -30, -6, 17, 24); lg.ellipse("fill", 30, -6, 17, 24)
        col((0.85, 0.2, 0.2)); lg.rectangle("fill", -44, 2, 88, 8)
        col(c, 1, 0.9); lg.ellipse("fill", -24, -58, 7, 5); lg.ellipse("fill", 24, -58, 7, 5)
    elif a == "cat":
        col(c); lg.polygon("fill", -30, -34, -24, -64, -6, -48); lg.polygon("fill", 30, -34, 24, -64, 6, -48)
        col(PINK); lg.polygon("fill", -25, -42, -22, -58, -12, -48); lg.polygon("fill", 25, -42, 22, -58, 12, -48)
    elif a == "fox":
        col(c, 1, 0.92); lg.polygon("fill", -30, -30, -38, -86, -6, -48); lg.polygon("fill", 30, -30, 38, -86, 6, -48)
        col((1, 0.9, 0.85)); lg.polygon("fill", -26, -40, -32, -76, -12, -50); lg.polygon("fill", 26, -40, 32, -76, 12, -50)
    elif a == "pony":
        col(c, 1, 0.9); lg.polygon("fill", -22, -44, -16, -64, -6, -50); lg.polygon("fill", 22, -44, 16, -64, 6, -50)
        mane = (1, 0.6, 0.75) if c[0] > 0.8 else (0.3, 0.18, 0.1)
        col(mane)
        for i in range(5):
            lg.circle("fill", -10 + i * 5, -54 + (i % 2) * 3, 8)
    elif a == "heartbear":
        col(c); G.heartShape(-25, -44, 13); G.heartShape(25, -44, 13)
    elif a == "lion":
        col((0.85, 0.45, 0.15))
        for i in range(12):
            ang = i / 12 * pi * 2
            lg.circle("fill", cos(ang) * 32, -24 + sin(ang) * 32, 13)
    elif a == "dino":
        col((0.95, 0.6, 0.2))
        for i in range(-2, 3):
            lg.polygon("fill", i * 11 - 6, -48 + abs(i) * 4, i * 11 + 6, -48 + abs(i) * 4, i * 11, -64 + abs(i) * 4)
    elif a == "teddy":
        col(c); lg.circle("fill", -24, -44, 11); lg.circle("fill", 24, -44, 11)
    elif a == "bunny":
        col(c); lg.ellipse("fill", -12, -66, 8, 24); lg.ellipse("fill", 12, -66, 8, 24)
        col(PINK); lg.ellipse("fill", -12, -64, 4, 17); lg.ellipse("fill", 12, -64, 4, 17)
    elif a in ("shark", "megalodon", "dolphin"):
        col(c, 1, 0.85); lg.polygon("fill", -6, -48, 12, -76, 16, -46)
    elif a in ("unicorn", "rainbow"):
        if a == "rainbow":
            mane = [G.C["red"], G.C["orange"], G.C["yellow"], G.C["green"], G.C["blue"], G.C["purple"]]
        else:
            mane = [(0.85, 0.55, 1), (1, 0.6, 0.85), (0.6, 0.75, 1)]
        for i, m in enumerate(mane, 1):
            col(m); lg.circle("fill", 26 - i * 2, -52 + i * 9, 10)
    # legs & arms
    col(limb, 1, 0.9)
    lg.ellipse("fill", -18, 46, 13, 9); lg.ellipse("fill", 18, 46, 13, 9)
    lg.ellipse("fill", -32, 14, 9, 15); lg.ellipse("fill", 32, 14, 9, 15)
    # body
    col(c); lg.ellipse("fill", 0, 22, 30, 28)
    if a == "penguin":
        col(WHITE); lg.ellipse("fill", 0, 26, 22, 24)
        col((1, 0.6, 0.1)); lg.ellipse("fill", -16, 50, 11, 5); lg.ellipse("fill", 16, 50, 11, 5)
    elif a in ("shark", "megalodon", "dolphin", "duck"):
        col(WHITE, 1, 1 if a == "duck" else 0.97); lg.ellipse("fill", 0, 28, 18, 18)
    else:
        col(belly); lg.ellipse("fill", 0, 26, 17, 16)
    # head
    if a == "camel":
        col(c); lg.ellipse("fill", 0, -34, 24, 30)
    else:
        col(c); lg.circle("fill", 0, -24, 30)
    if a == "mallard":
        col((0.1, 0.5, 0.25)); lg.circle("fill", 0, -26, 29)
        col(WHITE); lg.ellipse("fill", 0, 3, 20, 4)
    elif a == "camel":
        col((0.85, 0.2, 0.2)); lg.rectangle("fill", -26, 10, 52, 14, 3)
        col((1, 0.8, 0.2)); lg.rectangle("fill", -26, 20, 52, 4)
    if "stripes" in has and not SIL:
        lg.set_color(c[0] * 0.6, c[1] * 0.6, c[2] * 0.6)
        for i in (-1, 0, 1):
            lg.polygon("fill", i * 9 - 3, -54, i * 9 + 3, -54, i * 9, -44)
        for sx in (-1, 1):
            lg.polygon("fill", sx * 30, 14, sx * 30, 20, sx * 18, 17)
            lg.polygon("fill", sx * 29, 28, sx * 28, 34, sx * 17, 31)
    if a == "penguin":
        col(WHITE); lg.ellipse("fill", -10, -24, 13, 15); lg.ellipse("fill", 10, -24, 13, 15); lg.ellipse("fill", 0, -14, 16, 12)
    # muzzle / beak
    if a == "cat":
        col(PINK); lg.polygon("fill", -4, -18, 4, -18, 0, -14)
        if not SIL:
            lg.set_color(0.35, 0.35, 0.4); lg.set_line_width(1.5)
            lg.line(-10, -14, -30, -18); lg.line(-10, -11, -30, -8); lg.line(10, -14, 30, -18); lg.line(10, -11, 30, -8)
    elif a == "fox":
        col((1, 0.97, 0.92)); lg.ellipse("fill", 0, -13, 14, 10)
        col(DARK); lg.ellipse("fill", 0, -17, 4, 3)
    elif a == "pony":
        col(c, 1, 1.12); lg.ellipse("fill", 0, -10, 18, 13)
        col(DARK, 0.6); lg.circle("fill", -6, -10, 2.2); lg.circle("fill", 6, -10, 2.2)
    elif a == "camel":
        col(c, 1, 1.12); lg.ellipse("fill", 0, -8, 19, 16)
        col(DARK, 0.6); lg.ellipse("fill", -7, -12, 3, 2); lg.ellipse("fill", 7, -12, 3, 2)
        col(DARK, 0.6); lg.set_line_width(2); lg.arc("line", "open", 0, -6, 7, 0.4, pi - 0.4)
    elif a == "heartbear":
        col((1, 0.85, 0.85)); lg.ellipse("fill", 0, -14, 13, 10)
        col((0.85, 0.05, 0.25)); G.heartShape(0, -19, 5)
    elif a == "mallard":
        col((1, 0.75, 0.15)); lg.ellipse("fill", 0, -14, 12, 6)
    elif a == "penguin":
        col((1, 0.6, 0.1)); lg.polygon("fill", -6, -16, 6, -16, 0, -6)
    elif a in ("teddy", "lion"):
        col((0.95, 0.82, 0.65)); lg.ellipse("fill", 0, -14, 13, 10)
        if not SIL:
            lg.set_color(0.1, 0.06, 0.04); lg.ellipse("fill", 0, -18, 4, 3)
    elif a == "duck":
        col((1, 0.55, 0.1)); lg.ellipse("fill", 0, -14, 12, 6)
    elif a in ("unicorn", "rainbow"):
        col((1, 0.8, 0.3)); lg.polygon("fill", -6, -50, 6, -50, 0, -78)
        if not SIL:
            lg.set_color(0.85, 0.6, 0.2); lg.set_line_width(1.5); lg.line(-3, -58, 4, -61); lg.line(-2, -66, 3, -68)
    elif a == "dolphin":
        col(c, 1, 1.15); lg.ellipse("fill", 0, -12, 10, 6)
    # face
    mouth = a not in ("duck", "mallard", "penguin", "pony", "camel", "heartbear")
    face(0, -36 if a == "camel" else -26, 1, mouth)
    if a == "camel" and not SIL:
        lg.set_color(c[0] * 0.85, c[1] * 0.85, c[2] * 0.85)
        lg.arc("fill", -10, -37, 6, pi, 2 * pi); lg.arc("fill", 10, -37, 6, pi, 2 * pi)
        lg.set_color(0.1, 0.06, 0.04); lg.set_line_width(1.5); lg.line(-16, -37, -4, -37); lg.line(4, -37, 16, -37)
    accFront(has)
    if a in ("shark", "megalodon") and not SIL:
        lg.set_color(0.5, 0.1, 0.15); lg.ellipse("fill", 0, -12, 14, 6)
        lg.set_color(1, 1, 1)
        for i in range(-2, 3):
            lg.polygon("fill", i * 5 - 2.5, -17, i * 5 + 2.5, -17, i * 5, -12)
    if a == "megalodon":
        col((1, 0.8, 0.15))
        lg.polygon("fill", -18, -50, -18, -64, -9, -56, 0, -70, 9, -56, 18, -64, 18, -50)
        if not SIL:
            lg.set_color(0.9, 0.15, 0.2); lg.circle("fill", 0, -58, 3)
            lg.set_color(0.25, 0.28, 0.35); lg.set_line_width(2); lg.line(14, -36, 22, -28)
    shine(-12, -40, 7)


def _scale(it, h, fit):
    sc = it["scale"]
    if fit:
        sc = min(sc, 1.1)
    return h / (135 if it["kind"] == "plush" else 110) * TIER_SCALE[it["tier"]] * sc


def drawOn(id_, x, bottomY, h, locked=False, wobble=0, fit=False):
    it = ITEMS[id_]
    s = _scale(it, h, fit)
    foot = 56 if it["kind"] == "plush" else 60
    draw(id_, x, bottomY - foot * s, h, locked, wobble, fit)


def draw(id_, x, y, h, locked=False, wobble=0, fit=False):
    global SIL
    it = ITEMS.get(id_)
    if not it:
        return
    SIL = bool(locked)
    s = _scale(it, h, fit)
    lg.push()
    lg.translate(x, y)
    lg.rotate(wobble or 0)
    lg.scale(s, s)
    if not locked and it["grand"]:
        lg.set_blend("add")
        lg.set_color(1, 0.85, 0.3, 0.12 + 0.06 * sin(G.T * 4))
        lg.circle("fill", 0, 0, 80)
        lg.set_blend("alpha")
    lg.set_color(0, 0, 0, 0.25); lg.ellipse("fill", 0, 54, 38, 8)
    if it["kind"] == "squishy":
        lg.translate(0, 8)
        SQ[it["shape"]](it["color"])
    else:
        plush(it["animal"], it["color"], it["acc"])
    lg.pop()
    if locked:
        f = G.F["ui26"] if h >= 60 else G.F["ui12"]
        G.text("?", x, y - f.getHeight() / 2, f, (0.9, 0.85, 1, 0.8), 60, 2 if h >= 60 else 1)
    SIL = False


# ---------------------------------------------------------------- score prizes (tour finale / consolation)
def drawPrize(tier, x, y, s):
    lg.push(); lg.translate(x, y); lg.scale(s, s)
    lg.set_color(0, 0, 0, 0.25); lg.ellipse("fill", 0, 92, 90, 16)
    if tier == 0:
        lg.set_color(0.95, 0.95, 0.9); lg.rectangle("fill", -4, 0, 8, 90)
        for i in range(6, 0, -1):
            G.col(G.C["pink"] if i % 2 == 0 else G.C["cream"])
            lg.circle("fill", 0, -10, i * 9)
    elif tier == 1:
        lg.set_color(0.8, 0.8, 0.85); lg.set_line_width(5); lg.circle("line", 0, -30, 22)
        G.star(0, 30, 48, G.C["gold"], G.T)
    else:
        body, panda, sz = G.C["tan"], tier == 3, 1.0
        if tier == 3:
            sz = 1.15
        if tier == 4:
            body, sz = G.C["orange"], 1.3
        lg.scale(sz, sz)
        lg.set_color(0.97, 0.97, 0.97) if panda else G.col(body)
        lg.ellipse("fill", 0, 40, 52, 48)
        lg.set_color(0.08, 0.08, 0.1) if panda else G.shade(body, 0.85)
        lg.ellipse("fill", -46, 70, 18, 14); lg.ellipse("fill", 46, 70, 18, 14)
        lg.ellipse("fill", -40, 28, 14, 22); lg.ellipse("fill", 40, 28, 14, 22)
        lg.set_color(0.97, 0.97, 0.97) if panda else G.col(body)
        lg.circle("fill", 0, -32, 44)
        lg.set_color(0.08, 0.08, 0.1) if panda else G.shade(body, 0.85)
        lg.circle("fill", -34, -66, 15); lg.circle("fill", 34, -66, 15)
        if panda:
            lg.ellipse("fill", -16, -36, 10, 13); lg.ellipse("fill", 16, -36, 10, 13)
            lg.set_color(1, 1, 1); lg.circle("fill", -15, -37, 3.5); lg.circle("fill", 17, -37, 3.5)
        else:
            lg.set_color(0.08, 0.06, 0.05); lg.circle("fill", -15, -38, 5); lg.circle("fill", 15, -38, 5)
        G.shade(G.C["white"] if panda else body, 1.2); lg.ellipse("fill", 0, -18, 18, 13)
        lg.set_color(0.08, 0.06, 0.05); lg.ellipse("fill", 0, -24, 6, 4)
        if tier == 4:
            lg.set_color(0.1, 0.06, 0.04)
            for i in (-1, 0, 1):
                lg.polygon("fill", i * 18 - 6, -76, i * 18 + 6, -76, i * 18, -56)
                lg.polygon("fill", -50, 20 + i * 18, -50, 30 + i * 18, -28, 25 + i * 18)
                lg.polygon("fill", 50, 20 + i * 18, 50, 30 + i * 18, 28, 25 + i * 18)
        G.col(G.C["red"])
        lg.polygon("fill", -14, 8, 0, 14, -14, 22); lg.polygon("fill", 14, 8, 0, 14, 14, 22)
        lg.circle("fill", 0, 14, 5)
    lg.pop()
