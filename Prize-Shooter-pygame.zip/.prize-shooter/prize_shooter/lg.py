"""A small love.graphics-like drawing layer on top of pygame.

Supports a transform stack (translate / rotate / scale), colours with alpha,
additive blending, and the primitives the game uses. Shapes with alpha or
additive blending are drawn through a small temporary surface.
"""
import math
import pygame

W, H = 1280, 720

_target = None
_targets = []
_col = (255, 255, 255, 255)
_lw = 1.0
_blend = "alpha"
# affine transform: x' = a*x + c*y + e ; y' = b*x + d*y + f
_m = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]
_stack = []
_font = None


def set_target(surf):
    global _target
    _target = surf


def push_target(surf):
    _targets.append(_target)
    set_target(surf)


def pop_target():
    set_target(_targets.pop())


def get_target():
    return _target


def finalize(surf):
    """Optimise a cached bitmap for fast blitting: opaque -> plain surface, else RLE-accelerated alpha."""
    if pygame.display.get_surface() is None:
        return surf
    w, h = surf.get_size()
    if surf.get_flags() & pygame.SRCALPHA:
        try:
            opaque = pygame.mask.from_surface(surf, 254).count() == w * h
        except Exception:
            opaque = False
        if opaque:
            return surf.convert()
        out = surf.convert_alpha()
        out.set_alpha(255, pygame.RLEACCEL)
        return out
    return surf.convert()


# ---------------------------------------------------------------- transforms
def push():
    _stack.append(list(_m))


def pop():
    global _m
    _m[:] = _stack.pop()


def origin():
    _m[:] = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]


def translate(x, y):
    a, b, c, d, e, f = _m
    _m[4] = a * x + c * y + e
    _m[5] = b * x + d * y + f


def rotate(r):
    if r == 0:
        return
    a, b, c, d, e, f = _m
    co, si = math.cos(r), math.sin(r)
    _m[0] = a * co + c * si
    _m[1] = b * co + d * si
    _m[2] = -a * si + c * co
    _m[3] = -b * si + d * co


def scale(sx, sy=None):
    if sy is None:
        sy = sx
    _m[0] *= sx
    _m[1] *= sx
    _m[2] *= sy
    _m[3] *= sy


def tp(x, y):
    a, b, c, d, e, f = _m
    return (a * x + c * y + e, b * x + d * y + f)


def _sx():
    return math.hypot(_m[0], _m[1])


def _sy():
    return math.hypot(_m[2], _m[3])


def _axis_aligned():
    return abs(_m[1]) < 1e-6 and abs(_m[2]) < 1e-6


def uniform_scale():
    return math.sqrt(abs(_m[0] * _m[3] - _m[1] * _m[2]))


def rotation():
    return math.atan2(_m[1], _m[0])


# ---------------------------------------------------------------- state
def _c255(v):
    v = int(v * 255 + 0.5)
    return 0 if v < 0 else (255 if v > 255 else v)


def set_color(r, g=None, b=None, a=1.0):
    global _col
    if g is None:  # a tuple/list was passed
        t = r
        r, g, b = t[0], t[1], t[2]
        a = t[3] if len(t) > 3 else 1.0
    _col = (_c255(r), _c255(g), _c255(b), _c255(a))


def get_color():
    return _col


def set_line_width(w):
    global _lw
    _lw = w


def set_blend(mode):
    global _blend
    _blend = mode


def _lwidth():
    return max(1, int(round(_lw * uniform_scale())))


# ---------------------------------------------------------------- painting core
def _paint(painter, x0, y0, x1, y1):
    """painter(surface, ox, oy, color) draws with coordinates offset by (ox, oy)."""
    r, g, b, a = _col
    if a <= 0:
        return
    if _blend == "alpha" and a >= 255:
        painter(_target, 0, 0, (r, g, b))
        return
    tw, th = _target.get_size()
    ix0 = max(0, int(math.floor(x0)) - 2)
    iy0 = max(0, int(math.floor(y0)) - 2)
    ix1 = min(tw, int(math.ceil(x1)) + 2)
    iy1 = min(th, int(math.ceil(y1)) + 2)
    if ix1 <= ix0 or iy1 <= iy0:
        return
    w, h = ix1 - ix0, iy1 - iy0
    if _blend == "add":
        tmp = pygame.Surface((w, h))
        tmp.fill((0, 0, 0))
        k = a / 255.0
        painter(tmp, -ix0, -iy0, (int(r * k), int(g * k), int(b * k)))
        _target.blit(tmp, (ix0, iy0), special_flags=pygame.BLEND_RGB_ADD)
    else:
        tmp = pygame.Surface((w, h), pygame.SRCALPHA)
        painter(tmp, -ix0, -iy0, (r, g, b, a))
        _target.blit(tmp, (ix0, iy0))


def _bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _flat_to_pts(args):
    if len(args) == 1:
        args = args[0]
    if len(args) and isinstance(args[0], (tuple, list)):
        return [tuple(p) for p in args]
    return [(args[i], args[i + 1]) for i in range(0, len(args) - 1, 2)]


def polygon(mode, *args):
    pts = [tp(x, y) for x, y in _flat_to_pts(args)]
    if len(pts) < 3:
        return
    x0, y0, x1, y1 = _bbox(pts)
    lw = 0 if mode == "fill" else _lwidth()

    def p(s, ox, oy, c):
        q = [(x + ox, y + oy) for x, y in pts]
        pygame.draw.polygon(s, c, q, lw)
    _paint(p, x0 - lw, y0 - lw, x1 + lw, y1 + lw)


def line(*args):
    pts = [tp(x, y) for x, y in _flat_to_pts(args)]
    if len(pts) < 2:
        return
    lw = _lwidth()
    x0, y0, x1, y1 = _bbox(pts)

    def p(s, ox, oy, c):
        q = [(x + ox, y + oy) for x, y in pts]
        if lw <= 1:
            pygame.draw.lines(s, c, False, q, 1)
        else:
            pygame.draw.lines(s, c, False, q, lw)
            for pt in q:  # round joints
                pygame.draw.circle(s, c, (int(pt[0]), int(pt[1])), max(1, lw // 2))
    _paint(p, x0 - lw, y0 - lw, x1 + lw, y1 + lw)


def rectangle(mode, x, y, w, h, rx=None, ry=None):
    if _axis_aligned():
        X0, Y0 = tp(x, y)
        X1, Y1 = tp(x + w, y + h)
        if X1 < X0:
            X0, X1 = X1, X0
        if Y1 < Y0:
            Y0, Y1 = Y1, Y0
        rad = int(rx * min(abs(_m[0]), abs(_m[3]))) if rx else 0
        lw = 0 if mode == "fill" else _lwidth()
        if mode == "fill" and rad == 0 and _blend == "alpha" and 0 < _col[3] < 255:
            # translucent plain rectangle: blit a cached solid surface with surface alpha (much faster)
            iw, ih = max(1, int(round(X1 - X0))), max(1, int(round(Y1 - Y0)))
            if iw * ih >= 4000:
                key = (iw, ih, _col)
                sf = _rect_cache.get(key)
                if sf is None:
                    if len(_rect_cache) > 40:
                        _rect_cache.clear()
                    sf = pygame.Surface((iw, ih))
                    sf.fill(_col[:3])
                    sf.set_alpha(_col[3])
                    _rect_cache[key] = sf
                _target.blit(sf, (int(round(X0)), int(round(Y0))))
                return

        def p(s, ox, oy, c):
            r = pygame.Rect(int(round(X0 + ox)), int(round(Y0 + oy)), max(1, int(round(X1 - X0))), max(1, int(round(Y1 - Y0))))
            pygame.draw.rect(s, c, r, lw, border_radius=rad)
        _paint(p, X0 - lw, Y0 - lw, X1 + lw, Y1 + lw)
    else:
        polygon(mode, x, y, x + w, y, x + w, y + h, x, y + h)


_rect_cache = {}


def _ellipse_pts(cx, cy, rx, ry, n=28):
    return [(cx + math.cos(i / n * math.tau) * rx, cy + math.sin(i / n * math.tau) * ry) for i in range(n)]


def ellipse(mode, x, y, rx, ry, segs=None):
    if _axis_aligned():
        X, Y = tp(x, y)
        RX, RY = abs(rx * _m[0]), abs(ry * _m[3])
        lw = 0 if mode == "fill" else _lwidth()

        def p(s, ox, oy, c):
            r = pygame.Rect(int(round(X - RX + ox)), int(round(Y - RY + oy)), max(1, int(round(RX * 2))), max(1, int(round(RY * 2))))
            pygame.draw.ellipse(s, c, r, lw)
        _paint(p, X - RX - lw, Y - RY - lw, X + RX + lw, Y + RY + lw)
    else:
        polygon(mode, _ellipse_pts(x, y, rx, ry))


def circle(mode, x, y, r, segs=None):
    sx, sy = _sx(), _sy()
    if abs(sx - sy) <= 0.02 * max(sx, sy, 1e-6):
        X, Y = tp(x, y)
        R = r * sx
        if R < 0.5:
            return
        lw = 0 if mode == "fill" else _lwidth()

        def p(s, ox, oy, c):
            pygame.draw.circle(s, c, (int(round(X + ox)), int(round(Y + oy))), max(1, int(round(R))), lw)
        _paint(p, X - R - lw, Y - R - lw, X + R + lw, Y + R + lw)
    else:
        ellipse(mode, x, y, r, r)


def arc(mode, *args):
    if isinstance(args[0], str):
        arctype = args[0]
        args = args[1:]
    else:
        arctype = "pie"
    x, y, r, a1, a2 = args[:5]
    n = max(6, int(abs(a2 - a1) / (math.pi * 2) * 40))
    pts = [(x + math.cos(a1 + (a2 - a1) * i / n) * r, y + math.sin(a1 + (a2 - a1) * i / n) * r) for i in range(n + 1)]
    if mode == "fill":
        if arctype == "pie":
            polygon("fill", [(x, y)] + pts)
        else:
            polygon("fill", pts)
    else:
        if arctype == "pie":
            line([(x, y)] + pts + [(x, y)])
        elif arctype == "closed":
            line(pts + [pts[0]])
        else:
            line(pts)


# ---------------------------------------------------------------- images / text
def draw_surface(surf, x, y, sx=1.0, sy=None, centered=False):
    """Blit a pygame surface at (x, y) through the current transform (scale + rotation supported)."""
    if sy is None:
        sy = sx
    w, h = surf.get_size()
    us = uniform_scale()
    rot = rotation()
    kx, ky = sx * _sx(), sy * _sy()
    if centered:
        cx, cy = tp(x, y)
    else:
        cx, cy = tp(x + w * sx / 2, y + h * sy / 2)
    if abs(rot) < 1e-3 and abs(kx - 1) < 1e-3 and abs(ky - 1) < 1e-3:
        s2 = surf
    elif abs(rot) < 1e-3:
        nw, nh = max(1, int(w * kx)), max(1, int(h * ky))
        s2 = pygame.transform.smoothscale(surf, (nw, nh)) if surf.get_bitsize() >= 24 else pygame.transform.scale(surf, (nw, nh))
    else:
        if abs(kx - ky) > 1e-3:
            surf = pygame.transform.smoothscale(surf, (max(1, int(w * kx / max(us, 1e-6))), max(1, int(h * ky / max(us, 1e-6)))))
        s2 = pygame.transform.rotozoom(surf, -math.degrees(rot), us)
    r, g, b, a = _col
    if a < 255:
        s2 = s2.copy()
        s2.set_alpha(a)
    if _blend == "add":
        _target.blit(s2, (int(cx - s2.get_width() / 2), int(cy - s2.get_height() / 2)), special_flags=pygame.BLEND_RGB_ADD)
    else:
        _target.blit(s2, (int(cx - s2.get_width() / 2), int(cy - s2.get_height() / 2)))


def clear(r=0, g=0, b=0):
    _target.fill((_c255(r), _c255(g), _c255(b)))


# -------- fonts
class Font:
    def __init__(self, path, size):
        self.path = path
        self.size = size
        self.f = pygame.font.Font(path, size)
        self.h = self.f.get_height()
        self._wcache = {}

    def getWidth(self, s):
        w = self._wcache.get(s)
        if w is None:
            w = self.f.size(s)[0]
            if len(self._wcache) > 2000:
                self._wcache.clear()
            self._wcache[s] = w
        return w

    def getHeight(self):
        return self.h


def set_font(f):
    global _font
    _font = f


_tcache = {}


def text_surface(s, font, rgb, outline=0, olc=(26, 8, 13)):
    key = (s, id(font), rgb, outline, olc)
    surf = _tcache.get(key)
    if surf is not None:
        return surf
    main = font.f.render(s, True, rgb)
    if outline > 0:
        o = font.f.render(s, True, olc)
        w, h = main.get_size()
        surf = pygame.Surface((w + outline * 2, h + outline * 2), pygame.SRCALPHA)
        for dx in (-outline, 0, outline):
            for dy in (-outline, 0, outline):
                if dx or dy:
                    surf.blit(o, (outline + dx, outline + dy))
        surf.blit(main, (outline, outline))
        surf = finalize(surf)
    else:
        surf = finalize(main.convert_alpha()) if pygame.display.get_surface() else main
    if len(_tcache) > 1500:
        _tcache.clear()
    _tcache[key] = surf
    return surf


def printf(s, x, y, limit=None, align="left"):
    """Print one line with the current font/colour through the transform."""
    if not s:
        return
    r, g, b, a = _col
    surf = text_surface(s, _font, (r, g, b))
    w = surf.get_width()
    if limit is not None and align == "center":
        x = x + (limit - w) / 2
    elif limit is not None and align == "right":
        x = x + limit - w
    draw_surface(surf, x, y)


def print_(s, x, y):
    printf(s, x, y)
