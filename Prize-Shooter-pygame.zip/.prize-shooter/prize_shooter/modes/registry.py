"""Stand registry (port of modes/list.lua)."""
MODES = [
    {"id": "stars", "color": (0.15, 0.45, 0.95)},
    {"id": "shark", "color": (0.13, 0.55, 0.55)},
    {"id": "ducks", "color": (0.95, 0.65, 0.1)},
    {"id": "rails", "color": (0.86, 0.12, 0.14)},
    {"id": "cans", "color": (0.45, 0.47, 0.55)},
    {"id": "hearts", "color": (0.85, 0.2, 0.45)},
    {"id": "pyramid", "color": (0.8, 0.55, 0.2)},
    {"id": "balloons", "color": (0.25, 0.4, 0.8)},
]


def find(id_):
    for m in MODES:
        if m["id"] == id_:
            return m
    return MODES[0]


def module(id_):
    from . import stars, shark, ducks, rails, cans, hearts, pyramid, balloons
    return {"stars": stars, "shark": shark, "ducks": ducks, "rails": rails, "cans": cans,
            "hearts": hearts, "pyramid": pyramid, "balloons": balloons}[id_]
