"""PYRAMID SHOOTING: shoot a 15-block pyramid down from the top, layer by layer. Lower layers too early = penalty."""
import math
import random
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, floor = math.sin, math.floor

BW, BH = 76, 58
TABLE_Y = 560
COLORS = [(0.9, 0.25, 0.2), (0.2, 0.55, 0.9), (0.3, 0.75, 0.35), (0.95, 0.7, 0.15), (0.7, 0.35, 0.85)]
_blocks = {}


def rand(a, b):
    return a + random.random() * (b - a)


def block_sprite(b):
    key = (b["gold"], b["col"], b["num"])
    surf = _blocks.get(key)
    if surf is None:
        surf = pygame.Surface((BW + 12, BH + 12), pygame.SRCALPHA)
        lg.push_target(surf); lg.push(); lg.origin(); lg.translate((BW + 12) / 2, (BH + 12) / 2 - 2)
        lg.set_color(0, 0, 0, 0.25); lg.rectangle("fill", -BW / 2 + 4, -BH / 2 + 5, BW, BH, 6)
        if b["gold"]:
            lg.set_color(1, 0.8, 0.25)
        else:
            lg.set_color(0.86, 0.68, 0.45)
        lg.rectangle("fill", -BW / 2, -BH / 2, BW, BH, 6)
        lg.set_color(1, 1, 1, 0.25); lg.rectangle("fill", -BW / 2 + 4, -BH / 2 + 4, BW - 8, 8, 4)
        lg.set_color(0.6, 0.42, 0.25, 0.5); lg.set_line_width(1)
        lg.line(-BW / 2 + 8, -6, BW / 2 - 8, -4); lg.line(-BW / 2 + 10, 10, BW / 2 - 12, 12)
        G.col(G.C["red"] if b["gold"] else b["col"]); lg.circle("fill", 0, 0, 17)
        G.text("$" if b["gold"] else str(b["num"]), 0, -15, G.F["ui26"], G.C["white"], 40, 1)
        lg.pop(); lg.pop_target()
        _blocks[key] = surf
    return surf


def block(x, y, b, rot=0, s=1, glow=False):
    lg.push(); lg.translate(x, y + 2); lg.rotate(rot)
    lg.set_color(1, 1, 1)
    lg.draw_surface(block_sprite(b), 0, 0, s, s, True)
    lg.pop()
    if glow:
        lg.set_color(1, 1, 0.6, 0.35 + 0.25 * sin(G.T * 6)); lg.set_line_width(3)
        lg.rectangle("line", x - BW / 2 - 2, y - BH / 2 - 2, BW + 4, BH + 4, 7)


def _paint_bg():
    lg.set_color(0.86, 0.66, 0.38); lg.rectangle("fill", 0, 0, G.W, G.H)
    for i in range(13):
        lg.set_color(0.8, 0.6, 0.34); lg.rectangle("fill", 80, 150 + i * 40, 1120, 2)
        for j in range(23):
            lg.rectangle("fill", 80 + j * 52 + (i % 2) * 26, 150 + i * 40, 2, 40)
    lg.set_color(0.98, 0.85, 0.4); lg.circle("fill", 1050, 230, 46)
    lg.set_color(0.7, 0.52, 0.28)
    lg.polygon("fill", 120, 600, 260, 380, 400, 600); lg.polygon("fill", 880, 600, 1000, 420, 1120, 600)
    lg.set_color(0.6, 0.44, 0.22)
    lg.polygon("fill", 260, 380, 400, 600, 300, 600); lg.polygon("fill", 1000, 420, 1120, 600, 1040, 600)


class Pyramid:
    def __init__(self):
        self.time, self.mag = 60, 8
        self.t = self.elapsed = 0.0
        self.round = 0
        self.stats = {"blocks": 0, "pyramids": 0, "early": 0, "perfect": 0}
        self.bonus = None
        self.finished = False
        self.flying = []
        self.build()

    def build(self):
        self.round += 1
        self.blocks = []
        self.pyrShots, self.pyrEarly = 0, 0
        self.cleared = None
        self.wob = 0.0
        goldRow = random.randint(1, 5) if self.round >= 2 else None
        for layer, n in enumerate([5, 4, 3, 2, 1], 1):
            for i in range(1, n + 1):
                self.blocks.append({"layer": layer, "ox": (i - (n + 1) / 2) * (BW + 4), "oy": -(layer - 0.5) * (BH + 2),
                                    "alive": True, "col": COLORS[(layer + i) % 5], "num": 6 - layer,
                                    "gold": goldRow == layer and i == math.ceil(n / 2),
                                    "pop": -(layer * 0.12 + i * 0.04), "shake": 0.0})
        self.moveAmp = min(260, 120 + (self.round - 2) * 50) if self.round >= 2 else 0

    def base(self):
        x = 640 + sin(self.t * (0.6 + self.round * 0.08)) * self.moveAmp
        y = TABLE_Y + (sin(self.t * 1.3) * 18 if self.round >= 3 else 0)
        return x, y

    def topLayer(self):
        return max([b["layer"] for b in self.blocks if b["alive"]] or [0])

    def blockPos(self, b):
        bx, by = self.base()
        w = sin(self.t * 30) * b["shake"] * 5 + sin(self.t * 12) * self.wob * (b["layer"] * 1.5)
        return bx + b["ox"] + w, by + b["oy"]

    def update(self, dt, active):
        self.t += dt
        if active:
            self.elapsed += dt
        self.wob = max(0.0, self.wob - dt * 2)
        for b in self.blocks:
            if b["pop"] < 1:
                b["pop"] = min(1.0, b["pop"] + dt * 5)
            b["shake"] = max(0.0, b["shake"] - dt * 3)
        keep = []
        for f in self.flying:
            f["t"] += dt
            f["vy"] += 1500 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["y"] <= 820:
                keep.append(f)
        self.flying = keep
        if self.cleared is not None:
            self.cleared += dt
            if self.cleared > 1.8:
                self.build()

    def shoot(self, x, y):
        if self.cleared is not None:
            return None
        self.pyrShots += 1
        R = G.hitR
        top = self.topLayer()
        for b in self.blocks:
            if b["alive"] and b["pop"] >= 1:
                bx, by = self.blockPos(b)
                if abs(x - bx) < BW / 2 * R and abs(y - by) < BH / 2 * R:
                    if b["layer"] < top and not G.kids:
                        b["shake"] = 1.0
                        self.wob = 1.0
                        self.stats["early"] += 1
                        self.pyrEarly += 1
                        A.play("wood", 0.9, 0.7)
                        A.play("buzzer", 0.25, 2)
                        return {"pts": -50, "penalty": True, "label": T("too_early"), "x": bx, "y": by - 40}
                    b["alive"] = False
                    self.stats["blocks"] += 1
                    self.flying.append({"x": bx, "y": by, "vx": (bx - x) * 5 + rand(-150, 150), "vy": rand(-560, -380),
                                        "rot": 0.0, "vr": rand(-10, 10), "t": 0.0, "b": b})
                    G.FX.burst(x, y, 10, [(0.85, 0.65, 0.4), b["col"]], 260)
                    A.play("wood", 1, 0.9 + random.random() * 0.3)
                    pts = 100 if b["layer"] == 5 else 60
                    label, big, color = None, False, None
                    if b["gold"]:
                        pts, label, big, color = 250, T("golden_block"), True, G.C["gold"]
                        A.play("gold", 0.8)
                    if self.topLayer() == 0:
                        self.stats["pyramids"] += 1
                        if self.pyrShots <= 15 and self.pyrEarly == 0:
                            self.stats["perfect"] += 1
                        self.cleared = 0.0
                        bonus = 400 * self.round
                        self.bonus = [{"pts": bonus, "label": T("pyramid_down", bonus), "x": 640, "y": 300}]
                        A.play("bell", 0.9)
                        A.play("clatter", 0.6, 0.7)
                        G.FX.burst(640, 420, 70, None, 600)
                    return {"pts": pts, "label": label, "big": big, "color": color or G.C["cream"], "x": bx, "y": by - 36}
        return None

    def demoTarget(self):
        top = self.topLayer()
        for b in self.blocks:
            if b["alive"] and b["layer"] == top and b["pop"] >= 1:
                return self.blockPos(b)
        return 640, 400

    def draw(self):
        G.blit_cached("pyramid_bg", _paint_bg)
        bx, by = self.base()
        lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", bx - 230, by + 8, 470, 18)
        lg.set_color(0.45, 0.26, 0.14); lg.rectangle("fill", bx - 235, by, 470, 18, 4)
        G.col(G.C["red"]); lg.rectangle("fill", bx - 235, by + 14, 470, 4)
        lg.set_color(0.3, 0.18, 0.1); lg.rectangle("fill", bx - 12, by + 18, 24, 80)
        top = self.topLayer()
        for b in self.blocks:
            if b["alive"] and b["pop"] > 0:
                x, y = self.blockPos(b)
                s = b["pop"] * (1.25 - 0.25 * b["pop"]) if b["pop"] < 1 else 1
                block(x, y, b, 0, s, b["layer"] == top and self.cleared is None)
        for f in self.flying:
            block(f["x"], f["y"], f["b"], f["rot"], max(0.4, 1 - f["t"] * 0.6))
        G.text(T("pyramid_info", self.round), 640, 592, G.F["ui20"], G.C["darkred"], 600, 0)


def new():
    return Pyramid()
