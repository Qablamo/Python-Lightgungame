"""RAIL RUNNERS: red bullseye targets riding brass rails. Bullseye 100, middle 50, outer 25; pop-ups pay double."""
import math
import random
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, floor, sqrt, pi = math.sin, math.floor, math.sqrt, math.pi
PRIZES = [2000, 5000, 9000, 14000]

HRAILS = [205, 335, 465]
VRAILS = [150, 1130]
HX0, HX1 = 250, 1030
VY0, VY1 = 230, 520


def rand(a, b):
    return a + random.random() * (b - a)


def updateFlip(tg, dt):
    if tg["down"] > 0:
        tg["flip"] = max(-1.0, tg["flip"] - dt * 10)
        tg["down"] -= dt
        if tg["down"] <= 0:
            tg["down"] = 0
    elif tg["flip"] < 1:
        tg["flip"] = min(1.0, tg["flip"] + dt * 7)


def targetDisc(px, py, r, flip):
    if flip >= 0:
        G.bullseye(px, py, r, max(0.05, flip))
    else:
        lg.push(); lg.translate(px, py); lg.scale(1, max(0.05, -flip))
        lg.set_color(0.45, 0.45, 0.5); lg.circle("fill", 0, 0, r)
        lg.set_color(0.3, 0.3, 0.35); lg.set_line_width(3); lg.circle("line", 0, 0, r * 0.7)
        lg.pop()


def _paint_bg():
    lg.set_color(0.42, 0.12, 0.1); lg.rectangle("fill", 0, 0, G.W, G.H)
    for i in range(13):
        lg.set_color(0.36 + (i % 2) * 0.04, 0.1, 0.08)
        lg.rectangle("fill", 80, 140 + i * 40, 1120, 38)
        lg.set_color(0.6, 0.45, 0.25)
        lg.circle("fill", 100 + (i * 173) % 1080, 160 + i * 40, 3)
    G.text(T("saloon"), 640, 588, G.F["sign26"], (0.95, 0.75, 0.3, 0.5), 600, 0)
    for vx in VRAILS:
        lg.set_color(0.25, 0.15, 0.08); lg.rectangle("fill", vx - 10, VY0 - 50, 20, VY1 - VY0 + 100)
        lg.set_color(0.85, 0.68, 0.3); lg.rectangle("fill", vx - 4, VY0 - 50, 8, VY1 - VY0 + 100)
    for ry in HRAILS:
        lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", 200, ry + 4, 880, 10)
        lg.set_color(0.85, 0.68, 0.3); lg.rectangle("fill", 200, ry - 4, 880, 10, 4)
        lg.set_color(1, 0.9, 0.6, 0.6); lg.rectangle("fill", 200, ry - 3, 880, 3)
        for ex in (200, 1080):
            lg.set_color(0.25, 0.15, 0.08); lg.rectangle("fill", ex - 8, ry - 16, 16, 34, 3)


class Rails:
    def __init__(self):
        self.time, self.mag = 60, 8
        self.t = self.elapsed = 0.0
        self.stats = {"bulls": 0, "pops": 0, "bombs": 0}
        self.bonus = None
        self.finished = False
        self.targets = []
        for ri, ry in enumerate(HRAILS, 1):
            for k in (1, 2):
                d = 1 if (ri + k) % 2 == 0 else -1
                self.targets.append({"kind": "h", "ry": ry, "x": HX0 + (k - 0.5) / 2 * (HX1 - HX0) + rand(-60, 60),
                                     "v": d * rand(140, 230), "r": 40, "flip": 1.0, "down": 0})
        for i, vx in enumerate(VRAILS, 1):
            self.targets.append({"kind": "v", "rx": vx, "y": rand(VY0, VY1), "v": (1 if i == 1 else -1) * rand(120, 170),
                                 "r": 36, "flip": 1.0, "down": 0})
        self.pops = []
        self.popTimer = 2.5

    def mul(self):
        return 1 + self.elapsed / 45

    def targetPos(self, tg):
        if tg["kind"] == "h":
            return tg["x"], tg["ry"] + 62
        if tg["kind"] == "v":
            return tg["rx"] + (62 if tg["rx"] < 640 else -62), tg["y"]
        return tg["x"], tg["y"]

    def update(self, dt, active):
        self.t += dt
        if active:
            self.elapsed += dt
        mul = self.mul()
        for tg in self.targets:
            if tg["kind"] == "h":
                tg["x"] += tg["v"] * mul * dt
                if tg["x"] < HX0:
                    tg["x"], tg["v"] = HX0, abs(tg["v"])
                if tg["x"] > HX1:
                    tg["x"], tg["v"] = HX1, -abs(tg["v"])
            else:
                tg["y"] += tg["v"] * mul * dt
                if tg["y"] < VY0:
                    tg["y"], tg["v"] = VY0, abs(tg["v"])
                if tg["y"] > VY1:
                    tg["y"], tg["v"] = VY1, -abs(tg["v"])
            updateFlip(tg, dt)
        n = len(self.targets)
        for i in range(n):
            a = self.targets[i]
            for j in range(i + 1, n):
                b = self.targets[j]
                if a["kind"] == "h" and b["kind"] == "h" and a["ry"] == b["ry"] and abs(a["x"] - b["x"]) < 90:
                    if (a["x"] < b["x"] and a["v"] > b["v"]) or (a["x"] > b["x"] and a["v"] < b["v"]):
                        if a["x"] < b["x"]:
                            a["v"], b["v"] = -abs(a["v"]), abs(b["v"])
                        else:
                            a["v"], b["v"] = abs(a["v"]), -abs(b["v"])
                        A.play("tick", 0.25, 0.7)
        if active:
            self.popTimer -= dt
            if self.popTimer <= 0:
                self.popTimer = rand(2.4, 3.6) / mul
                self.pops.append({"kind": "pop", "x": rand(260, 1020), "y": 690.0, "t": 0.0,
                                  "stay": rand(1.1, 1.6) / sqrt(mul), "r": 32, "flip": 1.0, "down": 0, "hitDone": False,
                                  "bomb": (not G.kids) and random.random() < 0.3})
                A.play("blip", 0.5, 0.8)
        keep = []
        for p in self.pops:
            p["t"] += dt
            top = 560
            if p["t"] < 0.25:
                p["y"] = 690 - (690 - top) * (p["t"] / 0.25)
            elif p["t"] < 0.25 + p["stay"] and not p["hitDone"]:
                p["y"] = top + sin(p["t"] * 8) * 3
            else:
                p["y"] += 600 * dt
                if p["y"] > 720:
                    continue
            if p["down"] > 0:
                p["flip"] = max(-1.0, p["flip"] - dt * 10)
                p["down"] -= dt
            keep.append(p)
        self.pops = keep

    def hit(self, tg, x, y, px, py):
        d = sqrt((x - px) ** 2 + (y - py) ** 2) / tg["r"] / G.hitR
        if d > 1.08:
            return None
        if tg.get("bomb"):
            tg["hitDone"] = True
            tg["down"] = 2.2
            self.stats["bombs"] += 1
            A.play("boom", 1)
            G.FX.addShake(16)
            G.FX.burst(px, py, 45, [G.C["orange"], G.C["yellow"], (0.2, 0.2, 0.2)], 520)
            return {"pts": -200, "penalty": True, "label": T("boom"), "x": px, "y": py - tg["r"]}
        label, big = None, False
        if d < 0.22:
            self.stats["bulls"] += 1
            pts, label, big = 100, T("bullseye"), True
            A.play("ding", 0.8)
            G.FX.burst(px, py, 30, None, 380)
        elif d < 0.6:
            pts = 50
        else:
            pts = 25
        if tg["kind"] == "pop":
            pts *= 2
            tg["hitDone"] = True
            self.stats["pops"] += 1
        if tg["kind"] == "v":
            pts = floor(pts * 1.5)
        A.play("clang", 0.8, 0.9 + random.random() * 0.25)
        G.FX.ring(px, py, G.C["white"], tg["r"] * 1.3)
        G.FX.burst(x, y, 8, [(0.9, 0.85, 0.75), G.C["red"]], 200)
        tg["down"] = 2.2
        return {"pts": pts, "label": label, "big": big, "color": G.C["yellow"] if big else G.C["cream"], "x": px, "y": py - tg["r"]}

    def shoot(self, x, y):
        for p in self.pops:
            if p["flip"] > 0 and p["down"] <= 0:
                r = self.hit(p, x, y, p["x"], p["y"])
                if r:
                    return r
        for tg in self.targets:
            if tg["down"] <= 0 and tg["flip"] > 0.5:
                px, py = self.targetPos(tg)
                r = self.hit(tg, x, y, px, py)
                if r:
                    return r
        return None

    def draw(self):
        G.blit_cached("rails_bg", _paint_bg)
        for tg in self.targets:
            px, py = self.targetPos(tg)
            lg.set_color(0.2, 0.2, 0.22)
            if tg["kind"] == "h":
                lg.rectangle("fill", px - 20, tg["ry"] - 12, 40, 18, 4)
                lg.set_color(0.6, 0.6, 0.65); lg.circle("fill", px - 11, tg["ry"] - 6, 5); lg.circle("fill", px + 11, tg["ry"] - 6, 5)
                lg.set_color(0.3, 0.3, 0.32); lg.rectangle("fill", px - 3, tg["ry"] + 6, 6, 18)
            else:
                lg.rectangle("fill", tg["rx"] - 14, py - 20, 28, 40, 4)
                lg.set_color(0.3, 0.3, 0.32); lg.rectangle("fill", min(tg["rx"], px), py - 3, abs(px - tg["rx"]), 6)
            targetDisc(px, py, tg["r"], tg["flip"])
        for p in self.pops:
            lg.set_color(0.3, 0.3, 0.32); lg.rectangle("fill", p["x"] - 4, p["y"], 8, 120)
            if p.get("bomb") and p["flip"] > 0:
                lg.push(); lg.translate(p["x"], p["y"]); lg.scale(1, max(0.05, p["flip"]))
                lg.set_color(0.95, 0.85, 0.2); lg.circle("fill", 0, 0, p["r"])
                lg.set_color(0.1, 0.1, 0.1)
                for k in range(8):   # black/yellow hazard ring
                    a = k * pi / 4
                    lg.arc("fill", 0, 0, p["r"], a, a + pi / 8)
                lg.set_color(0.95, 0.85, 0.2); lg.circle("fill", 0, 0, p["r"] * 0.72)
                lg.pop()
                G.bombIcon(p["x"], p["y"] + 4, 12, self.t + p["x"])
            else:
                targetDisc(p["x"], p["y"], p["r"], p["flip"])
            if p["flip"] > 0 and not p.get("bomb"):
                lg.set_color(1, 1, 0.5, 0.5 + 0.5 * sin(self.t * 14)); lg.set_line_width(3); lg.circle("line", p["x"], p["y"], p["r"] + 6)

    def demoTarget(self):
        for p in self.pops:
            if p["flip"] > 0 and p["down"] <= 0 and p["t"] > 0.25 and not p.get("bomb"):
                return p["x"], p["y"]
        for tg in self.targets:
            if tg["down"] <= 0 and tg["flip"] > 0.5:
                return self.targetPos(tg)
        return 640, 400


def new():
    return Rails()
