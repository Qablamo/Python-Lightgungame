"""TIN CAN ALLEY: knock all 10 cans off the shelf.

The LÖVE version uses Box2D. Pygame has no physics engine on Batocera, so this is a small
purpose-built simulation: upright cans rest on whatever is under them (shelf or other cans);
a can whose centre is no longer above its support tips over and tumbles with gravity,
bounces on the shelf / floor, and can knock over other cans it crashes into.
The FOTO target on the wall takes a souvenir photo (saved to the save folder).
"""
import math
import random
import time
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import game as Game
from ..lang import T
from . import canphys as P

sin, cos, pi, floor, sqrt = math.sin, math.cos, math.pi, math.floor, math.sqrt
PRIZES = [1800, 4500, 8000, 12500]

CW, CH = 56, 74
HW, HH = CW / 2, CH / 2
SHELF_Y, SHELF_W, SHELF_H = 525, 600, 20
FLOOR_Y = 622
GRAV = 9.81 * 64 * 1.4
LABELS = [G.C["red"], G.C["blue"], G.C["green"], G.C["orange"], G.C["purple"]]
FOTO_X, FOTO_Y = 190, 300

LAYOUTS = [
    {"name": "stack_1", "rows": [4, 3, 2, 1]},
    {"name": "stack_2", "rows": [4, 3, 2, 1], "move": 70},
    {"name": "stack_3", "rows": [4, 4, 2]},
    {"name": "stack_4", "rows": [4, 3, 2, 1], "move": 110, "gold": True},
    {"name": "stack_5", "rows": [3, 3, 3, 1], "move": 60, "gold": True},
]
_sprites = {}


def rand(a, b):
    return a + random.random() * (b - a)


def can_sprite(label, gold):
    key = (tuple(label), gold)
    s = _sprites.get(key)
    if s is not None:
        return s
    s = pygame.Surface((CW + 12, CH + 12), pygame.SRCALPHA)
    lg.push_target(s); lg.push(); lg.origin(); lg.translate((CW + 12) / 2 - 2, (CH + 12) / 2 - 2)
    lg.set_color(0, 0, 0, 0.25); lg.rectangle("fill", -HW + 4, -HH + 5, CW, CH, 5)
    if gold:
        lg.set_color(0.95, 0.75, 0.2)
    else:
        lg.set_color(0.76, 0.78, 0.82)
    lg.rectangle("fill", -HW, -HH, CW, CH, 5)
    if gold:
        lg.set_color(1, 0.9, 0.45)
    else:
        G.col(label)
    lg.rectangle("fill", -HW, -HH + 16, CW, CH - 32)
    if not gold:
        lg.set_color(1, 1, 1, 0.85)
        lg.rectangle("fill", -HW, -4, CW, 8)
        G.star(0, 0, 9, G.C["yellow"], 0)
    else:
        G.text("$", 0, -11, G.F["ui16"], (0.6, 0.4, 0.05), CW, 0)
    if gold:
        lg.set_color(0.7, 0.5, 0.1)
    else:
        lg.set_color(0.5, 0.52, 0.56)
    for ry in (-HH, -HH + 5, HH - 5, HH - 3):
        lg.rectangle("fill", -HW, ry, CW, 3)
    lg.set_color(1, 1, 1, 0.45); lg.rectangle("fill", -HW + 7, -HH + 3, 6, CH - 6, 3)
    lg.set_color(0, 0, 0, 0.12); lg.rectangle("fill", HW - 10, -HH + 3, 8, CH - 6, 3)
    lg.pop(); lg.pop_target()
    _sprites[key] = s
    return s


def drawCan(x, y, ang, label, gold, s=1.0):
    lg.push(); lg.translate(x, y); lg.rotate(ang)
    lg.set_color(1, 1, 1)
    lg.draw_surface(can_sprite(label, gold), 2, 2, s, s, True)
    lg.pop()


def corners(c):
    co, si = cos(c["a"]), sin(c["a"])
    out = []
    for dx, dy in ((-HW, -HH), (HW, -HH), (HW, HH), (-HW, HH)):
        out.append((c["x"] + dx * co - dy * si, c["y"] + dx * si + dy * co))
    return out


def point_in_can(c, px, py):
    dx, dy = px - c["x"], py - c["y"]
    co, si = cos(-c["a"]), sin(-c["a"])
    lx, ly = dx * co - dy * si, dx * si + dy * co
    return abs(lx) <= HW and abs(ly) <= HH


def _paint_bg():
    lg.set_color(0.28, 0.16, 0.12); lg.rectangle("fill", 0, 0, G.W, G.H)
    for i in range(23):
        lg.set_color(0.32 + (i % 3) * 0.02, 0.18 + (i % 2) * 0.015, 0.12)
        lg.rectangle("fill", 80 + i * 52, 140, 50, 500)
    lg.set_blend("add")
    for r in range(6, 0, -1):
        lg.set_color(1, 0.85, 0.5, 0.025)
        lg.ellipse("fill", 640, 360, 120 + r * 50, 90 + r * 45)
    lg.set_blend("alpha")
    fx, fy = FOTO_X, FOTO_Y
    lg.set_color(0.95, 0.95, 0.92); lg.rectangle("fill", fx - 55, fy - 75, 110, 150, 4)
    lg.set_color(0.08, 0.08, 0.1)
    lg.circle("fill", fx, fy - 30, 18)
    lg.polygon("fill", fx - 40, fy + 70, fx - 30, fy, fx + 30, fy, fx + 40, fy + 70)
    for r in (34, 23, 12):
        lg.set_color(1, 1, 1, 0.9); lg.set_line_width(2); lg.circle("line", fx, fy, r)
    lg.set_color(0.9, 0.1, 0.15); lg.circle("fill", fx, fy, 6)
    lg.set_color(0.6, 0.6, 0.65); lg.rectangle("fill", fx - 3, fy - 80, 6, 6)
    lg.set_color(0.2, 0.12, 0.08); lg.rectangle("fill", 80, FLOOR_Y, 1120, 20)


class Cans:
    def __init__(self):
        self.time, self.mag = 75, 6
        self.t = 0.0
        self.round = 0
        self.flying = []
        self.photos = 0
        self.stats = {"stacks": 0, "photos": 0, "bestStack": 999}
        self.bonus = None
        self.finished = False
        self.fotoCool = 0.0
        self.flash = 0.0
        self.flashDelay = None
        self.polaroid = None
        self.clinkCool = 0.0
        self.buildStack()

    # ------------------------------------------------------------------ setup
    def buildStack(self):
        self.round += 1
        L = LAYOUTS[(self.round - 1) % len(LAYOUTS)]
        self.layout = L
        self.speed = 1 + ((self.round - 1) // len(LAYOUTS)) * 0.4
        self.shelfX = 640.0
        self.shelfV = 0.0
        self.shelfT = 0.0
        self.world = P.World(GRAV, 8)
        self.floor = P.Body(640, FLOOR_Y + 100, 800, 100, 0, friction=0.8)
        self.wallL = P.Body(80 - 100, 300, 100, 600, 0)
        self.wallR = P.Body(1200 + 100, 300, 100, 600, 0)
        self.shelfBody = P.Body(640, SHELF_Y + SHELF_H / 2, SHELF_W / 2, SHELF_H / 2, 0, friction=0.9)
        self.cans = []
        y = SHELF_Y - HH
        nrows = len(L["rows"])
        for r, n in enumerate(L["rows"], 1):
            wrow = n * (CW + 2)
            for i in range(1, n + 1):
                x = 640 - wrow / 2 + (i - 0.5) * (CW + 2)
                self.cans.append({"x": x, "y": y, "a": 0.0, "vx": 0.0, "vy": 0.0, "va": 0.0, "state": "stand",
                                  "label": random.choice(LABELS), "gold": bool(L.get("gold")) and r == nrows,
                                  "pop": -(r * 0.08 + i * 0.03), "down": False, "gone": False, "shot": False,
                                  "wob": 0.0, "body": None, "sbody": None, "sleep": 0.0, "asleep": False})
            y -= CH + 0.5
        self.standing = len(self.cans)
        self.cleared = None
        self.stackTime = 0.0
        self.stackShots = 0
        self.banner = False
        self.bannerT = 0.0

    # ------------------------------------------------------------------ physics
    # Upright cans are kept perfectly still (no jitter) and only move when the shelf moves or
    # their support disappears. Knocked cans become rigid bodies in a small box-physics world.
    def clink(self, sp):
        if sp > 160 and self.clinkCool <= 0:
            self.clinkCool = 0.06
            A.play("tin", min(0.7, sp / 900), 0.85 + random.random() * 0.5)

    def topple(self, c, d, push=25.0, spin=0.6, vy=0.0):
        """Turn an upright can into a rigid body, leaning towards direction d (-1 / 1)."""
        if c["state"] != "stand":
            return
        c["state"] = "fall"
        b = P.Body(c["x"], c["y"], HW, HH, 1.0, c["a"], ref=c, friction=0.7)
        b.vx = d * push + self.shelfV
        b.vy = vy
        b.w = d * spin
        c["body"] = b
        c["sleep"] = 0.0
        c["asleep"] = False

    def wake(self, c):
        if c.get("asleep"):
            c["asleep"] = False
            c["sleep"] = 0.0
            b = c["body"]
            b.inv_m = 1.0
            b.inv_i = 1.0 / ((4 * HW * HW + 4 * HH * HH) / 12.0)

    def _aabb(self, c):
        pts = corners(c)
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return min(xs), max(xs), min(ys)

    def supports(self, c):
        """Return (surfaceY, contacts) for an upright can: the highest surface below it."""
        bottom = c["y"] + HH
        cands = []
        if abs(c["x"] - self.shelfX) < SHELF_W / 2 + HW and bottom <= SHELF_Y + 3:
            cands.append((SHELF_Y, self.shelfX - SHELF_W / 2, self.shelfX + SHELF_W / 2))
        for o in self.cans:
            # (cans still popping in count as support too, otherwise the upper rows drop into the lower ones)
            if o is c or o["gone"]:
                continue
            if o["state"] == "stand":
                if abs(o["x"] - c["x"]) < CW - 1:
                    top = o["y"] - HH
                    if top >= bottom - 3:
                        cands.append((top, o["x"] - HW, o["x"] + HW))
            elif o.get("asleep"):
                x0, x1, top = self._aabb(o)
                if x0 < c["x"] + HW - 1 and x1 > c["x"] - HW + 1 and top >= bottom - 3:
                    cands.append((top, x0, x1))
        if not cands:
            return FLOOR_Y, [(FLOOR_Y, -9999, 9999)]
        surf = min(s[0] for s in cands)
        return surf, [s for s in cands if s[0] <= surf + 2.5]

    def step_standing(self, c, dt, shelf_dx):
        surf, contacts = self.supports(c)
        bottom = c["y"] + HH
        if bottom <= SHELF_Y + 1 and abs(c["x"] - self.shelfX) < SHELF_W / 2 + HW:
            c["x"] += shelf_dx          # the whole stack rides along with the moving shelf
        if bottom < surf - 0.5:
            # nothing directly underneath any more: drop straight down
            c["vy"] += GRAV * dt
            c["y"] += c["vy"] * dt
            if c["y"] + HH >= surf:
                c["y"] = surf - HH
                self.clink(c["vy"])
                c["vy"] = 0.0
                c["wob"] = max(c["wob"], 0.6)
            return
        c["y"] = surf - HH
        c["vy"] = 0.0
        lo = min(s[1] for s in contacts)
        hi = max(s[2] for s in contacts)
        if lo > c["x"] - 3:
            self.topple(c, -1)
        elif hi < c["x"] + 3:
            self.topple(c, 1)

    def on_impact(self, a, b, speed):
        ca, cb = a.ref, b.ref
        self.clink(speed)
        for hit, other in ((ca, b), (cb, a)):
            if not isinstance(hit, dict):
                continue
            if hit["state"] == "stand" and other.inv_m > 0 and speed > 150:
                self._pending.append((hit, 1 if hit["x"] > other.x else -1, min(220.0, speed * 0.45)))
            elif hit.get("asleep") and other.inv_m > 0 and speed > 70:
                self._wake.append(hit)

    def physics(self, dt, shelf_dx):
        self.shelfV = shelf_dx / dt if dt > 0 else 0.0
        order = sorted((c for c in self.cans if not c["gone"] and c["state"] == "stand"), key=lambda c: -c["y"])
        for c in order:
            self.step_standing(c, dt, shelf_dx)
        dynamic, statics = [], [self.floor, self.wallL, self.wallR]
        sh = self.shelfBody
        sh.x, sh.vx = self.shelfX, self.shelfV
        statics.append(sh)
        for c in self.cans:
            if c["gone"] or c["pop"] < 1:
                continue
            if c["state"] == "stand":
                sb = c.get("sbody")
                if sb is None:
                    sb = c["sbody"] = P.Body(c["x"], c["y"], HW, HH, 0, ref=c, friction=0.7)
                sb.x, sb.y = c["x"], c["y"]
                sb.vx = self.shelfV if c["y"] + HH <= SHELF_Y + 1 else 0.0
                statics.append(sb)
            elif c.get("asleep"):
                statics.append(c["body"])
            else:
                dynamic.append(c["body"])
        if not dynamic:
            return
        self._pending, self._wake = [], []
        self.world.on_impact = self.on_impact
        self.world.step(dt, dynamic, statics)
        for b in dynamic:
            c = b.ref
            c["x"], c["y"], c["a"] = b.x, b.y, b.a
            if b.vx * b.vx + b.vy * b.vy < 225 and abs(b.w) < 0.3:
                c["sleep"] += dt
                if c["sleep"] > 0.5:
                    c["asleep"] = True
                    b.vx = b.vy = b.w = 0.0
                    b.inv_m = b.inv_i = 0.0
            else:
                c["sleep"] = 0.0
            if b.y > 900:
                c["gone"] = True
        for c, d, push in self._pending:
            self.topple(c, d, push, 1.5, -40.0)
        for c in self._wake:
            self.wake(c)

    def isDown(self, c):
        if c["state"] != "stand":
            return True
        return c["y"] > SHELF_Y or abs(c["x"] - self.shelfX) > SHELF_W / 2 + 4

    # ------------------------------------------------------------------ update
    def update(self, dt, active):
        self.t += dt
        self.clinkCool -= dt
        self.fotoCool = max(0.0, self.fotoCool - dt)
        if self.flashDelay is not None:
            self.flashDelay -= 1
            if self.flashDelay <= 0:
                self.flashDelay = None
                self.flash = 1.0
        self.flash = max(0.0, self.flash - dt * 2.5)
        if self.polaroid:
            self.polaroid["t"] += dt
            if self.polaroid["t"] > 4:
                self.polaroid = None

        L = self.layout
        oldX = self.shelfX
        if L.get("move") and active and self.cleared is None:
            self.shelfT += dt
            w = 1.3 * self.speed
            self.shelfX = 640 + L["move"] * sin(self.shelfT * w)
        shelf_dx = self.shelfX - oldX
        for c in self.cans:
            if c["pop"] < 1:
                c["pop"] = min(1.0, c["pop"] + dt * 5)
            c["wob"] = max(0.0, c["wob"] - dt * 2.5)

        # physics in sub-steps (stable stacking + fast cans don't tunnel)
        steps = 3
        for _ in range(steps):
            self.physics(dt / steps, shelf_dx / steps)

        if active:
            self.stackTime += dt
        standing = 0
        for c in self.cans:
            if c["gone"]:
                continue
            if not c["down"] and c["pop"] >= 1 and self.isDown(c):
                c["down"] = True
                if not c["shot"]:
                    self.bonus = self.bonus or []
                    self.bonus.append({"pts": 50, "label": "+50", "x": c["x"], "y": c["y"] - 40})
                    A.play("clatter", 0.5, 0.9 + random.random() * 0.3)
            if not c["down"]:
                standing += 1
            if c["y"] > 900:
                c["gone"] = True
        self.standing = standing

        if standing == 0 and self.cleared is None:
            self.stats["stacks"] += 1
            self.stats["bestStack"] = min(self.stats["bestStack"], self.stackShots)
            self.cleared = 0.0
            bonus = 500 * self.round
            quick = max(0, floor((12 - self.stackTime) * 40))
            self.bonus = self.bonus or []
            self.bonus.append({"pts": bonus + quick, "label": T("all_down_bonus", bonus + quick), "x": 640, "y": 300})
            self.banner = True
            self.bannerT = 0.0
            A.play("bell", 0.9)
            A.play("gold", 0.8)
            G.FX.burst(640, 360, 80, None, 650)
        if self.cleared is not None:
            self.cleared += dt
            if self.cleared > 2.2:
                self.buildStack()
        self.bannerT += dt

        keep = []
        for f in self.flying:
            f["t"] += dt
            f["vy"] += 1300 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["t"] <= 1.2:
                keep.append(f)
        self.flying = keep

    # ------------------------------------------------------------------ shooting
    def knock(self, can, x, y):
        cx, cy = can["x"], can["y"]
        for o in self.cans:
            if o is can or o["gone"]:
                continue
            dx, dy = o["x"] - cx, o["y"] - cy
            d = sqrt(dx * dx + dy * dy) or 0.001
            if d < 95:
                o["wob"] = 1.0
                if o["state"] == "stand":
                    # the impact rattles the stack: direct neighbours may tip over
                    if abs(dy) < 10 and d < 70 and random.random() < 0.22:
                        self.topple(o, 1 if dx > 0 else -1, push=90, spin=1.5)
                elif o["body"] is not None:
                    self.wake(o)
                    b = o["body"]
                    b.vx += dx / d * 120
                    b.vy -= 60
                    b.w += rand(-3, 3)
        self.flying.append({"x": cx, "y": cy, "rot": can["a"], "vx": (cx - x) * 6 + rand(-80, 80), "vy": rand(-620, -480),
                            "vr": rand(-12, 12), "t": 0.0, "label": can["label"], "gold": can["gold"]})
        can["gone"] = can["shot"] = can["down"] = True

    def shoot(self, x, y):
        self.stackShots += 1
        fx, fy = FOTO_X, FOTO_Y
        d = sqrt((x - fx) ** 2 + (y - fy) ** 2)
        if d < 34:
            if d < 12 and self.fotoCool <= 0:
                self.fotoCool = 6.0
                self.photos += 1
                self.stats["photos"] += 1
                A.play("shutter", 1)
                self.flashDelay = 2

                def got(img):
                    self.polaroid = {"img": img, "t": 0.0}
                Game.request_photo(got)
                return {"pts": 300, "label": T("photo_hit"), "big": True, "color": G.C["pink"], "x": fx, "y": fy - 40}
            A.play("thud", 0.6)
            return {"pts": 10, "x": fx, "y": fy - 30, "color": G.C["cream"]}
        if self.cleared is not None:
            return None
        for c in self.cans:
            if c["gone"] or c["pop"] < 1:
                continue
            hit = point_in_can(c, x, y)
            if not hit and G.kids:
                for ox, oy in ((14, 0), (-14, 0), (0, 14), (0, -14)):
                    if point_in_can(c, x + ox, y + oy):
                        hit = True
                        break
            if hit:
                cx, cy = c["x"], c["y"]
                wasDown = c["down"]
                self.knock(c, x, y)
                A.play("tin", 1, 0.9 + random.random() * 0.2)
                A.play("clang", 0.35, 1.8)
                G.FX.burst(x, y, 12, [(0.85, 0.87, 0.9), c["label"], G.C["white"]], 300)
                G.FX.ring(cx, cy, G.C["white"], 46)
                if c["gold"]:
                    A.play("gold", 0.9)
                    return {"pts": 300, "label": T("golden_can"), "big": True, "color": G.C["gold"], "x": cx, "y": cy - 40}
                return {"pts": 25 if wasDown else 100, "x": cx, "y": cy - 40, "color": G.C["cream"]}
        return None

    # ------------------------------------------------------------------ drawing
    def draw(self):
        t = self.t
        G.blit_cached("cans_bg", _paint_bg)
        G.sign(930, 190, 230, 110, None, None, G.C["yellow"], None, t)
        G.text(T("cans_sign1"), 1045, 202, G.F["sign34"], G.C["darkred"], 220, 0)
        G.text(T("cans_sign2"), 1045, 246, G.F["sign34"], G.C["darkred"], 220, 0)
        G.text(T("stack_info", self.round, T(self.layout["name"])), 1045, 316, G.F["ui16"], G.C["cream"], 260, 2)
        G.text(T("cans_standing", self.standing), 1045, 340, G.F["ui16"], G.C["yellow"], 260, 2)
        G.text(T("photo"), FOTO_X, FOTO_Y - 98, G.F["sign26"], (0.6, 0.6, 0.6) if self.fotoCool > 0 else G.C["cream"], 140, 2)

        sx = self.shelfX
        lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", sx - SHELF_W / 2 + 6, SHELF_Y + 8, SHELF_W, SHELF_H + 6)
        lg.set_color(0.62, 0.4, 0.22); lg.rectangle("fill", sx - SHELF_W / 2, SHELF_Y, SHELF_W, SHELF_H, 3)
        lg.set_color(0.75, 0.52, 0.3); lg.rectangle("fill", sx - SHELF_W / 2, SHELF_Y, SHELF_W, 5, 3)
        G.col(G.C["red"]); lg.rectangle("fill", sx - SHELF_W / 2, SHELF_Y + SHELF_H - 4, SHELF_W, 4)
        lg.set_color(0.3, 0.2, 0.12)
        lg.rectangle("fill", sx - SHELF_W / 2 + 40, SHELF_Y + SHELF_H, 14, FLOOR_Y - SHELF_Y - SHELF_H)
        lg.rectangle("fill", sx + SHELF_W / 2 - 54, SHELF_Y + SHELF_H, 14, FLOOR_Y - SHELF_Y - SHELF_H)

        for c in self.cans:
            if not c["gone"] and c["pop"] > 0:
                s = c["pop"] * (1.25 - 0.25 * c["pop"]) if c["pop"] < 1 else 1
                a = c["a"] + (sin(t * 28) * c["wob"] * 0.05 if c["state"] == "stand" else 0)
                drawCan(c["x"], c["y"], a, c["label"], c["gold"], s)
                if c["gold"]:
                    lg.set_color(1, 1, 1, 0.5 + 0.5 * sin(t * 10)); lg.circle("fill", c["x"] + 14, c["y"] - 24, 3)
        for f in self.flying:
            drawCan(f["x"], f["y"], f["rot"], f["label"], f["gold"], max(0.25, 1 - f["t"] * 0.7))

        if self.banner and self.bannerT < 2.2:
            k = max(0.05, min(1, self.bannerT * 4))
            lg.push(); lg.translate(640, 250); lg.scale(k, k); lg.rotate(sin(self.bannerT * 8) * 0.04)
            G.sign(-300, -50, 600, 100, None, None, G.C["green"], None, t)
            G.text(T("all_down_banner"), 0, -32, G.F["sign46"], G.C["yellow"], 580, 3)
            lg.pop()

    def drawOverlay(self):
        if self.flash > 0:
            lg.set_color(1, 0.95, 0.8, self.flash * 0.45)
            lg.rectangle("fill", 0, 0, G.W, G.H)
        p = self.polaroid
        if p:
            k = min(1, p["t"] * 3)
            out = (p["t"] - 3.4) / 0.6 if p["t"] > 3.4 else 0
            w, h = 300, 169
            x = G.W - 80 - w * k + out * 400
            y = 380
            lg.push(); lg.translate(x + w / 2, y + h / 2); lg.rotate(-0.06); lg.translate(-w / 2, -h / 2)
            lg.set_color(0, 0, 0, 0.4); lg.rectangle("fill", -6, 6, w + 24, h + 60)
            lg.set_color(0.98, 0.97, 0.94); lg.rectangle("fill", -12, -12, w + 24, h + 60)
            iw, ih = p["img"].get_size()
            lg.set_color(1, 1, 1, min(1, p["t"] * 1.2))
            lg.draw_surface(p["img"], 0, 0, w / iw, h / ih)
            G.text(T("polaroid", time.strftime("%d-%m-%Y")), w / 2, h + 8, G.F["ui16"], (0.2, 0.2, 0.3), w, 0)
            lg.pop()

    def demoTarget(self):
        best = None
        for c in self.cans:
            if not c["gone"] and c["pop"] >= 1:
                if best is None or c["y"] > best[1]:
                    best = (c["x"], c["y"])
        return best or (640, 400)


def new():
    return Cans()
