"""BALLOON WALL: pop the balloons. Some hide a prize ticket, gold ones pay big, loose ones float up."""
import math
import random
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, cos, pi, sqrt = math.sin, math.cos, math.pi, math.sqrt

COLS = [G.C["red"], G.C["blue"], G.C["green"], G.C["yellow"], G.C["pink"], G.C["orange"], G.C["purple"], G.C["sky"]]
GOLD = (1, 0.8, 0.2)
BOMBC = (0.13, 0.13, 0.16)
BX, BY, BW, BH = 150, 175, 980, 380


def rand(a, b):
    return a + random.random() * (b - a)


def _balloon_body(r, c):
    lg.set_color(0, 0, 0, 0.2); lg.ellipse("fill", 4, 6, r, r * 1.2)
    G.col(c); lg.ellipse("fill", 0, 0, r, r * 1.2)
    lg.polygon("fill", -5, r * 1.18, 5, r * 1.18, 0, r * 1.05)
    G.shade(c, 0.75); lg.ellipse("fill", r * 0.25, r * 0.35, r * 0.55, r * 0.6)
    G.col(c); lg.ellipse("fill", -r * 0.05, -r * 0.05, r * 0.85, r * 1.0)
    lg.set_color(1, 1, 1, 0.65); lg.ellipse("fill", -r * 0.38, -r * 0.48, r * 0.18, r * 0.28)


def balloon(x, y, r, c, s, gold, t):
    s = round(s, 2)
    r = int(r)
    lg.set_color(0.82, 0.82, 0.86); lg.set_line_width(1.5)
    lg.line(x, y + r * 1.2 * s, x + sin(t * 3 + x) * 6, y + r * 1.2 * s + 40)
    lg.push(); lg.translate(x, y); lg.scale(s, s)
    G.sprite(("balloon", r, tuple(c)), lambda: _balloon_body(r, c), r + 8, r * 1.3 + 8, 0, 0)
    if gold:
        lg.set_color(1, 1, 1, 0.5 + 0.5 * sin(t * 10)); lg.circle("fill", r * 0.4, -r * 0.6, 3)
    lg.pop()


def _paint_bg():
    lg.set_color(0.25, 0.3, 0.55); lg.rectangle("fill", 0, 0, G.W, G.H)
    for i in range(23):
        lg.set_color(0.28 + (i % 2) * 0.03, 0.33, 0.58); lg.rectangle("fill", 80 + i * 52, 140, 50, 500)
    lg.set_color(0.45, 0.3, 0.15); lg.rectangle("fill", BX - 26, BY - 26, BW + 52, BH + 52, 10)
    lg.set_color(0.78, 0.6, 0.38); lg.rectangle("fill", BX - 14, BY - 14, BW + 28, BH + 28, 6)
    lg.set_color(0.7, 0.52, 0.32)
    for i in range(1, 161):
        lg.circle("fill", BX + (i * 97) % BW, BY + (i * 53) % BH, 2)


class Balloons:
    def __init__(self):
        self.time, self.mag = 60, 8
        self.t = self.elapsed = 0.0
        self.stats = {"popped": 0, "tickets": 0, "gold": 0, "floaters": 0, "bombs": 0}
        self.bonus = None
        self.finished = False
        self.balloons = []
        cols, rows = 9, 4
        for r in range(1, rows + 1):
            for c in range(1, cols + 1):
                b = {"x": BX + (c - 0.5) * BW / cols + (18 if r % 2 == 0 else -18), "y": BY + (r - 0.5) * BH / rows,
                     "ph": rand(0, 6), "pop": 1.0, "respawn": 0.0}
                self.reroll(b)
                self.balloons.append(b)
        self.floaters, self.shreds, self.tickets = [], [], []
        self.floatT = 5.0

    def reroll(self, b):
        b["alive"] = True
        b["col"] = random.choice(COLS)
        r = random.random()
        b["gold"] = r < 0.05
        b["ticket"] = (not b["gold"]) and r < 0.17
        b["bomb"] = (not G.kids) and 0.17 <= r < 0.26   # black bomb balloon: don't shoot it!
        b["r"] = rand(30, 36)

    def bpos(self, b):
        return b["x"] + sin(self.t * 1.3 + b["ph"]) * 4, b["y"] + sin(self.t * 2.1 + b["ph"]) * 5

    def update(self, dt, active):
        self.t += dt
        if active:
            self.elapsed += dt
        for b in self.balloons:
            if not b["alive"]:
                b["respawn"] -= dt
                if b["respawn"] <= 0:
                    self.reroll(b)
                    b["pop"] = 0.0
                    A.play("swish", 0.25, 1.6)
            elif b["pop"] < 1:
                b["pop"] = min(1.0, b["pop"] + dt * 2.5)
        if active:
            self.floatT -= dt
            if self.floatT <= 0:
                self.floatT = rand(4, 7) / (1 + self.elapsed / 60)
                self.floaters.append({"x": rand(200, 1080), "y": 680.0, "vx": rand(-40, 40), "ph": rand(0, 6),
                                      "col": random.choice(COLS), "r": 30, "sp": rand(110, 160) * (1 + self.elapsed / 80)})
        keep = []
        for f in self.floaters:
            f["y"] -= f["sp"] * dt
            f["x"] += (f["vx"] + sin(self.t * 2 + f["ph"]) * 50) * dt
            if f["y"] >= 90:
                keep.append(f)
        self.floaters = keep
        keep = []
        for s in self.shreds:
            s["t"] += dt
            s["vy"] += 900 * dt
            s["x"] += s["vx"] * dt
            s["y"] += s["vy"] * dt
            s["rot"] += s["vr"] * dt
            if s["t"] <= 1.2:
                keep.append(s)
        self.shreds = keep
        keep = []
        for k in self.tickets:
            k["t"] += dt
            if k["t"] < 0.6:
                k["y"] -= 120 * dt
                k["x"] += sin(k["t"] * 12) * 60 * dt
            else:
                f = min(1, (k["t"] - 0.6) * 2.5)
                k["x"] += (1180 - k["x"]) * f * dt * 6
                k["y"] += (690 - k["y"]) * f * dt * 6
            k["rot"] = sin(k["t"] * 9) * 0.4
            if k["t"] <= 1.4:
                keep.append(k)
        self.tickets = keep

    def burst(self, x, y, r, c):
        for _ in range(9):
            a = rand(0, pi * 2)
            self.shreds.append({"x": x + cos(a) * r * 0.5, "y": y + sin(a) * r * 0.5, "vx": cos(a) * rand(150, 380),
                                "vy": sin(a) * rand(150, 380) - 120, "rot": rand(0, 6), "vr": rand(-15, 15), "t": 0.0, "col": c, "s": rand(5, 10)})
        G.FX.burst(x, y, 14, None, 320)
        A.play("balloon", 1, 0.9 + random.random() * 0.25)

    def shoot(self, x, y):
        R = G.hitR
        for i, f in enumerate(self.floaters):
            if sqrt((x - f["x"]) ** 2 + (y - f["y"]) ** 2) < (f["r"] + 8) * R:
                del self.floaters[i]
                self.stats["floaters"] += 1
                self.burst(f["x"], f["y"], f["r"], f["col"])
                A.play("whistle", 0.4, 1.6)
                return {"pts": 150, "label": T("floater"), "big": True, "color": G.C["sky"], "x": f["x"], "y": f["y"] - 40}
        for b in self.balloons:
            if b["alive"] and b["pop"] >= 1:
                bx, by = self.bpos(b)
                dx, dy = (x - bx) / ((b["r"] + 6) * R), (y - by) / ((b["r"] * 1.2 + 6) * R)
                if dx * dx + dy * dy < 1:
                    b["alive"] = False
                    b["respawn"] = rand(2.5, 4)
                    if b["bomb"]:
                        self.stats["bombs"] += 1
                        self.burst(bx, by, b["r"], BOMBC)
                        A.play("boom", 1)
                        G.FX.addShake(16)
                        G.FX.burst(bx, by, 45, [G.C["orange"], G.C["yellow"], (0.2, 0.2, 0.2)], 520)
                        return {"pts": -250, "penalty": True, "label": T("boom"), "x": bx, "y": by - 40}
                    self.stats["popped"] += 1
                    self.burst(bx, by, b["r"], GOLD if b["gold"] else b["col"])
                    if b["ticket"]:
                        self.stats["tickets"] += 1
                        self.tickets.append({"x": bx, "y": by, "t": 0.0, "rot": 0.0})
                        A.play("ticket", 0.7)
                        return {"pts": 50, "label": T("ticket_found"), "big": True, "color": G.C["orange"], "x": bx, "y": by - 40}
                    if b["gold"]:
                        self.stats["gold"] += 1
                        A.play("gold", 0.8)
                        return {"pts": 300, "label": T("gold_balloon"), "big": True, "color": G.C["gold"], "x": bx, "y": by - 40}
                    return {"pts": 50, "x": bx, "y": by - 30, "color": G.C["cream"]}
        return None

    def demoTarget(self):
        if self.floaters:
            return self.floaters[0]["x"], self.floaters[0]["y"]
        lst = [b for b in self.balloons if b["alive"] and b["pop"] >= 1 and not b["bomb"]]
        if lst:
            return self.bpos(random.choice(lst))
        return 640, 360

    def draw(self):
        t = self.t
        G.blit_cached("balloons_bg", _paint_bg)
        for b in self.balloons:
            x, y = self.bpos(b)
            lg.set_color(0.6, 0.6, 0.65); lg.circle("fill", b["x"], b["y"] + b["r"] * 1.2 + 4, 3)
            if b["alive"]:
                s = (0.2 + 0.8 * b["pop"]) if b["pop"] < 1 else 1
                c = BOMBC if b["bomb"] else (GOLD if b["gold"] else b["col"])
                balloon(x, y, b["r"], c, s, b["gold"], t)
                if b["bomb"] and s >= 1:
                    G.bombIcon(x, y + 4, 11, t + b["ph"])
        for f in self.floaters:
            balloon(f["x"], f["y"], f["r"], f["col"], 1, False, t)
            lg.set_color(1, 1, 1, 0.5 + 0.5 * sin(t * 8)); lg.set_line_width(2); lg.circle("line", f["x"], f["y"], f["r"] + 10)
        for s in self.shreds:
            a = 1 - s["t"] / 1.2
            c = s["col"]
            lg.set_color(c[0], c[1], c[2], a)
            lg.push(); lg.translate(s["x"], s["y"]); lg.rotate(s["rot"])
            lg.polygon("fill", -s["s"], -s["s"] * 0.4, s["s"], -s["s"] * 0.2, s["s"] * 0.4, s["s"] * 0.6)
            lg.pop()
        for k in self.tickets:
            lg.push(); lg.translate(k["x"], k["y"]); lg.rotate(k["rot"])
            lg.set_color(1, 0.55, 0.2); lg.rectangle("fill", -22, -12, 44, 24, 3)
            lg.set_color(1, 0.85, 0.5); lg.set_line_width(1); lg.rectangle("line", -18, -8, 36, 16)
            G.text(T("ticket_word"), 0, -8, G.F["ui12"], G.C["darkred"], 44, 0)
            lg.pop()


def new():
    return Balloons()
