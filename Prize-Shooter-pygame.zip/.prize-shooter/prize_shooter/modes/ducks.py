"""LUCKY DUCKIES: three conveyor rows of bobbing rubber ducks. Gold ducks pay big, bombs cost points."""
import math
import random
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, pi, ceil = math.sin, math.pi, math.ceil
PRIZES = [2000, 5000, 9000, 14000]

ROWS = [
    {"y": 300, "s": 0.6, "speed": 110, "pts": 100, "water": (0.25, 0.5, 0.9)},
    {"y": 425, "s": 0.8, "speed": -150, "pts": 75, "water": (0.2, 0.42, 0.85)},
    {"y": 555, "s": 1.0, "speed": 190, "pts": 50, "water": (0.15, 0.36, 0.8)},
]
WAVE = 48


def rollType(allowBomb):
    r = random.random()
    if r < 0.06:
        return "gold"
    if allowBomb and not G.kids and r < 0.19:
        return "bomb"
    return "duck"


def _bomb_body(s, flip):
    lg.push(); lg.scale(s, s * flip)
    lg.set_color(0, 0, 0, 0.25); lg.circle("fill", 4, 6, 32)
    lg.set_color(0.12, 0.12, 0.15); lg.circle("fill", 0, 0, 32)
    lg.set_color(0.35, 0.35, 0.4); lg.rectangle("fill", -8, -42, 16, 12)
    lg.set_color(0.6, 0.5, 0.3); lg.set_line_width(3); lg.line(0, -42, 6, -54, 14, -58)
    lg.set_color(1, 1, 1, 0.3); lg.circle("fill", -10, -10, 8)
    G.text("X", 0, -14, G.F["ui20"], G.C["red"], 60, 0)
    lg.pop()


def bomb(x, y, s, flip, t):
    s = round(s, 2)
    fq = round(flip, 1) or 0.05
    G.sprite(("bomb", s, fq), lambda: _bomb_body(s, fq), 40 * s, 66 * s, x, y - 14 * s)
    if flip > 0:
        lg.push(); lg.translate(x, y - 14 * s); lg.scale(s, s * flip)
        lg.set_color(1, 0.7 + 0.3 * sin(t * 30), 0.2); lg.circle("fill", 14, -58, 5 + 2 * sin(t * 25))
        lg.pop()


def _wave_strip(color):
    # periodic strip; drawn so that strip x=0 is one wave period left of the visible start
    w = WAVE
    surf = pygame.Surface((1120 + w * 2, 80), pygame.SRCALPHA)
    lg.push_target(surf); lg.push(); lg.origin(); lg.translate(0, 12)
    G.col(color)
    lg.rectangle("fill", 0, 12, 1120 + w * 2, 50)
    xs = [k * w for k in range(0, (1120 + w * 2) // w + 2)]
    for x in xs:
        lg.circle("fill", x, 14, w * 0.5)
    lg.set_color(1, 1, 1, 0.5)
    lg.set_line_width(3)
    for x in xs:
        lg.arc("line", "open", x, 14, w * 0.5 - 3, pi * 1.15, pi * 1.6)
    lg.set_color(0.35, 0.22, 0.12); lg.rectangle("fill", 0, 56, 1120 + w * 2, 8)
    lg.pop(); lg.pop_target()
    return surf


def _paint_sky():
    for i in range(11):
        if G.evening:
            lg.set_color(0.16 + i * 0.05, 0.14 + i * 0.025, 0.36 + i * 0.02)
        else:
            lg.set_color(0.55 + i * 0.02, 0.8 + i * 0.01, 0.98)
        lg.rectangle("fill", 0, 140 + i * 50, G.W, 51)


class Ducks:
    def __init__(self):
        self.time, self.mag = 60, 8
        self.t = self.elapsed = 0.0
        self.stats = {"ducks": 0, "gold": 0, "flyers": 0, "bombs": 0}
        self.bonus = None
        self.finished = False
        self.rows = []
        for R in ROWS:
            spacing = 170 * R["s"] + 40
            n = ceil((G.W + 260) / spacing)
            row = {"def": R, "spacing": spacing, "L": n * spacing, "offset": random.random() * spacing, "items": [],
                   "strip": _wave_strip(R["water"])}
            for i in range(1, n + 1):
                row["items"].append({"base": (i - 1) * spacing, "type": rollType(i % 3 != 1), "flip": 1.0, "hit": False,
                                     "lastP": None, "pop": None})
            self.rows.append(row)
        self.flyer = None
        self.flyerTimer = 6.0
        self.falling = []
        self.clouds = [{"x": random.randint(80, 1200), "y": random.randint(170, 230), "s": 0.6 + random.random() * 0.6}
                       for _ in range(5)]

    def speedMul(self):
        return 1 + self.elapsed / 50

    def itemPos(self, row, it):
        R = row["def"]
        x = (it["base"] + row["offset"]) % row["L"] - 130
        if R["speed"] < 0:
            x = G.W - x
        y = R["y"] - 30 * R["s"] + sin(self.t * 4 + it["base"] * 0.05) * 4 * R["s"]
        return x, y

    def update(self, dt, active):
        self.t += dt
        if active:
            self.elapsed += dt
        mul = self.speedMul()
        for row in self.rows:
            R = row["def"]
            row["offset"] += abs(R["speed"]) * mul * dt
            for it in row["items"]:
                p = (it["base"] + row["offset"]) % row["L"]
                if it["lastP"] is not None and p < it["lastP"]:
                    it["hit"], it["flip"], it["type"], it["pop"] = False, 1.0, rollType(True), 0.0
                it["lastP"] = p
                if it["hit"]:
                    it["flip"] = max(0.0, it["flip"] - dt * 4)
                if it["pop"] is not None:
                    it["pop"] += dt
                    if it["pop"] > 0.4:
                        it["pop"] = None
        for c in self.clouds:
            c["x"] += 12 * dt * c["s"]
            if c["x"] > 1300:
                c["x"] = -100
        if active:
            self.flyerTimer -= dt
            if self.flyer is None and self.flyerTimer <= 0:
                d = 1 if random.random() < 0.5 else -1
                self.flyer = {"x": -80 if d == 1 else G.W + 80, "dir": d, "t": 0.0, "y0": 200 + random.random() * 40, "y": 200}
                A.play("whistle", 0.5, 1.4)
        f = self.flyer
        if f:
            f["t"] += dt
            f["x"] += f["dir"] * 330 * dt
            f["y"] = f["y0"] + sin(f["t"] * 3) * 30
            if f["x"] < -120 or f["x"] > G.W + 120:
                self.flyer = None
                self.flyerTimer = 8 + random.random() * 5
        keep = []
        for f in self.falling:
            f["vy"] += 1400 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["y"] <= 800:
                keep.append(f)
        self.falling = keep

    def shoot(self, x, y):
        f = self.flyer
        if f and (x - f["x"]) ** 2 + (y - (f["y"] - 10)) ** 2 < (44 * G.hitR) ** 2:
            self.flyer = None
            self.stats["flyers"] += 1
            self.flyerTimer = 9 + random.random() * 5
            self.falling.append({"x": f["x"], "y": f["y"], "vx": f["dir"] * 120, "vy": -200, "rot": 0.0, "vr": 10 * f["dir"], "dir": f["dir"]})
            A.play("squeak", 1, 1.3)
            A.play("gold", 0.7)
            G.FX.burst(f["x"], f["y"], 24, [G.C["yellow"], G.C["white"], G.C["orange"]], 300)
            return {"pts": 250, "label": T("flying_duck"), "big": True, "color": G.C["orange"], "x": f["x"], "y": f["y"]}
        for row in reversed(self.rows):
            s = row["def"]["s"]
            for it in row["items"]:
                if it["hit"]:
                    continue
                ix, iy = self.itemPos(row, it)
                cy = iy - 16 * s
                if (x - ix) ** 2 + (y - cy) ** 2 < (46 * s * G.hitR) ** 2:
                    it["hit"] = True
                    if it["type"] == "bomb":
                        self.stats["bombs"] += 1
                        A.play("boom", 1)
                        G.FX.addShake(16)
                        G.FX.burst(ix, iy, 40, [G.C["orange"], G.C["yellow"], (0.2, 0.2, 0.2)], 500)
                        return {"pts": -250, "penalty": True, "label": T("boom"), "x": ix, "y": iy - 40}
                    gold = it["type"] == "gold"
                    self.stats["ducks"] += 1
                    if gold:
                        self.stats["gold"] += 1
                    A.play("squeak", 0.9, (1.25 if gold else 1) * (1.15 - s * 0.2))
                    A.play("splash", 0.4)
                    G.FX.burst(ix, iy, 10, [(0.6, 0.8, 1), G.C["white"]], 220, "drop")
                    if gold:
                        A.play("gold", 0.8)
                        G.FX.ring(ix, cy, G.C["gold"], 60)
                    return {"pts": 400 if gold else row["def"]["pts"], "label": T("golden_duck") if gold else None, "big": gold,
                            "color": G.C["gold"] if gold else G.C["yellow"], "x": ix, "y": cy - 30 * s}
        G.FX.burst(x, y, 4, [(0.9, 0.9, 1)], 120, "drop")
        return None

    def draw(self):
        t = self.t
        G.blit_cached("ducks_sky_%s" % G.evening, _paint_sky)
        if G.evening:
            for i in range(1, 41):
                sx, sy = (i * 197) % 1120 + 80, (i * 53) % 140 + 150
                lg.set_color(1, 1, 0.9, 0.4 + 0.4 * sin(t * 3 + i))
                lg.circle("fill", sx, sy, 1.5 + (i % 3) * 0.5)
            lg.set_color(1, 0.95, 0.75); lg.circle("fill", 1080, 200, 26)
            lg.set_color(0.2, 0.16, 0.38); lg.circle("fill", 1068, 192, 22)
        for c in self.clouds:
            if G.evening:
                lg.set_color(0.45, 0.38, 0.6, 0.6)
            else:
                lg.set_color(1, 1, 1, 0.85)
            lg.circle("fill", c["x"], c["y"], 26 * c["s"]); lg.circle("fill", c["x"] + 28 * c["s"], c["y"] + 6, 20 * c["s"])
            lg.circle("fill", c["x"] - 28 * c["s"], c["y"] + 6, 18 * c["s"])
        tgt = lg.get_target()
        for ri, row in enumerate(self.rows, 1):
            R = row["def"]
            lg.set_color(0.9, 0.3 + ri * 0.08, 0.35, 0.35)
            lg.rectangle("fill", 80, R["y"] - 90 * R["s"], 1120, 6)
            d = 1 if R["speed"] > 0 else -1
            for it in row["items"]:
                x, y = self.itemPos(row, it)
                if -80 < x < G.W + 80:
                    popS = min(1, it["pop"] / 0.25) if it["pop"] is not None else 1
                    if it["type"] == "bomb":
                        bomb(x, y + (1 - it["flip"]) * 44 * R["s"], R["s"] * popS, max(0.15, it["flip"]), t)
                    else:
                        c = G.C["gold"] if it["type"] == "gold" else G.C["yellow"]
                        if it["hit"]:
                            c = (c[0] * 0.75, c[1] * 0.75, c[2] * 0.6)
                        G.duck(x, y + (1 - it["flip"]) * 44 * R["s"], R["s"] * popS, d, c, max(0.15, it["flip"]))
                        if it["type"] == "gold" and it["flip"] > 0:
                            lg.set_color(1, 1, 1, 0.5 + 0.5 * sin(t * 12 + x))
                            lg.circle("fill", x + 20 * R["s"] * d, y - 50 * R["s"], 3)
            o = (row["offset"] * 0.5 * d) % WAVE
            X, Y = lg.tp(80, R["y"] - 12)
            tgt.blit(row["strip"], (int(X), int(Y)), pygame.Rect(int(WAVE - o), 0, 1120, 80))
        f = self.flyer
        if f:
            G.duck(f["x"], f["y"], 0.7, f["dir"], G.C["white"])
            flap = sin(f["t"] * 18) * 26
            lg.set_color(0.92, 0.92, 0.95)
            lg.polygon("fill", f["x"] - 6 * f["dir"], f["y"] - 6, f["x"] + 16 * f["dir"], f["y"] - 4, f["x"] - 10 * f["dir"], f["y"] - 30 - flap)
        for dd in self.falling:
            lg.push(); lg.translate(dd["x"], dd["y"]); lg.rotate(dd["rot"])
            G.duck(0, 0, 0.7, dd["dir"], G.C["white"], -1)
            lg.pop()

    def demoTarget(self):
        if self.flyer:
            return self.flyer["x"], self.flyer["y"] - 10
        for row in reversed(self.rows):
            for it in row["items"]:
                x, y = self.itemPos(row, it)
                if not it["hit"] and it["type"] != "bomb" and 160 < x < 1120:
                    return x, y - 16 * row["def"]["s"]
        return 640, 400


def new():
    return Ducks()
