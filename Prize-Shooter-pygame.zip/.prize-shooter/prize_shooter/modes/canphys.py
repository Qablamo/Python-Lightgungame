"""A tiny 2D rigid-box physics solver for Tin Can Alley (pygame has no Box2D on Batocera).

Box-box collision is a port of the classic Box2D-Lite clipping algorithm; contacts are
resolved with sequential impulses (friction, a little restitution, Baumgarte position
correction). Bodies with inv_m == 0 are static/kinematic (shelf, floor, walls, upright cans).
"""
import math

sin, cos, sqrt = math.sin, math.cos, math.sqrt


class Body:
    __slots__ = ("x", "y", "a", "vx", "vy", "w", "hw", "hh", "inv_m", "inv_i", "r", "ref", "friction")

    def __init__(self, x, y, hw, hh, mass=1.0, a=0.0, ref=None, friction=0.6):
        self.x, self.y, self.a = x, y, a
        self.vx = self.vy = self.w = 0.0
        self.hw, self.hh = hw, hh
        self.r = sqrt(hw * hw + hh * hh)
        self.ref = ref
        self.friction = friction
        if mass > 0:
            self.inv_m = 1.0 / mass
            self.inv_i = 1.0 / (mass * (4 * hw * hw + 4 * hh * hh) / 12.0)
        else:
            self.inv_m = self.inv_i = 0.0


def _incident_edge(hx, hy, px, py, c, s, nx, ny):
    # n = -(RotT * normal)
    tx = -(c * nx + s * ny)
    ty = -(-s * nx + c * ny)
    if abs(tx) > abs(ty):
        if tx > 0:
            v0, v1 = (hx, -hy), (hx, hy)
        else:
            v0, v1 = (-hx, hy), (-hx, -hy)
    else:
        if ty > 0:
            v0, v1 = (hx, hy), (-hx, hy)
        else:
            v0, v1 = (-hx, -hy), (hx, -hy)
    return [(px + c * v0[0] - s * v0[1], py + s * v0[0] + c * v0[1]),
            (px + c * v1[0] - s * v1[1], py + s * v1[0] + c * v1[1])]


def _clip(vin, nx, ny, offset):
    out = []
    (x0, y0), (x1, y1) = vin
    d0 = nx * x0 + ny * y0 - offset
    d1 = nx * x1 + ny * y1 - offset
    if d0 <= 0:
        out.append((x0, y0))
    if d1 <= 0:
        out.append((x1, y1))
    if d0 * d1 < 0:
        t = d0 / (d0 - d1)
        out.append((x0 + t * (x1 - x0), y0 + t * (y1 - y0)))
    return out


def collide(A, B):
    """Return a list of contacts (px, py, nx, ny, separation); normal points from A to B."""
    ca, sa = cos(A.a), sin(A.a)
    cb, sb = cos(B.a), sin(B.a)
    dpx, dpy = B.x - A.x, B.y - A.y
    dAx, dAy = ca * dpx + sa * dpy, -sa * dpx + ca * dpy
    dBx, dBy = cb * dpx + sb * dpy, -sb * dpx + cb * dpy
    d = B.a - A.a
    c11, c12, c21, c22 = abs(cos(d)), abs(sin(d)), abs(sin(d)), abs(cos(d))
    faceAx = abs(dAx) - A.hw - (c11 * B.hw + c12 * B.hh)
    faceAy = abs(dAy) - A.hh - (c21 * B.hw + c22 * B.hh)
    if faceAx > 0 or faceAy > 0:
        return []
    faceBx = abs(dBx) - (c11 * A.hw + c21 * A.hh) - B.hw
    faceBy = abs(dBy) - (c12 * A.hw + c22 * A.hh) - B.hh
    if faceBx > 0 or faceBy > 0:
        return []
    rel, abs_tol = 0.95, 0.01
    axis, sep = 0, faceAx
    nx, ny = (ca, sa) if dAx > 0 else (-ca, -sa)
    if faceAy > rel * sep + abs_tol * A.hh:
        axis, sep = 1, faceAy
        nx, ny = (-sa, ca) if dAy > 0 else (sa, -ca)
    if faceBx > rel * sep + abs_tol * B.hw:
        axis, sep = 2, faceBx
        nx, ny = (cb, sb) if dBx > 0 else (-cb, -sb)
    if faceBy > rel * sep + abs_tol * B.hh:
        axis, sep = 3, faceBy
        nx, ny = (-sb, cb) if dBy > 0 else (sb, -cb)
    if axis == 0:
        fnx, fny = nx, ny
        front = A.x * fnx + A.y * fny + A.hw
        snx, sny = -sa, ca
        side = A.x * snx + A.y * sny
        neg, pos = -side + A.hh, side + A.hh
        inc = _incident_edge(B.hw, B.hh, B.x, B.y, cb, sb, fnx, fny)
    elif axis == 1:
        fnx, fny = nx, ny
        front = A.x * fnx + A.y * fny + A.hh
        snx, sny = ca, sa
        side = A.x * snx + A.y * sny
        neg, pos = -side + A.hw, side + A.hw
        inc = _incident_edge(B.hw, B.hh, B.x, B.y, cb, sb, fnx, fny)
    elif axis == 2:
        fnx, fny = -nx, -ny
        front = B.x * fnx + B.y * fny + B.hw
        snx, sny = -sb, cb
        side = B.x * snx + B.y * sny
        neg, pos = -side + B.hh, side + B.hh
        inc = _incident_edge(A.hw, A.hh, A.x, A.y, ca, sa, fnx, fny)
    else:
        fnx, fny = -nx, -ny
        front = B.x * fnx + B.y * fny + B.hh
        snx, sny = cb, sb
        side = B.x * snx + B.y * sny
        neg, pos = -side + B.hw, side + B.hw
        inc = _incident_edge(A.hw, A.hh, A.x, A.y, ca, sa, fnx, fny)
    cp = _clip(inc, -snx, -sny, neg)
    if len(cp) < 2:
        return []
    cp = _clip(cp, snx, sny, pos)
    if len(cp) < 2:
        return []
    out = []
    for vx, vy in cp:
        s = fnx * vx + fny * vy - front
        if s <= 0:
            out.append((vx - s * fnx, vy - s * fny, nx, ny, s))
    return out


class World:
    def __init__(self, gravity=880.0, iterations=8):
        self.g = gravity
        self.iterations = iterations
        self.restitution = 0.12
        self.on_impact = None     # callback(bodyA, bodyB, approach_speed)

    def step(self, dt, dynamic, statics):
        if dt <= 0:
            return
        inv_dt = 1.0 / dt
        for b in dynamic:
            b.vy += self.g * dt
            b.w *= (1 - 0.4 * dt)
        # contacts: dynamic vs static, dynamic vs dynamic
        cons = []
        n = len(dynamic)
        for i in range(n):
            A = dynamic[i]
            for S in statics:
                dx, dy = S.x - A.x, S.y - A.y
                rr = A.r + S.r
                if dx * dx + dy * dy < rr * rr and abs(dx) < A.r + S.hw + 2 and abs(dy) < A.r + S.hh + 2:
                    for c in collide(S, A):
                        cons.append(self._pre(S, A, c, inv_dt))
            for j in range(i + 1, n):
                B = dynamic[j]
                dx, dy = B.x - A.x, B.y - A.y
                rr = A.r + B.r
                if dx * dx + dy * dy < rr * rr:
                    for c in collide(A, B):
                        cons.append(self._pre(A, B, c, inv_dt))
        for _ in range(self.iterations):
            for c in cons:
                self._apply(c)
        for b in dynamic:
            b.x += b.vx * dt
            b.y += b.vy * dt
            b.a += b.w * dt

    def _pre(self, A, B, c, inv_dt):
        px, py, nx, ny, sep = c
        r1x, r1y = px - A.x, py - A.y
        r2x, r2y = px - B.x, py - B.y
        rn1 = r1x * nx + r1y * ny
        rn2 = r2x * nx + r2y * ny
        kn = A.inv_m + B.inv_m + A.inv_i * (r1x * r1x + r1y * r1y - rn1 * rn1) + B.inv_i * (r2x * r2x + r2y * r2y - rn2 * rn2)
        tx, ty = ny, -nx
        rt1 = r1x * tx + r1y * ty
        rt2 = r2x * tx + r2y * ty
        kt = A.inv_m + B.inv_m + A.inv_i * (r1x * r1x + r1y * r1y - rt1 * rt1) + B.inv_i * (r2x * r2x + r2y * r2y - rt2 * rt2)
        # relative normal velocity before solving (for restitution and impact events)
        dvx = B.vx - B.w * r2y - A.vx + A.w * r1y
        dvy = B.vy + B.w * r2x - A.vy - A.w * r1x
        vn = dvx * nx + dvy * ny
        bias = -0.2 * inv_dt * min(0.0, sep + 0.5)
        if vn < -90:
            bias = max(bias, -self.restitution * vn)
        if vn < -60 and self.on_impact:
            self.on_impact(A, B, -vn)
        mu = sqrt(A.friction * B.friction)
        return [A, B, r1x, r1y, r2x, r2y, nx, ny, tx, ty, 1.0 / kn if kn else 0.0, 1.0 / kt if kt else 0.0, bias, 0.0, 0.0, mu]

    @staticmethod
    def _apply(c):
        A, B, r1x, r1y, r2x, r2y, nx, ny, tx, ty, mn, mt, bias, Pn, Pt, mu = c
        dvx = B.vx - B.w * r2y - A.vx + A.w * r1y
        dvy = B.vy + B.w * r2x - A.vy - A.w * r1x
        vn = dvx * nx + dvy * ny
        dP = mn * (-vn + bias)
        P0 = Pn
        Pn = max(P0 + dP, 0.0)
        dP = Pn - P0
        px, py = dP * nx, dP * ny
        A.vx -= A.inv_m * px; A.vy -= A.inv_m * py; A.w -= A.inv_i * (r1x * py - r1y * px)
        B.vx += B.inv_m * px; B.vy += B.inv_m * py; B.w += B.inv_i * (r2x * py - r2y * px)
        dvx = B.vx - B.w * r2y - A.vx + A.w * r1y
        dvy = B.vy + B.w * r2x - A.vy - A.w * r1x
        vt = dvx * tx + dvy * ty
        dT = mt * (-vt)
        maxT = mu * Pn
        T0 = Pt
        Pt = max(-maxT, min(T0 + dT, maxT))
        dT = Pt - T0
        px, py = dT * tx, dT * ty
        A.vx -= A.inv_m * px; A.vy -= A.inv_m * py; A.w -= A.inv_i * (r1x * py - r1y * px)
        B.vx += B.inv_m * px; B.vy += B.inv_m * py; B.w += B.inv_i * (r2x * py - r2y * px)
        c[13], c[14] = Pn, Pt
