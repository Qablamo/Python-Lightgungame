"""SHARK TOOTH: knock the teeth out of a snapping shark. Teeth can only be hit while the jaws are open."""
import math
import random
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import game as Game
from ..lang import T

sin, cos, pi, sqrt = math.sin, math.cos, math.pi, math.sqrt
PRIZES = [2000, 6000, 11000, 18000]


def rand(a, b):
    return a + random.random() * (b - a)


def _paint_bg():
    for i in range(13):
        f = i / 12
        lg.set_color(0.05 + 0.1 * (1 - f), 0.3 + 0.25 * (1 - f), 0.5 + 0.2 * (1 - f))
        lg.rectangle("fill", 0, 140 + i * 42, G.W, 43)


def _paint_ray():
    lg.set_color(1, 1, 1, 0.06)
    lg.polygon("fill", 0, 0, 60, 0, 160, 500, 90, 500)


def _paint_sand():
    lg.set_color(0.85, 0.75, 0.5)
    lg.ellipse("fill", 640, 70, 700, 70)


def tooth(rx, ry, d, ln, wid, glow, t, rotten=False):
    if rotten:
        lg.set_color(0.55, 0.45, 0.2)
        pts = (rx - wid, ry - d * 4, rx + wid, ry - d * 4, rx, ry + d * ln)
        lg.polygon("fill", *pts)
        lg.set_color(0.3, 0.38, 0.12); lg.circle("fill", rx - wid * 0.2, ry + d * ln * 0.3, wid * 0.35)
        lg.set_color(0.2, 0.15, 0.05); lg.circle("fill", rx + wid * 0.25, ry + d * ln * 0.15, wid * 0.22)
        lg.set_color(0.35, 0.28, 0.1); lg.set_line_width(1.5)
        lg.polygon("line", *pts)
        # little stink lines
        lg.set_color(0.5, 0.65, 0.25, 0.6 + 0.3 * sin(t * 6))
        lg.set_line_width(2)
        for k in (-1, 1):
            sx = rx + k * wid * 0.6
            lg.line(sx, ry - d * 8, sx + 3 * sin(t * 8 + k), ry - d * 16, sx, ry - d * 24)
        return
    if glow:
        lg.set_color(1, 0.85, 0.2, 0.45 + 0.3 * sin(t * 12))
        lg.circle("fill", rx, ry + d * ln * 0.45, wid * 1.8)
        lg.set_color(1, 0.88, 0.35)
    else:
        lg.set_color(0.98, 0.97, 0.92)
    pts = (rx - wid, ry - d * 4, rx + wid, ry - d * 4, rx, ry + d * ln)
    lg.polygon("fill", *pts)
    lg.set_color(0.7, 0.68, 0.62)
    lg.set_line_width(1.5)
    lg.polygon("line", *pts)


class Shark:
    def __init__(self):
        self.time, self.mag = 60, 6
        self.t = 0.0
        self.stats = {"teeth": 0, "gold": 0, "dazed": 0, "sharks": 0, "rotten": 0}
        self.angry = 0.0
        self.bonus = None
        self.finished = False
        self.level = 1
        self.bubbles = [{"x": rand(90, 1190), "y": rand(150, 640), "r": rand(3, 10), "sp": rand(30, 90), "ph": rand(0, 6)}
                        for _ in range(26)]
        self.flying = []
        self.newShark(True)

    def newShark(self, first):
        self.teeth = [{"up": True, "i": i, "n": 8, "alive": True} for i in range(1, 9)]
        self.teeth += [{"up": False, "i": i, "n": 7, "alive": True} for i in range(1, 8)]
        for t in self.teeth:
            t["rotten"] = False
        if not G.kids:   # one rotten tooth per shark: shoot it and he gets ANGRY
            random.choice(self.teeth)["rotten"] = True
        self.open = 0.0
        self.jaw = "opening"
        self.jawT = 0.0
        self.dizzy = 0.0
        self.glow = None
        self.glowT = 0.0
        self.leave = 0.0
        self.enter = 0.0 if first else 1.0
        self.snap = 0.0
        self.hurt = 0.0

    def speed(self):
        return (1 + (self.level - 1) * 0.3) * (1.7 if self.angry > 0 else 1)

    def sharkPos(self):
        sp = self.speed()
        x = 640 + sin(self.t * 0.7 * sp) * (40 + self.level * 25)
        y = 395 + sin(self.t * 1.3) * 8 + self.enter * 520 + self.leave * 560
        return x, y, 0.92 + self.snap * 0.08

    def mouth(self):
        x, y, k = self.sharkPos()
        return x, y + 52 * k, 172 * k, (16 + 118 * self.open) * k, k

    def toothGeom(self, tth):
        mx, my, mw, mh, k = self.mouth()
        if tth["up"]:
            a = pi + pi * (0.1 + 0.8 * (tth["i"] - 0.5) / tth["n"])
        else:
            a = pi * (0.12 + 0.76 * (tth["i"] - 0.5) / tth["n"])
        d = 1 if tth["up"] else -1
        return mx + cos(a) * mw, my + sin(a) * mh, d, 34 * k, 15 * k

    def aliveCount(self):
        # the rotten tooth doesn't count: knock out all the good ones to make him toothless
        return sum(1 for t in self.teeth if t["alive"] and not t["rotten"])

    def update(self, dt, active):
        self.t += dt
        for b in self.bubbles:
            b["y"] -= b["sp"] * dt
            if b["y"] < 140:
                b["y"], b["x"] = 650, rand(90, 1190)
        keep = []
        for f in self.flying:
            f["vy"] += 1600 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["y"] <= 800:
                keep.append(f)
        self.flying = keep
        self.snap = max(0.0, self.snap - dt * 4)
        self.hurt = max(0.0, self.hurt - dt * 3)
        self.angry = max(0.0, self.angry - dt)
        if self.enter > 0:
            self.enter = max(0.0, self.enter - dt * 1.4)
            return
        if self.leave > 0:
            self.leave += dt * 0.9
            if self.leave >= 1:
                self.level += 1
                self.newShark(False)
                A.play("splash", 0.8)
            return
        sp = self.speed()
        self.glowT -= dt
        if self.glowT <= 0 or (self.glow is not None and not self.glow["alive"]):
            alive = [t for t in self.teeth if t["alive"] and not t["rotten"]]
            self.glow = random.choice(alive) if alive else None
            self.glowT = 2.5
        if self.dizzy > 0:
            self.dizzy -= dt
            self.open = min(1.0, self.open + dt * 6)
            if self.dizzy <= 0:
                self.jaw, self.jawT = "open", 0.5
            return
        self.jawT -= dt
        if self.jaw == "opening":
            self.open = min(1.0, self.open + dt * 3 * sp)
            if self.open >= 1:
                self.jaw = "open"
                self.jawT = rand(0.35, 0.7) if self.angry > 0 else rand(1.3, 2.4) / sp
        elif self.jaw == "open":
            if self.jawT <= 0:
                self.jaw = "closing"
        elif self.jaw == "closing":
            self.open = max(0.0, self.open - dt * 9 * sp)
            if self.open <= 0:
                self.jaw = "closed"
                self.jawT = rand(0.2, 0.35) if self.angry > 0 else rand(0.5, 1.0) / sp
                self.snap = 1.0
                A.play("chomp", 1.0 if self.angry > 0 else 0.9, 0.9 + random.random() * 0.2)
                G.FX.addShake(9 if self.angry > 0 else 5)
        elif self.jaw == "closed":
            if self.jawT <= 0:
                self.jaw = "opening"

    def rottenHit(self, tth, x, y):
        """The rotten tooth: he gets angry, snaps his jaws shut and chomps faster for a while."""
        tth["alive"] = False
        self.stats["rotten"] += 1
        self.angry = 4.0
        self.dizzy = 0.0
        self.jaw = "closing"
        self.hurt = 1.0
        A.play("crack", 0.9, 0.7)
        A.play("buzzer", 0.5, 0.8)
        G.FX.burst(x, y, 14, [(0.45, 0.35, 0.15), (0.35, 0.5, 0.2)], 260)
        G.FX.addShake(12)
        return {"pts": -150, "penalty": True, "label": T("rotten_tooth"), "x": x, "y": y - 20}

    def knockTooth(self, tth, x, y):
        if tth["rotten"]:
            return self.rottenHit(tth, x, y)
        tth["alive"] = False
        self.stats["teeth"] += 1
        glow = self.glow is tth
        if glow:
            self.stats["gold"] += 1
        _, _, d, _, _ = self.toothGeom(tth)
        self.flying.append({"x": x, "y": y, "vx": rand(-260, 260), "vy": rand(-520, -300), "rot": 0.0, "vr": rand(-14, 14), "dir": d})
        G.FX.burst(x, y, 8, [G.C["white"], (0.9, 0.9, 0.85)], 220)
        A.play("crack", 0.9, 0.9 + random.random() * 0.25)
        if glow:
            A.play("gold", 0.8)
        self.hurt = 1.0
        if self.aliveCount() == 0:
            # toothless! the rotten tooth (if he still has it) just falls out on its own, free of charge
            for rt in self.teeth:
                if rt["alive"] and rt["rotten"]:
                    rt["alive"] = False
                    rx, ry, rd, rln, _ = self.toothGeom(rt)
                    self.flying.append({"x": rx, "y": ry + rd * rln * 0.4, "vx": rand(-120, 120), "vy": rand(-300, -200),
                                        "rot": 0.0, "vr": rand(-10, 10), "dir": rd, "rotten": True})
            self.stats["sharks"] += 1
            self.leave = 0.001
            A.play("bell", 0.8)
            self.bonus = [{"pts": 1000 * self.level, "label": T("toothless", 1000 * self.level), "x": 640, "y": 300}]
            G.FX.burst(640, 400, 70, None, 600)
        return {"pts": 300 if glow else 100, "label": T("gold_tooth") if glow else None, "big": glow,
                "color": G.C["gold"] if glow else G.C["white"], "x": x, "y": y}

    def shoot(self, x, y):
        if self.enter > 0 or self.leave > 0:
            return None
        sx, sy, k = self.sharkPos()
        if self.open > 0.4:
            for tth in self.teeth:
                if tth["alive"]:
                    rx, ry, d, ln, wid = self.toothGeom(tth)
                    cx, cy = rx, ry + d * ln * 0.4
                    if (x - cx) ** 2 + (y - cy) ** 2 < ((wid + 8) * G.hitR) ** 2:
                        return self.knockTooth(tth, cx, cy)
        for side in (-1, 1):
            ex, ey = sx + side * 172 * k, sy - 78 * k
            if (x - ex) ** 2 + (y - ey) ** 2 < (32 * k * G.hitR) ** 2:
                if self.dizzy <= 0:
                    self.dizzy = 2.6
                    self.stats["dazed"] += 1
                    A.play("squeak", 0.8, 0.6)
                    A.play("thud", 0.8)
                    G.FX.ring(ex, ey, G.C["yellow"], 50)
                    return {"pts": 150, "label": T("dazed"), "x": ex, "y": ey, "color": G.C["sky"]}
                return None
        dx, dy = (x - sx) / (310 * k), (y - sy) / (215 * k)
        if dx * dx + dy * dy < 1:
            A.play("thud", 0.6)
            G.FX.burst(x, y, 5, [(0.6, 0.65, 0.7)], 120)
        else:
            G.FX.burst(x, y, 6, [(0.7, 0.9, 1)], 150, "drop")
        return None

    def draw(self):
        t = self.t
        G.blit_cached("shark_bg", _paint_bg)
        ray = G.cached("shark_ray", (170, 500), _paint_ray)
        tgt = lg.get_target()
        for i in range(7):
            x = 150 + i * 170 + sin(t * 0.5 + i) * 30
            X, Y = lg.tp(x, 140)
            tgt.blit(ray, (int(X), int(Y)))
        G.blit_cached("shark_sand", _paint_sand, 0, 590, (G.W, 140))
        lg.set_line_width(9)
        for i in range(10):
            bx = 110 + i * 120
            lg.set_color(0.1, 0.55 + (i % 3) * 0.08, 0.3)
            pts = []
            for s in range(7):
                pts.append((bx + sin(t * 1.5 + s * 0.8 + i) * s * 4, 640 - s * 22))
            lg.line(pts)
        lg.set_line_width(2)
        for b in self.bubbles:
            lg.set_color(0.8, 0.95, 1, 0.45)
            lg.circle("line", b["x"] + sin(t * 2 + b["ph"]) * 6, b["y"], b["r"])

        sx, sy, k = self.sharkPos()
        lg.push()
        lg.translate(sx, sy)
        lg.scale(k, k)
        hurt = self.hurt
        lg.set_color(0.38, 0.45, 0.55)
        lg.polygon("fill", -290, 60, -420, 160, -250, 130)
        lg.polygon("fill", 290, 60, 420, 160, 250, 130)
        lg.polygon("fill", -50, -190, 20, -300, 60, -185)
        ang = min(1.0, self.angry)
        lg.set_color(0.48 + hurt * 0.2 + ang * 0.25, 0.55 - ang * 0.2, 0.65 - ang * 0.25)
        lg.ellipse("fill", 0, 0, 310, 215)
        lg.set_color(0.94, 0.95, 0.96)
        lg.ellipse("fill", 0, 80, 255, 125)
        lg.set_color(0.4, 0.46, 0.55)
        lg.set_line_width(4)
        for i in range(3):
            lg.line(-250 + i * 18, -20, -262 + i * 18, 40)
            lg.line(250 - i * 18, -20, 262 - i * 18, 40)
        lg.set_color(0.25, 0.28, 0.35)
        lg.ellipse("fill", -40, -120, 10, 5); lg.ellipse("fill", 40, -120, 10, 5)
        for side in (-1, 1):
            ex, ey = side * 172, -78
            lg.set_color(1, 1, 1); lg.circle("fill", ex, ey, 30)
            lg.set_color(0.2, 0.2, 0.25); lg.set_line_width(3); lg.circle("line", ex, ey, 30)
            if self.dizzy > 0:
                lg.set_line_width(5); lg.set_color(0.1, 0.1, 0.15)
                lg.line(ex - 14, ey - 14, ex + 14, ey + 14); lg.line(ex + 14, ey - 14, ex - 14, ey + 14)
            else:
                ax, ay = (Game.aim[0] - sx) / k - ex, (Game.aim[1] - sy) / k - ey
                d = sqrt(ax * ax + ay * ay) + 0.001
                px, py = ex + ax / d * min(12, d * 0.05), ey + ay / d * min(12, d * 0.05)
                if self.angry > 0:
                    lg.set_color(0.85, 0.1, 0.1)
                else:
                    lg.set_color(0.05, 0.05, 0.08)
                lg.circle("fill", px, py, 14)
                lg.set_color(1, 1, 1); lg.circle("fill", px - 4, py - 5, 4)
            lg.set_color(0.3, 0.34, 0.42); lg.set_line_width(9)
            if self.angry > 0:   # brows pulled right down
                lg.line(ex - side * 38, ey - 52, ex + side * 30, ey - 22)
            else:
                lg.line(ex - side * 34, ey - 46, ex + side * 30, ey - 34)
        lg.pop()

        mx, my, mw, mh, _ = self.mouth()
        lg.set_color(0.4, 0.03, 0.07); lg.ellipse("fill", mx, my, mw, mh)
        lg.set_color(0.9, 0.4, 0.5); lg.ellipse("fill", mx, my + mh * 0.55, mw * 0.55, mh * 0.35)
        lg.set_color(0.25, 0.02, 0.05); lg.set_line_width(5); lg.ellipse("line", mx, my, mw, mh)
        for tth in self.teeth:
            rx, ry, d, ln, wid = self.toothGeom(tth)
            if tth["alive"]:
                tooth(rx, ry, d, ln, wid, self.glow is tth, t, tth["rotten"])
            else:
                lg.set_color(0.6, 0.15, 0.2); lg.ellipse("fill", rx, ry, wid * 0.7, 5 * k)
        if self.angry > 0:   # steam puffs from his head
            for j in range(4):
                ph = (t * 1.5 + j * 0.25) % 1
                lg.set_color(1, 1, 1, 0.5 * (1 - ph))
                for side in (-1, 1):
                    lg.circle("fill", sx + side * (110 + ph * 50) * k, sy - (190 + ph * 90) * k, 10 + ph * 18)
        if self.dizzy > 0:
            for i in range(5):
                a = t * 4 + i / 5 * pi * 2
                G.star(sx + cos(a) * 120 * k, sy - 230 * k + sin(a) * 25, 14, G.C["yellow"], a)
        for f in self.flying:
            lg.push(); lg.translate(f["x"], f["y"]); lg.rotate(f["rot"])
            if f.get("rotten"):
                lg.set_color(0.55, 0.45, 0.2)
            else:
                lg.set_color(0.98, 0.97, 0.92); lg.polygon("fill", -14, -12, 14, -12, 0, 20)
            lg.pop()
        G.text(T("shark_status", self.level, self.aliveCount(), sum(1 for x in self.teeth if not x["rotten"])), 640, 590, G.F["ui20"], G.C["cream"], 600, 2)

    def demoTarget(self):
        if self.open > 0.6 and self.enter <= 0 and self.leave <= 0:
            for tth in self.teeth:
                if tth["alive"] and not tth["rotten"]:
                    rx, ry, d, ln, _ = self.toothGeom(tth)
                    return rx, ry + d * ln * 0.4
        sx, sy, k = self.sharkPos()
        return sx - 172 * k, sy - 78 * k


def new():
    return Shark()
