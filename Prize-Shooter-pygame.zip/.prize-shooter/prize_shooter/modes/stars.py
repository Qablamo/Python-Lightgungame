"""SHOOTING STARS: shoot paper stars off the peg board. The dial calls a colour: those stars pay 5x."""
import math
import random
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, cos, pi, floor, sqrt = math.sin, math.cos, math.pi, math.floor, math.sqrt
PRIZES = [1500, 4000, 8000, 13000]

COLORS = [None, G.C["red"], G.C["yellow"], G.C["blue"], G.C["green"], G.C["pink"], G.C["orange"]]
NCOL = 6
GOLD = (1.0, 0.84, 0.25)
BOMB = -1                      # col value of a bomb star (never in Kids mode)
BOMBC = (0.16, 0.16, 0.2)
BX, BY, BW, BH = 170, 168, 940, 410
WX, WY, WR = 640, 372, 158
FLOOR = 598


def colorOf(i):
    if i == BOMB:
        return BOMBC
    return GOLD if i == 0 else COLORS[i]


def _paint_board():
    lg.set_color(0.32, 0.4, 0.3); lg.rectangle("fill", 80, 580, 1120, 60)
    lg.set_color(0.25, 0.32, 0.24); lg.rectangle("fill", 80, 580, 1120, 4)
    lg.set_color(0.45, 0.28, 0.15); lg.rectangle("fill", BX - 16, BY - 14, BW + 32, BH + 28, 10)
    lg.set_color(0.78, 0.82, 0.8); lg.rectangle("fill", BX, BY, BW, BH, 6)
    lg.set_color(0.55, 0.6, 0.58)
    for px in range(BX + 12, BX + BW - 5, 24):
        for py in range(BY + 12, BY + BH - 5, 24):
            lg.rectangle("fill", px - 1.5, py - 1.5, 3, 3)
    lg.set_color(0.2, 0.2, 0.25); lg.circle("fill", WX + 4, WY + 6, WR)


class Stars:
    def __init__(self):
        self.time, self.mag, self.totalShots = 90, 10, 40
        self.t = 0.0
        self.stats = {"called": 0, "gold": 0, "bombs": 0}
        self.stars, self.ring, self.fallers = [], [], []
        self.bonus = None
        self.finished = False
        self.wheelA = 0.0
        self.call = 3
        self.callTimer = 7.0
        self.callPulse = 0.0
        self.refill = 0.0
        # splats are stamped once onto a floor layer instead of redrawn every frame
        self.splatLayer = pygame.Surface((G.W, 90), pygame.SRCALPHA)
        cols, rows = 13, 6
        sx, sy = BW / cols, BH / rows
        for r in range(rows):
            for c in range(cols):
                x, y = BX + sx * (c + 0.5), BY + sy * (r + 0.5)
                if sqrt((x - WX) ** 2 + (y - WY) ** 2) > WR + 30:
                    col = BOMB if (not G.kids and random.random() < 0.06) else random.randint(1, NCOL)
                    self.stars.append({"x": x, "y": y, "r": 23, "col": col, "alive": True,
                                       "scale": 1.0, "rot": random.random() * 0.6 - 0.3})
        for i in range(10):
            self.ring.append({"a": i / 10 * pi * 2, "r": 21, "col": i % NCOL + 1, "alive": True, "scale": 1.0, "respawn": 0.0})
        self.pickCall()

    def pickCall(self):
        counts = {}
        for s in self.stars:
            if s["alive"] and s["col"] > 0:
                counts[s["col"]] = counts.get(s["col"], 0) + 1
        best, bc = self.call, -1
        for i in range(1, NCOL + 1):
            c = counts.get(i, 0) + random.random() * 3
            if i != self.call and c > bc:
                best, bc = i, c
        self.call = best
        self.callTimer = 7.0
        self.callPulse = 1.0

    def ringPos(self, s):
        a = s["a"] + self.wheelA
        return WX + cos(a) * (WR - 44), WY + sin(a) * (WR - 44)

    def update(self, dt, active):
        self.t += dt
        self.wheelA += 0.9 * sin(self.t * 0.35) * dt * 1.6
        self.callPulse = max(0.0, self.callPulse - dt * 2)
        if active:
            self.callTimer -= dt
            if self.callTimer <= 0:
                self.pickCall()
                A.play("whistle", 0.4, 1.2)
        for s in self.stars:
            if s["alive"]:
                s["scale"] = min(1.0, s["scale"] + dt * 4)
        for s in self.ring:
            if s["alive"]:
                s["scale"] = min(1.0, s["scale"] + dt * 4)
            else:
                s["respawn"] -= dt
                if s["respawn"] <= 0:
                    s["alive"], s["scale"], s["col"] = True, 0.0, random.randint(1, NCOL)
        self.refill -= dt
        if self.refill <= 0:
            self.refill = 0.9
            empty = [s for s in self.stars if not s["alive"]]
            if empty:
                s = random.choice(empty)
                s["alive"], s["scale"] = True, 0.0
                roll = random.random()
                if roll < 0.05:
                    s["col"] = 0
                elif roll < 0.12 and not G.kids:
                    s["col"] = BOMB
                elif roll < 0.4:
                    s["col"] = self.call
                else:
                    s["col"] = random.randint(1, NCOL)
        keep = []
        for f in self.fallers:
            f["vy"] += 1500 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["y"] > f["floor"]:
                if f["bounced"]:
                    self.stamp(f)
                    continue
                f["bounced"] = True
                f["y"] = f["floor"]
                f["vy"] = -f["vy"] * 0.3
                f["vx"] *= 0.5
            keep.append(f)
        self.fallers = keep

    def stamp(self, f):
        lg.push_target(self.splatLayer); lg.push(); lg.origin()
        lg.translate(f["x"], f["floor"] - 570); lg.scale(1, 0.38)
        G.col(colorOf(f["col"]), 0.9)
        lg.polygon("fill", G.starPoly(0, 0, f["r"] * 0.8, 5, 0.5, f["rot"]))
        lg.pop(); lg.pop_target()

    def hitStar(self, s, x, y, ring):
        s["alive"] = False
        if s["col"] == BOMB:
            self.stats["bombs"] += 1
            A.play("boom", 1)
            G.FX.addShake(14)
            G.FX.burst(x, y, 40, [G.C["orange"], G.C["yellow"], (0.2, 0.2, 0.2)], 480)
            G.FX.ring(x, y, G.C["orange"], 70)
            return {"pts": -200, "penalty": True, "label": T("boom"), "x": x, "y": y - 30}
        if ring:
            s["respawn"] = 3.0
        c = colorOf(s["col"])
        self.fallers.append({"x": x, "y": y, "vx": (random.random() - 0.5) * 220, "vy": -260 - random.random() * 120,
                             "rot": 0.0, "vr": (random.random() - 0.5) * 16, "col": s["col"], "r": s["r"],
                             "floor": FLOOR + random.random() * 22, "bounced": False})
        G.FX.burst(x, y, 10, [c, G.C["white"]], 240, "star")
        G.FX.ring(x, y, c, 40)
        label, big = None, False
        if s["col"] == 0:
            self.stats["gold"] += 1
            pts, label, big, color = 400, T("gold_star"), True, GOLD
            A.play("gold", 0.9)
        elif s["col"] == self.call:
            self.stats["called"] += 1
            pts, color = 150, c
            A.play("pop", 0.9, 1.1)
            A.play("ding", 0.35, 1.5)
        else:
            pts, color = 30, (0.9, 0.9, 0.9)
            A.play("pop", 0.8, 0.9 + random.random() * 0.2)
        if ring:
            pts = floor(pts * 1.5)
        return {"pts": pts, "label": label, "big": big, "color": color, "x": x, "y": y}

    def shoot(self, x, y):
        for s in self.ring:
            if s["alive"]:
                sx, sy = self.ringPos(s)
                if (x - sx) ** 2 + (y - sy) ** 2 < ((s["r"] + 6) * G.hitR) ** 2:
                    return self.hitStar(s, sx, sy, True)
        for s in self.stars:
            if s["alive"] and (x - s["x"]) ** 2 + (y - s["y"]) ** 2 < ((s["r"] + 7) * G.hitR) ** 2:
                return self.hitStar(s, s["x"], s["y"], False)
        return None

    def draw(self):
        G.wall((0.1, 0.5, 0.5))
        G.blit_cached("stars_board", _paint_board)
        lg.get_target().blit(self.splatLayer, lg.tp(0, 570))
        t = self.t
        for s in self.stars:
            if s["alive"]:
                sc = s["scale"] * (1.3 - 0.3 * s["scale"]) if s["scale"] < 1 else 1
                pulse = (1 + 0.06 * sin(t * 8)) if s["col"] == self.call else 1
                G.star(s["x"], s["y"], s["r"] * sc * pulse, colorOf(s["col"]), -pi / 2 + s["rot"])
                if s["col"] == BOMB and sc >= 1:
                    G.bombIcon(s["x"], s["y"] + 3, 8, t + s["x"])
                if s["col"] > 0 and sc >= 1:
                    G.colorSymbol(s["col"], s["x"], s["y"] + 1, 5)
                if s["col"] == 0:
                    lg.set_color(1, 1, 1, 0.6 + 0.4 * sin(t * 10))
                    lg.circle("fill", s["x"] + 10, s["y"] - 12, 3)
        lg.set_color(0.32, 0.3, 0.36); lg.circle("fill", WX, WY, WR)
        for i in range(20):
            a = self.wheelA + i / 20 * pi * 2
            if i % 2 == 0:
                lg.set_color(0.4, 0.38, 0.45)
            else:
                lg.set_color(0.3, 0.28, 0.34)
            lg.arc("fill", WX, WY, WR - 4, a, a + pi / 10)
        chase = floor(t * 10)
        for i in range(24):
            a = i / 24 * pi * 2
            G.bulb(WX + cos(a) * (WR - 6), WY + sin(a) * (WR - 6), (i + chase) % 4 == 0, (1, 0.9, 0.5), 4)
        for s in self.ring:
            if s["alive"]:
                sx, sy = self.ringPos(s)
                G.star(sx, sy, s["r"] * s["scale"], colorOf(s["col"]), self.wheelA * 2)
                if s["col"] > 0 and s["scale"] >= 1:
                    G.colorSymbol(s["col"], sx, sy + 1, 5)
        cc = COLORS[self.call]
        warn = self.callTimer < 1.2 and (t * 8) % 1 < 0.5
        lg.set_color(0.98, 0.94, 0.82); lg.circle("fill", WX, WY, 62)
        G.col(G.C["white"] if warn else cc); lg.set_line_width(6); lg.circle("line", WX, WY, 62)
        G.text(T("shoot"), WX, WY - 58, G.F["ui16"], G.C["darkred"], 120, 0)
        ps = 1 + self.callPulse * 0.5
        G.star(WX, WY + 2, 30 * ps, cc, t)
        G.colorSymbol(self.call, WX, WY + 3, 8)
        G.text(T("col_%d" % self.call), WX, WY + 34, G.F["ui16"], G.C["darkred"], 120, 0)
        for f in self.fallers:
            G.star(f["x"], f["y"], f["r"], colorOf(f["col"]), f["rot"])

    def demoTarget(self):
        lst = [s for s in self.stars if s["alive"] and s["scale"] >= 1 and (s["col"] == self.call or s["col"] == 0)]
        if not lst:
            lst = [s for s in self.stars if s["alive"] and s["scale"] >= 1 and s["col"] != BOMB]
        if lst:
            s = random.choice(lst)
            return s["x"], s["y"]
        return 640, 360


def new():
    return Stars()
