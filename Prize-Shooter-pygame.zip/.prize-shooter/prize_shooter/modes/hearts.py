"""HEART SHOOTING: hearts on a spinning wheel. Dead centre = straight to the heart (2x). The big heart takes 3 hits."""
import math
import random
from .. import gfx as G
from .. import lg
from .. import audio as A
from ..lang import T

sin, cos, pi, floor, sqrt = math.sin, math.cos, math.pi, math.floor, math.sqrt

WX, WY, WR = 640, 385, 215
PINKS = [(0.95, 0.15, 0.3), (1, 0.4, 0.65), (0.85, 0.1, 0.45), (1, 0.55, 0.75)]
GOLD = (1, 0.8, 0.2)
BIGC = (0.9, 0.05, 0.25)


def rand(a, b):
    return a + random.random() * (b - a)


def _paint_bg():
    lg.set_color(0.45, 0.06, 0.16); lg.rectangle("fill", 0, 0, G.W, G.H)
    for gx in range(23):
        for gy in range(10):
            lg.set_color(0.55, 0.1, 0.22); G.heartShape(100 + gx * 50 + (gy % 2) * 25, 160 + gy * 50, 7)
    for side in (-1, 1):
        x = WX + side * 400
        lg.set_color(1, 0.5, 0.75); lg.set_line_width(5); G.heartShape(x, 300, 52, "line")
        G.text(T("love"), x, 420, G.F["sign34"], (1, 0.6, 0.8), 220, 2)
    lg.set_color(0, 0, 0, 0.35); lg.circle("fill", WX + 6, WY + 8, WR)


class Hearts:
    def __init__(self):
        self.time, self.mag = 60, 8
        self.t = self.elapsed = 0.0
        self.stats = {"hearts": 0, "centers": 0, "big": 0, "gold": 0}
        self.bonus = None
        self.finished = False
        self.angle, self.speed, self.dir, self.dirT = 0.0, 0.8, 1, 7.0
        self.outer = [{"a": i / 10 * pi * 2, "r": 30, "alive": True, "pop": 1.0, "col": PINKS[(i + 1) % 4], "gold": False, "respawn": 0}
                      for i in range(10)]
        self.inner = [{"a": i / 6 * pi * 2, "r": 24, "alive": True, "pop": 1.0, "col": PINKS[(i + 2) % 4], "gold": False, "respawn": 0}
                      for i in range(6)]
        self.big = {"hp": 3, "alive": True, "pop": 1.0, "respawn": 0.0, "shake": 0.0}
        self.halves = []

    def ring(self, name):
        return self.outer if name == "outer" else self.inner

    def pos(self, h, ring):
        if ring == "outer":
            a = h["a"] + self.angle
            return WX + cos(a) * 158, WY + sin(a) * 158
        a = h["a"] - self.angle * 1.6
        return WX + cos(a) * 92, WY + sin(a) * 92

    def update(self, dt, active):
        self.t += dt
        if active:
            self.elapsed += dt
        self.dirT -= dt
        if self.dirT <= 0:
            self.dirT = rand(6, 10)
            self.dir = -self.dir
        self.speed += ((self.dir * (0.7 + self.elapsed / 70)) - self.speed) * min(1, dt * 1.5)
        self.angle += self.speed * dt
        for ring in (self.outer, self.inner):
            for h in ring:
                if h["alive"]:
                    h["pop"] = min(1.0, h["pop"] + dt * 4)
                else:
                    h["respawn"] -= dt
                    if h["respawn"] <= 0:
                        h["alive"], h["pop"] = True, 0.0
                        h["gold"] = random.random() < 0.08
                        h["col"] = random.choice(PINKS)
        B = self.big
        B["shake"] = max(0.0, B["shake"] - dt * 4)
        if B["alive"]:
            B["pop"] = min(1.0, B["pop"] + dt * 3)
        else:
            B["respawn"] -= dt
            if B["respawn"] <= 0:
                B["alive"], B["hp"], B["pop"] = True, 3, 0.0
                A.play("chime", 0.5, 0.8)
        keep = []
        for f in self.halves:
            f["vy"] += 1400 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vr"] * dt
            if f["y"] <= 800:
                keep.append(f)
        self.halves = keep

    def breakHeart(self, x, y, r, c):
        self.halves.append({"x": x - r * 0.3, "y": y, "vx": rand(-220, -120), "vy": rand(-380, -240), "rot": 0.0, "vr": rand(-8, -3), "r": r, "col": c, "side": -1})
        self.halves.append({"x": x + r * 0.3, "y": y, "vx": rand(120, 220), "vy": rand(-380, -240), "rot": 0.0, "vr": rand(3, 8), "r": r, "col": c, "side": 1})
        G.FX.burst(x, y, 16, [c, G.C["white"], G.C["pink"]], 300, "star")

    def shoot(self, x, y):
        R = G.hitR
        for name in ("inner", "outer"):
            for h in self.ring(name):
                if h["alive"] and h["pop"] >= 1:
                    hx, hy = self.pos(h, name)
                    d = sqrt((x - hx) ** 2 + (y - hy) ** 2)
                    if d < (h["r"] + 6) * R:
                        h["alive"] = False
                        h["respawn"] = 4.0
                        self.stats["hearts"] += 1
                        self.breakHeart(hx, hy, h["r"], GOLD if h["gold"] else h["col"])
                        pts = 90 if name == "inner" else 60
                        label, big = None, False
                        if h["gold"]:
                            pts, label, big = 250, T("golden_heart"), True
                            self.stats["gold"] += 1
                            A.play("gold", 0.8)
                        if d < h["r"] * 0.4 * R:
                            pts *= 2
                            label, big = T("to_the_heart"), True
                            self.stats["centers"] += 1
                            A.play("chime", 0.8, 1.2)
                            G.FX.ring(hx, hy, G.C["pink"], 60)
                        A.play("pop", 0.9, 1.1 + random.random() * 0.2)
                        A.play("ding", 0.3, 1.8)
                        return {"pts": pts, "label": label, "big": big, "color": G.C["pink"] if big else G.C["cream"], "x": hx, "y": hy - 30}
        B = self.big
        if B["alive"] and B["pop"] >= 1 and sqrt((x - WX) ** 2 + (y - WY) ** 2) < 52 * R:
            B["hp"] -= 1
            B["shake"] = 1.0
            A.play("wood", 0.8, 1.3)
            if B["hp"] <= 0:
                B["alive"] = False
                B["respawn"] = 6.0
                self.stats["big"] += 1
                self.breakHeart(WX, WY, 52, BIGC)
                G.FX.burst(WX, WY, 60, [G.C["red"], G.C["pink"], G.C["white"], G.C["gold"]], 600, "star")
                G.FX.addShake(8)
                A.play("chime", 1, 0.8)
                A.play("bell", 0.6)
                return {"pts": 300, "label": T("big_heart"), "big": True, "color": G.C["pink"], "x": WX, "y": WY - 70}
            G.FX.burst(x, y, 8, [G.C["red"], G.C["white"]], 200)
            return {"pts": 30, "x": x, "y": y - 30, "color": G.C["cream"]}
        return None

    def demoTarget(self):
        for name in ("outer", "inner"):
            lst = [h for h in self.ring(name) if h["alive"] and h["pop"] >= 1]
            if lst:
                return self.pos(random.choice(lst), name)
        return WX, WY

    def draw(self):
        t = self.t
        G.blit_cached("hearts_bg", _paint_bg)
        for side in (-1, 1):
            lg.set_blend("add")
            lg.set_color(1, 0.3, 0.6, 0.18 + 0.1 * sin(t * 5 + side))
            G.heartShape(WX + side * 400, 300, 70)
            lg.set_blend("alpha")
        lg.set_color(0.98, 0.95, 0.9); lg.circle("fill", WX, WY, WR)
        for i in range(16):
            a = self.angle + i / 16 * pi * 2
            if i % 2 == 0:
                lg.set_color(1, 0.85, 0.9)
            else:
                lg.set_color(0.98, 0.95, 0.9)
            lg.arc("fill", WX, WY, WR - 6, a, a + pi / 8)
        lg.set_color(0.8, 0.6, 0.2); lg.set_line_width(8); lg.circle("line", WX, WY, WR)
        chase = floor(t * 10)
        for i in range(30):
            a = i / 30 * pi * 2
            G.bulb(WX + cos(a) * WR, WY + sin(a) * WR, (i + chase) % 3 == 0, (1, 0.5, 0.75), 5)
        for name in ("outer", "inner"):
            for h in self.ring(name):
                if h["alive"] and h["pop"] > 0:
                    x, y = self.pos(h, name)
                    s = h["pop"] * (1.3 - 0.3 * h["pop"]) if h["pop"] < 1 else (1 + 0.05 * sin(t * 6 + h["a"] * 3))
                    G.heart(x, y, h["r"] * s, GOLD if h["gold"] else h["col"], sin(t * 2 + h["a"]) * 0.15)
                    if h["gold"]:
                        lg.set_color(1, 1, 1, 0.5 + 0.5 * sin(t * 10)); lg.circle("fill", x + 12, y - 14, 3)
        B = self.big
        if B["alive"] and B["pop"] > 0:
            beat = 1 + 0.07 * max(0, sin(t * 7)) ** 4
            sh = B["shake"] * 6 * sin(t * 60)
            s = min(1, B["pop"]) * beat
            G.heart(WX + sh, WY, 52 * s, BIGC, 0)
            lg.set_color(0.35, 0, 0.1); lg.set_line_width(3)
            if B["hp"] <= 2:
                lg.line(WX - 10, WY - 30, WX + 4, WY - 6, WX - 6, WY + 10)
            if B["hp"] <= 1:
                lg.line(WX + 20, WY - 26, WX + 8, WY, WX + 22, WY + 20)
            G.text(str(B["hp"]), WX + sh, WY - 22, G.F["ui26"], G.C["white"], 60, 2)
        for f in self.halves:
            lg.push(); lg.translate(f["x"], f["y"]); lg.rotate(f["rot"])
            r, s = f["r"], f["side"]
            G.col(f["col"])
            lg.circle("fill", s * r * 0.5, -r * 0.22, r * 0.56)
            lg.polygon("fill", 0, -r * 0.05, s * r * 1.03, -r * 0.05, 0, r)
            lg.set_color(0.35, 0, 0.1); lg.set_line_width(2)
            lg.line(0, -r * 0.4, s * r * 0.12, -r * 0.1, 0, r * 0.2, s * r * 0.1, r * 0.5)
            lg.pop()


def new():
    return Hearts()
