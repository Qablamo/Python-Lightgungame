from .. import gfx as G
from .. import audio as A
from .. import settings as S
from .. import game as Game
from ..ui import Button
from ..lang import T

RELOADS = ["auto", "manual", "pump"]


def _next_reload():
    if S.reload in RELOADS:
        return RELOADS[(RELOADS.index(S.reload) + 1) % len(RELOADS)]
    return "auto"


def _set(name, value):
    setattr(S, name, value)


def _music_click():
    if S.musicOn == 0:
        S.musicOn = 1
    else:
        S.music = (S.music + 1) % 11


def _custom(name, fn):
    def f():
        S.toCustom()
        _set(name, fn())
    return f


OPTIONS = [
    ("set_diff", lambda: T("diff_" + S.difficulty), lambda: S.setDifficulty(S.nextDifficulty())),
    ("set_reload", lambda: T("reload_" + S.reload), _custom("reload", _next_reload)),
    ("set_kids", lambda: T("on") if S.kids == 1 else T("off"), _custom("kids", lambda: 1 - S.kids)),
    ("set_players", lambda: T("players_%d" % S.players), lambda: _set("players", 2 if S.players == 1 else 1)),
    ("set_lang", lambda: T("lang_name"), lambda: _set("lang", "nl" if S.lang == "en" else "en")),
    ("set_music", lambda: ("%d%%" % (S.music * 10)) if S.musicOn == 1 else T("off"), _music_click),
    ("set_sfx", lambda: "%d%%" % (S.sfx * 10), lambda: _set("sfx", (S.sfx + 1) % 11)),
    ("set_border", lambda: T("border_%d" % S.border), lambda: _set("border", (S.border + 1) % 4)),
    ("set_cross", lambda: T("cross_%d" % S.crosshair), _custom("crosshair", lambda: (S.crosshair + 1) % 3)),
    ("set_theme", lambda: T("theme_" + S.theme), lambda: _set("theme", "day" if S.theme == "evening" else "evening")),
    ("set_symbols", lambda: T("on") if S.symbols == 1 else T("off"), lambda: _set("symbols", 1 - S.symbols)),
    ("set_full", lambda: T("on") if S.fullscreen == 1 else T("off"), lambda: _set("fullscreen", 1 - S.fullscreen)),
]


class SettingsScreen:
    def enter(self):
        A.music("menu")
        self.buttons = []
        self.rows = []
        for i, opt in enumerate(OPTIONS):
            col = 0 if i < 6 else 1
            row = i if i < 6 else i - 6
            lx = 100 if col == 0 else 650
            y = 158 + row * 62

            def click(opt=opt):
                opt[2]()
                Game.apply_settings()
                S.save()
                self.refreshLabels()
            b = Button(lx + 245, y, 280, 48, opt[1](), G.F["sign22"], G.C["blue"], onShoot=click)
            b.opt = opt
            self.buttons.append(b)
            self.rows.append((opt[0], lx, y))

        def back():
            S.save()
            Game.switch("menu")
        self.buttons.append(Button(760, 556, 300, 60, T("back"), G.F["sign34"], G.C["red"], onShoot=back))

    def refreshLabels(self):
        for b in self.buttons:
            b.label = b.opt[1]() if b.opt else T("back")

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self):
        G.wall((0.22, 0.14, 0.35), "diamond")
        G.boothFront(T("settings"), G.T)
        for key, x, y in self.rows:
            G.text(T(key), x + 115, y + 10, G.F["sign22"], G.C["cream"], 235, 3)
        for b in self.buttons:
            b.draw(Game.aim[0], Game.aim[1])
        G.counter()
        G.text(T("set_hint1"), G.W / 2, 646, G.F["ui16"], G.C["cream"], 1100, 2)
        G.text(T("set_hint2"), G.W / 2, 676, G.F["ui16"], G.C["cream"], 1100, 2)

    def shoot(self, x, y, off):
        if off:
            A.play("reload", 0.7)
            return
        A.play("shot", 0.7)
        for b in self.buttons:
            if b.shoot(x, y):
                return
        G.FX.mark(x, y)

    def back(self):
        S.save()
        Game.switch("menu")
