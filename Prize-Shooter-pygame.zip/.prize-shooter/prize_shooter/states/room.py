"""Her bedroom: every toy you've won finds a spot."""
import math
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import game as Game
from .. import challenges as C
from .. import prizes as P
from ..ui import Button
from ..lang import T

sin, floor = math.sin, math.floor

SLOTS = {t: {} for t in range(1, 6)}
for i in range(1, 5):
    SLOTS[1][i] = (548 + (i - 1) * 56, 318)
for i in range(5, 9):
    SLOTS[1][i] = (800 + (i - 5) * 52, 232)
for i in range(1, 5):
    SLOTS[2][i] = (800 + (i - 1) * 52, 332)
for i in range(5, 9):
    SLOTS[2][i] = (800 + (i - 5) * 52, 432)
for i in range(1, 9):
    SLOTS[3][i] = (110 + (i - 1) * 48, 478)
    SLOTS[4][i] = (90 + (i - 1) * 64, 676)
SLOTS[5][2] = (1110, 170)
_jx = [640, 720, 800, 880, 960, 1040, 1150]
_k = 0
for i in range(1, 9):
    if i != 2:
        SLOTS[5][i] = (_jx[_k], 700)
        _k += 1


def slotFor(mode, tier):
    return SLOTS[tier].get(C.MODES.index(mode) + 1)


def shelf(x, y, w):
    lg.set_color(0, 0, 0, 0.2); lg.rectangle("fill", x + 4, y + 4, w, 12)
    lg.set_color(0.95, 0.9, 0.95); lg.rectangle("fill", x, y, w, 12, 3)
    lg.set_color(0.8, 0.72, 0.82); lg.polygon("fill", x + 14, y + 12, x + 30, y + 12, x + 14, y + 30)
    lg.polygon("fill", x + w - 14, y + 12, x + w - 30, y + 12, x + w - 14, y + 30)


def paint_back():
    lg.set_color(0.86, 0.78, 0.95); lg.rectangle("fill", 0, 0, G.W, G.H)
    for gx in range(27):
        for gy in range(13):
            lg.set_color(0.92, 0.85, 1); lg.circle("fill", gx * 50 + (gy % 2) * 25, gy * 50, 6)
    lg.set_color(0.78, 0.6, 0.42); lg.rectangle("fill", 0, 560, G.W, 160)
    for i in range(11):
        lg.set_color(0.72, 0.55, 0.38); lg.rectangle("fill", 0, 560 + i * 16, G.W, 2)
    lg.set_color(0.98, 0.7, 0.8); lg.ellipse("fill", 820, 650, 330, 50)
    lg.set_color(1, 0.82, 0.88); lg.ellipse("fill", 820, 650, 280, 38)
    lg.set_color(0.15, 0.13, 0.32); lg.rectangle("fill", 530, 90, 230, 220)


def paint_front():
    lg.set_color(1, 0.95, 0.75); lg.circle("fill", 720, 130, 18)
    lg.set_color(0.15, 0.13, 0.32); lg.circle("fill", 712, 124, 15)
    lg.set_color(0.95, 0.93, 0.98); lg.set_line_width(8); lg.rectangle("line", 530, 90, 230, 220)
    lg.line(645, 90, 645, 310); lg.line(530, 200, 760, 200)
    lg.set_color(0.95, 0.5, 0.65)
    lg.polygon("fill", 500, 80, 560, 80, 535, 330, 500, 330)
    lg.polygon("fill", 790, 80, 730, 80, 755, 330, 790, 330)
    lg.set_color(0.9, 0.85, 0.95); lg.rectangle("fill", 520, 318, 250, 14, 4)
    shelf(780, 232, 210); shelf(780, 332, 210); shelf(780, 432, 210)
    lg.set_color(0.98, 0.95, 0.98); lg.rectangle("fill", 1020, 170, 190, 420, 6)
    lg.set_line_width(1)
    lg.set_color(0.85, 0.78, 0.9); lg.rectangle("line", 1030, 185, 82, 380, 4); lg.rectangle("line", 1118, 185, 82, 380, 4)
    lg.set_color(0.95, 0.6, 0.75); lg.circle("fill", 1100, 380, 6); lg.circle("fill", 1130, 380, 6)
    lg.set_color(0.95, 0.88, 0.95); lg.rectangle("fill", 60, 360, 30, 230, 8)
    lg.set_color(0.98, 0.98, 1); lg.rectangle("fill", 70, 470, 420, 70, 10)
    lg.set_color(1, 0.65, 0.78); lg.rectangle("fill", 160, 470, 330, 100, 10)
    for i in range(6):
        lg.set_color(1, 0.8, 0.88); G.heartShape(200 + i * 52, 515, 10)
    lg.set_color(0.98, 0.98, 1); lg.ellipse("fill", 130, 466, 50, 18)
    lg.set_color(0.85, 0.78, 0.9); lg.rectangle("fill", 80, 560, 14, 40); lg.rectangle("fill", 470, 560, 14, 40)
    lg.set_color(0.9, 0.85, 0.95); lg.rectangle("fill", 506, 470, 8, 90)
    lg.set_color(1, 0.85, 0.5); lg.polygon("fill", 486, 470, 534, 470, 524, 440, 496, 440)
    for i in range(19):
        x = 190 + i * 50
        G.col(G.C["pink"] if i % 2 == 0 else G.C["sky"]); lg.polygon("fill", x, 18, x + 40, 18, x + 20, 44)


class Room:
    def enter(self):
        A.music("menu")
        self.wob = {}
        self.t = 0.0
        self.buttons = [Button(16, 14, 150, 56, T("back"), G.F["sign26"], G.C["red"], onShoot=lambda: Game.switch("shelf"))]

    def update(self, dt):
        self.t += dt
        for b in self.buttons:
            b.update(dt)
        for id_ in list(self.wob):
            self.wob[id_] -= dt * 1.5
            if self.wob[id_] <= 0:
                del self.wob[id_]

    def draw(self):
        t = self.t
        G.blit_cached("room_back", paint_back)
        for i in range(1, 19):
            lg.set_color(1, 1, 0.85, 0.4 + 0.5 * sin(t * 2 + i * 1.7))
            lg.circle("fill", 540 + (i * 53) % 210, 100 + (i * 37) % 120, 1.5 + (i % 3) * 0.5)
        for i in range(13):
            hue = (i + floor(t * 6)) % 3
            lg.set_color(1 if hue == 0 else 0.3, 0.9 if hue == 1 else 0.3, 1 if hue == 2 else 0.6)
            lg.circle("fill", 545 + i * 16, 270 + sin(i) * 4, 2.5)
        G.blit_cached("room_front", paint_front)
        lg.set_blend("add")
        lg.set_color(1, 0.85, 0.5, 0.045 + 0.015 * sin(t * 3)); lg.circle("fill", 510, 455, 95)
        lg.set_blend("alpha")

        lst = []
        for mode in C.MODES:
            for tier in range(1, 6):
                id_ = "%s%d" % (mode, tier)
                if C.has(id_):
                    s = slotFor(mode, tier)
                    if s:
                        lst.append((s[1], s[0], id_))
        lst.sort(key=lambda e: e[0])
        for y, x, id_ in lst:
            w = self.wob.get(id_, 0)
            breathe = sin(t * 2 + x) * 0.02
            P.drawOn(id_, x, y, 108, False, breathe + sin(w * 20) * w * 0.3)

        G.text(T("room"), 640, 40, G.F["sign46"], G.C["darkred"], 600, 3, (1, 1, 1))
        G.text(T("room_sub", C.count()), 640, 92, G.F["ui20"], G.C["darkred"], 600, 2, (1, 1, 1))
        for b in self.buttons:
            b.draw(Game.aim[0], Game.aim[1])

    def shoot(self, x, y, off):
        if off:
            return
        for b in self.buttons:
            if b.shoot(x, y):
                return
        A.play("shot", 0.5, 1.3)
        for mode in C.MODES:
            for tier in range(1, 6):
                id_ = "%s%d" % (mode, tier)
                if C.has(id_):
                    s = slotFor(mode, tier)
                    if s and abs(x - s[0]) < 32 and s[1] - 30 - tier * 14 < y < s[1]:
                        self.wob[id_] = 1.0
                        A.play("squeak", 0.8, 0.8 + tier * 0.1)
                        G.FX.burst(x, y, 12, [G.C["pink"], G.C["white"], G.C["yellow"]], 220, "star")
                        return

    def back(self):
        Game.switch("shelf")
