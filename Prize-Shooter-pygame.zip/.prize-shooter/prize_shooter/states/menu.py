import math
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from .. import challenges as C
from .. import prizes as P
from ..ui import Button
from ..lang import T
from ..modes.registry import MODES

sin, cos, pi = math.sin, math.cos, math.pi


def ic_stars(x, y, w, h):
    cx = x + w / 2
    G.star(cx - 50, y + 70, 26, G.C["yellow"], G.T * 0.8)
    G.star(cx + 48, y + 64, 22, G.C["pink"], -G.T)
    G.star(cx, y + 58, 36, G.C["sky"], G.T * 0.5)


def ic_shark(x, y, w, h):
    cx, cy = x + w / 2, y + 66
    op = 0.5 + 0.5 * sin(G.T * 3)
    lg.set_color(0.45, 0.52, 0.6); lg.ellipse("fill", cx, cy, 70, 46)
    lg.set_color(0.92, 0.93, 0.95); lg.ellipse("fill", cx, cy + 16, 56, 26)
    lg.set_color(0.45, 0.05, 0.08); lg.ellipse("fill", cx, cy + 14, 40, 6 + 16 * op)
    lg.set_color(1, 1, 1)
    for i in range(-3, 4):
        lg.polygon("fill", cx + i * 10 - 5, cy + 8 - 16 * op, cx + i * 10 + 5, cy + 8 - 16 * op, cx + i * 10, cy + 18 - 16 * op)
    lg.set_color(0.05, 0.05, 0.08); lg.circle("fill", cx - 36, cy - 14, 6); lg.circle("fill", cx + 36, cy - 14, 6)


def ic_ducks(x, y, w, h):
    cx = x + w / 2
    G.duck(cx - 40 + sin(G.T * 2) * 8, y + 80 + sin(G.T * 5) * 3, 0.75, 1)
    G.duck(cx + 50 + sin(G.T * 2) * 8, y + 84 + cos(G.T * 5) * 3, 0.55, 1, G.C["gold"])
    lg.set_color(0.2, 0.5, 0.95)
    for i in range(7):
        lg.circle("fill", x + 18 + i * 28, y + 108, 15)


def ic_rails(x, y, w, h):
    cx = x + w / 2
    lg.set_color(0.75, 0.6, 0.25); lg.rectangle("fill", x + 18, y + 104, w - 36, 6)
    G.bullseye(cx + sin(G.T * 1.6) * 45, y + 66, 36)


def ic_cans(x, y, w, h):
    cx = x + w / 2

    def can(px, py, c):
        lg.set_color(0.76, 0.78, 0.82); lg.rectangle("fill", px - 13, py - 18, 26, 36, 3)
        G.col(c); lg.rectangle("fill", px - 13, py - 9, 26, 18)
        lg.set_color(0.5, 0.52, 0.56); lg.rectangle("fill", px - 13, py - 18, 26, 3)
    lg.set_color(0.62, 0.4, 0.22); lg.rectangle("fill", x + 30, y + 104, w - 60, 8)
    can(cx - 42, y + 86, G.C["red"]); can(cx - 14, y + 86, G.C["blue"]); can(cx + 14, y + 86, G.C["green"]); can(cx + 42, y + 86, G.C["orange"])
    can(cx - 28, y + 49, G.C["purple"]); can(cx, y + 49, G.C["red"]); can(cx + 28, y + 49, G.C["blue"])
    lg.push(); lg.translate(cx, y + 30); lg.rotate(sin(G.T * 3) * 0.08)
    can(-14, -18, G.C["green"]); can(14, -18, G.C["orange"])
    lg.pop()


def ic_hearts(x, y, w, h):
    cx = x + w / 2
    lg.set_color(0.98, 0.95, 0.9); lg.circle("fill", cx, y + 64, 50)
    for i in range(6):
        a = G.T * 1.2 + i / 6 * pi * 2
        G.heart(cx + cos(a) * 36, y + 64 + sin(a) * 36, 11, G.C["red"] if i % 2 == 0 else G.C["pink"], 0)
    G.heart(cx, y + 64, 18 + 2 * max(0, sin(G.T * 7)) ** 4, (0.9, 0.05, 0.25), 0)


def ic_pyramid(x, y, w, h):
    cx = x + w / 2
    cols = [G.C["red"], G.C["blue"], G.C["green"], G.C["orange"]]
    for layer in range(1, 5):
        n = 5 - layer
        for i in range(1, n + 1):
            bx = cx + (i - (n + 1) / 2) * 32
            by = y + 112 - layer * 24
            lg.set_color(0.86, 0.68, 0.45); lg.rectangle("fill", bx - 15, by - 11, 30, 22, 3)
            G.col(cols[(layer + i) % 4]); lg.circle("fill", bx, by, 6)


def ic_balloons(x, y, w, h):
    cx = x + w / 2
    cols = [G.C["red"], G.C["yellow"], G.C["blue"], G.C["green"], G.C["pink"]]
    for i in range(1, 6):
        bx = cx + (i - 3) * 34
        by = y + 60 + sin(G.T * 2 + i) * 6 + (12 if i % 2 == 0 else 0)
        lg.set_color(0.9, 0.9, 0.9); lg.set_line_width(1); lg.line(bx, by + 22, bx, by + 50)
        G.col(cols[i - 1]); lg.ellipse("fill", bx, by, 16, 20)
        lg.set_color(1, 1, 1, 0.6); lg.ellipse("fill", bx - 6, by - 8, 4, 6)


ICONS = {"stars": ic_stars, "shark": ic_shark, "ducks": ic_ducks, "rails": ic_rails, "cans": ic_cans,
         "hearts": ic_hearts, "pyramid": ic_pyramid, "balloons": ic_balloons}


def mode_button(i, m):
    bw, bh = 254, 150
    c, r = i % 4, i // 4
    x, y = 104 + c * 270, 250 + r * 158
    mid = m["id"]
    b = Button(x, y, bw, bh, bg=m["color"], fg=G.C["cream"], onShoot=lambda: Game.playStand(mid))

    def icon(bx, by, w, h, hot):
        lg.push(); lg.translate(bx + w / 2, by + 2); lg.scale(0.6, 0.6); lg.translate(-102, 0)
        ICONS[mid](0, 0, 205, 210)
        lg.pop()
        G.text(T("name_" + mid), bx + w / 2, by + 74, G.F["sign22"], G.C["cream"], w - 14, 2)
        G.text(T("best", S.getBest(mid)), bx + w / 2, by + 100, G.F["ui16"], G.C["yellow"], w, 2)
        for t in range(1, 6):
            dx = bx + w / 2 + (t - 3) * 20
            if C.has("%s%d" % (mid, t)):
                G.star(dx, by + 131, 8, G.C["gold"] if t == 5 else G.C["pink"], 0)
            else:
                lg.set_color(0, 0, 0, 0.35); lg.circle("fill", dx, by + 131, 5)
    b.icon = icon
    return b


class Menu:
    lastCross = 1
    def enter(self):
        Game.tour = Game.duel = Game.demo = None
        Game.idle = 0
        A.music("menu")
        G.FX.clear()
        self.buttons = [mode_button(i, m) for i, m in enumerate(MODES)]

        tour = Button(104, 566, 290, 58, bg=G.C["pink"], onShoot=Game.startTour)

        def tour_icon(bx, by, w, h, hot):
            G.text(T("tour"), bx + w / 2, by + 4, G.F["sign26"], G.C["yellow"], w - 16, 3)
            G.text(T("tour_sub", S.getBest("tour")), bx + w / 2, by + 34, G.F["ui14"], G.C["cream"], w - 16, 2)
        tour.icon = tour_icon
        self.buttons.append(tour)

        shelf = Button(404, 566, 290, 58, bg=(0.55, 0.25, 0.5), onShoot=lambda: Game.switch("shelf"))

        def shelf_icon(bx, by, w, h, hot):
            G.text(T("prizes"), bx + w / 2 + 20, by + 4, G.F["sign26"], G.C["yellow"], w - 70, 3)
            G.text(T("shelf_count", C.count()), bx + w / 2 + 20, by + 34, G.F["ui14"], G.C["cream"], w - 70, 2)
            P.drawOn("hearts5", bx + 32, by + 54, 56)
        shelf.icon = shelf_icon
        self.buttons.append(shelf)
        self.buttons.append(Button(704, 566, 250, 58, T("settings"), G.F["sign26"], G.C["purple"], onShoot=lambda: Game.switch("settings")))
        self.buttons.append(Button(964, 566, 210, 58, T("quit"), G.F["sign26"], (0.3, 0.3, 0.35), onShoot=self.quit))

        def toggle(x, y, key, get, flip):
            b = Button(x, y, 210, 46, T(key, T("on") if get() else T("off")), G.F["sign22"], (0.2, 0.5, 0.45))

            def shot():
                flip(); S.save(); Game.apply_settings()
                b.label = T(key, T("on") if get() else T("off"))
                if key == "menu_music" and S.musicOn == 1:
                    A.current = None
                    A.music("menu")
            b.onShoot = shot
            b.getLabel = lambda: T(key, T("on") if get() else T("off"))
            self.buttons.append(b)

        def flip_cb():
            S.symbols = 1 - S.symbols

        def flip_mu():
            S.musicOn = 1 - S.musicOn

        def flip_cross():
            S.toCustom()
            if S.crosshair > 0:
                Menu.lastCross = S.crosshair
                S.crosshair = 0
            else:
                S.crosshair = Menu.lastCross
        toggle(104, 144, "menu_cb", lambda: S.symbols == 1, flip_cb)
        toggle(104, 196, "menu_cross", lambda: S.crosshair > 0, flip_cross)
        toggle(966, 144, "menu_music", lambda: S.musicOn == 1, flip_mu)
        # difficulty level: EASY / MEDIUM / HARD / CUSTOM (each level keeps its own high scores)
        lvl = Button(966, 196, 210, 46, "", G.F["sign22"], (0.55, 0.2, 0.25))

        def lvl_shot():
            S.setDifficulty(S.nextDifficulty())
            S.save()
            Game.apply_settings()
        lvl.onShoot = lvl_shot
        lvl.getLabel = lambda: T("menu_diff", T("diff_" + S.difficulty))
        lvl.label = lvl.getLabel()
        self.buttons.append(lvl)
        self.ducks = [{"x": i * 200, "y": 708, "alive": True, "flip": 1, "vy": 0, "gold": i == 3} for i in range(7)]
        self.t = 0.0

    def quit(self):
        S.save()
        Game.quit_requested = True

    def update(self, dt):
        self.t += dt
        for b in self.buttons:
            b.update(dt)
            gl = getattr(b, "getLabel", None)
            if gl:
                b.label = gl()
        for d in self.ducks:
            d["x"] += 90 * dt
            if d["x"] > G.W + 60:
                d.update(x=d["x"] - (G.W + 160), alive=True, flip=1, y=708, vy=0)
            if not d["alive"]:
                d["flip"] = max(-1, d["flip"] - dt * 6)
                d["vy"] += 900 * dt
                d["y"] += d["vy"] * dt

    def draw(self):
        G.wall(G.C["teal"], "diamond")
        G.boothFront(None, self.t)
        bob = sin(self.t * 2) * 3
        G.sign(330, 132 + bob, 620, 84, None, None, G.C["red"], None, self.t)
        G.text(T("game_title"), G.W / 2, 132 + bob + 4, G.F["sign64"], G.C["yellow"], 600, 4)
        G.text(T("subtitle"), G.W / 2, 220 + bob * 0.5, G.F["ui20"], G.C["cream"], 900, 3)
        for b in self.buttons:
            b.draw(Game.aim[0], Game.aim[1])
        G.counter()
        for d in self.ducks:
            G.duck(d["x"], d["y"], 0.42, 1, G.C["gold"] if d["gold"] else G.C["yellow"], d["flip"])
        G.text(T("menu_hint"), G.W / 2, 656, G.F["ui16"], G.C["cream"], 1000, 2)
        G.text(T("tickets", S.tickets), 1080, 636, G.F["ui16"], G.C["orange"], 220, 2)
        badges = []
        if S.kids == 1:
            badges.append(T("kids_on"))
        if S.players == 2:
            badges.append(T("players_2"))
        if S.reload == "pump":
            badges.append(T("reload_pump"))
        if badges:
            G.text("  -  ".join(badges), 200, 636, G.F["ui16"], G.C["pink"], 300, 2)

    def shoot(self, x, y, off):
        if off:
            A.play("reload", 0.7)
            return
        A.play("shot", 0.7)
        G.FX.mark(x, y)
        for d in self.ducks:
            if d["alive"] and abs(x - d["x"]) < 24 and abs(y - (d["y"] - 8)) < 22:
                d["alive"] = False
                d["vy"] = -300
                A.play("squeak", 0.9)
                G.FX.burst(d["x"], d["y"], 10, [G.C["yellow"], G.C["cream"]], 200)
                return
        for b in self.buttons:
            if b.shoot(x, y):
                return

    def back(self):
        self.quit()
