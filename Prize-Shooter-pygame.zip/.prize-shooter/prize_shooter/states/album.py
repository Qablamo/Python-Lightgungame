"""Photo album: the souvenir photos from the PHOTO target, as polaroids. Shoot one to enlarge it."""
import math
import os
import re
import pygame
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from ..ui import Button
from ..lang import T

PER = 6
_PAT = re.compile(r"^(photo|foto)_.*\.(png|bmp)$")


def label(f):
    m = re.search(r"_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})", f)
    if m:
        y, mo, d, h, mi = m.groups()
        return "%s-%s-%s  %s:%s" % (d, mo, y, h, mi)
    return ""


def polaroid(img, x, y, w, h, rot, lbl):
    lg.push(); lg.translate(x + w / 2, y + h / 2); lg.rotate(rot); lg.translate(-w / 2, -h / 2)
    lg.set_color(0, 0, 0, 0.35); lg.rectangle("fill", -4, 8, w + 16, h + 46)
    lg.set_color(0.98, 0.97, 0.94); lg.rectangle("fill", -8, -8, w + 16, h + 46)
    if img is not None:
        iw, ih = img.get_size()
        lg.set_color(1, 1, 1); lg.draw_surface(img, 0, 0, w / iw, h / ih)
    else:
        lg.set_color(0.2, 0.2, 0.25); lg.rectangle("fill", 0, 0, w, h)
    if lbl:
        G.text(lbl, w / 2, h + 8, G.F["ui14"], (0.25, 0.25, 0.35), w, 0)
    lg.set_color(0.95, 0.8, 0.3, 0.8); lg.rectangle("fill", w / 2 - 30, -16, 60, 18)
    lg.pop()


class Album:
    def enter(self):
        A.music("menu")
        try:
            self.files = sorted((f for f in os.listdir(S.SAVE_DIR) if _PAT.match(f)), reverse=True)
        except OSError:
            self.files = []
        self.cache = {}
        self.page = 1
        self.pages = max(1, math.ceil(len(self.files) / PER))
        self.zoom = None

        def prev():
            self.page = (self.page - 2) % self.pages + 1
            A.play("swish", 0.6)

        def nxt():
            self.page = self.page % self.pages + 1
            A.play("swish", 0.6)
        self.buttons = [
            Button(92, 640, 130, 62, T("back"), G.F["sign22"], G.C["red"], onShoot=lambda: Game.switch("shelf")),
            Button(230, 640, 70, 62, "<", G.F["sign34"], G.C["blue"], onShoot=prev),
            Button(306, 640, 70, 62, ">", G.F["sign34"], G.C["blue"], onShoot=nxt),
        ]

    def image(self, f, big=False):
        key = (f, big)
        if key not in self.cache:
            try:
                img = pygame.image.load(os.path.join(S.SAVE_DIR, f)).convert()
                # thumbnails are pre-scaled once so the Pi doesn't rescale every frame
                img = pygame.transform.smoothscale(img, (860, 484) if big else (290, 163))
                self.cache[key] = img
            except (pygame.error, OSError, ValueError):
                self.cache[key] = None
        return self.cache[key]

    def slot(self, k):
        c, r = k % 3, k // 3
        return 130 + c * 345, 160 + r * 238, (c - 1) * 0.05 + (-0.02 if r == 0 else 0.03)

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)
        if self.zoom:
            self.zoom["t"] = min(1.0, self.zoom["t"] + dt * 4)

    @staticmethod
    def _paint_bg():
        lg.set_color(0.25, 0.32, 0.3); lg.rectangle("fill", 0, 0, G.W, G.H)
        for i in range(23):
            lg.set_color(0.27 + (i % 2) * 0.02, 0.34, 0.32)
            lg.rectangle("fill", 80 + i * 52, 140, 50, 500)

    def draw(self):
        G.blit_cached("album_bg", self._paint_bg)
        G.boothFront(T("album"), G.T)
        if not self.files:
            G.text(T("album_empty"), G.W / 2, 360, G.F["ui26"], G.C["cream"], 900, 2)
        for k in range(PER):
            i = (self.page - 1) * PER + k
            if i < len(self.files):
                f = self.files[i]
                x, y, rot = self.slot(k)
                polaroid(self.image(f), x, y, 290, 163, rot, label(f))
        G.counter()
        for b in self.buttons:
            b.draw(Game.aim[0], Game.aim[1])
        G.text(T("page", self.page, self.pages), 700, 660, G.F["ui20"], G.C["yellow"], 500, 2)
        if self.zoom:
            z = self.zoom
            lg.set_color(0, 0, 0, 0.6 * z["t"]); lg.rectangle("fill", 0, 0, G.W, G.H)
            w, h = max(4, 860 * z["t"]), max(4, 484 * z["t"])
            polaroid(self.image(z["f"], True), G.W / 2 - w / 2, 300 - h / 2, w, h, 0, label(z["f"]) if z["t"] > 0.9 else None)

    def shoot(self, x, y, off):
        if off:
            return
        A.play("shot", 0.6)
        if self.zoom:
            self.zoom = None
            A.play("swish", 0.6)
            return
        for b in self.buttons:
            if b.shoot(x, y):
                return
        for k in range(PER):
            i = (self.page - 1) * PER + k
            if i < len(self.files):
                sx, sy, _ = self.slot(k)
                if sx - 8 < x < sx + 300 and sy - 8 < y < sy + 210:
                    self.zoom = {"f": self.files[i], "t": 0.0}
                    A.play("shutter", 0.5)
                    return

    def back(self):
        if self.zoom:
            self.zoom = None
        else:
            Game.switch("shelf")
