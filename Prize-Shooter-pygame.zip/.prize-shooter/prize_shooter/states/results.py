import math
import random
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from .. import challenges as C
from .. import prizes as P
from ..ui import Button
from ..lang import T
from ..modes import registry

floor, sin = math.floor, math.sin


def totalOf(r):
    acc = r["hits"] / r["shots"] if r["shots"] > 0 else 0
    bonus = floor(acc * 100) * 20
    return r["score"] + bonus, acc, bonus


class Results:
    def enter(self, d):
        self.t = 0.0
        self.duel = d.get("duel")
        if self.duel:
            t1, a1, _ = totalOf(self.duel[1])
            t2, a2, _ = totalOf(self.duel[2])
            self.duelTotals = {1: (t1, a1), 2: (t2, a2)}
            self.winner = 1 if t1 > t2 else (2 if t2 > t1 else 0)
            best = self.duel[2 if self.winner == 2 else 1]
            d = dict(best)
            d["duel"] = self.duel
        self.d = d
        self.total, self.acc, self.bonus = totalOf(d)
        mod = registry.module(d["mode"])
        th = getattr(mod, "PRIZES", None) or [1500, 4000, 7500, 12000]
        tour = Game.tour
        self.tour = tour
        self.tourDone = False
        judged = self.total
        if tour:
            tour["total"] += self.total
            self.tourDone = tour["idx"] >= len(tour["list"])
            if self.tourDone:
                th = [6000, 14000, 24000, 36000]
                judged = tour["total"]
            else:
                th = []
        self.tier = 0
        for i, v in enumerate(th):
            if judged >= v:
                self.tier = i + 1
        if tour:
            self.newBest = self.tourDone and tour["total"] > S.getBest("tour")
            if self.newBest:
                S.best[S.bestKey("tour")] = tour["total"]
                S.save()
        else:
            self.newBest = self.total > S.getBest(d["mode"])
            if self.newBest:
                S.best[S.bestKey(d["mode"])] = self.total
                S.save()
        if self.duel:
            self.won = C.evaluate(d["mode"], self.duel[1]) + C.evaluate(d["mode"], self.duel[2])
            self.won.sort(key=lambda i: -P.ITEMS[i]["tier"])
        else:
            self.won = C.evaluate(d["mode"], d)

        def ticketsFor(r):
            return floor(totalOf(r)[0] / 400) + (r.get("m") or {}).get("tickets", 0)
        self.ticketsWon = len(self.won) * 5 + (ticketsFor(self.duel[1]) + ticketsFor(self.duel[2]) if self.duel else ticketsFor(d))
        S.tickets = (S.tickets or 0) + self.ticketsWon
        S.save()
        self.ticketShown = 0
        self.ticketAcc = 0.0
        self.toy = self.won[0] if (not self.tourDone and self.won) else None
        self.grand = bool(self.toy and P.ITEMS[self.toy].get("grand"))
        self.revealed = 0
        self.shown = 0.0
        self.prizeY = -260.0
        self.prizeV = 0.0
        self.landed = False
        self.musicBack = False
        A.play_fanfare()
        mode = d["mode"]
        againLabel, again = T("play_again"), (lambda: Game.playStand(mode))
        if tour and not self.tourDone:
            def nxt():
                tour["idx"] += 1
                Game.switch("play", tour["list"][tour["idx"] - 1])
            againLabel, again = T("next_stand"), nxt
        elif tour:
            againLabel, again = T("new_tour"), Game.startTour

        def to_menu():
            Game.tour = None
            Game.switch("menu")
        self.buttons = [
            Button(360, 548, 260, 70, againLabel, G.F["sign34"], G.C["green"], onShoot=again),
            Button(660, 548, 260, 70, T("menu"), G.F["sign34"], G.C["red"], onShoot=to_menu),
        ]

    def update(self, dt):
        self.t += dt
        for b in self.buttons:
            b.update(dt)
        want = min(6, floor(self.t / 0.35))
        if want > self.revealed:
            self.revealed = want
            A.play("blip", 0.6, 1 + want * 0.06)
        if self.revealed >= 6:
            self.shown = min(self.total, self.shown + max(1, self.total) * dt * 1.2)
            if self.ticketShown < self.ticketsWon:
                self.ticketAcc += dt * max(8, self.ticketsWon / 2)
                while self.ticketAcc >= 1 and self.ticketShown < self.ticketsWon:
                    self.ticketAcc -= 1
                    self.ticketShown += 1
                    if self.ticketShown % 2 == 1:
                        A.play("ticket", 0.35, 1.2)
        if self.t > 2.1:
            self.prizeV += 2200 * dt
            self.prizeY += self.prizeV * dt
            land = 400 if self.tourDone else 355
            if self.prizeY > land:
                self.prizeY = land
                if abs(self.prizeV) > 150:
                    if not self.landed:
                        self.landed = True
                        A.play("gold", 0.9)
                        A.play("thud", 0.8)
                        G.FX.burst(940, 340, 160 if self.grand else 60, None, 800 if self.grand else 520)
                        G.FX.addShake(14 if self.grand else 8)
                        if self.toy:
                            A.play("squeak", 0.9, 1.1)
                        if self.grand:
                            A.play("bell", 1)
                    self.prizeV = -self.prizeV * 0.35
                else:
                    self.prizeV = 0
        if self.landed and random.random() < dt * 4:
            G.FX.burst(random.randint(200, 1080), 150, 8, None, 200)
        if self.landed and not self.musicBack and self.t > 5:
            self.musicBack = True
            A.music("menu")

    def draw(self):
        d = self.d
        G.wall((0.12, 0.35, 0.4), "diamond")
        G.boothFront(T("results"), G.T)
        lg.set_color(0.12, 0.05, 0.06, 0.9); lg.rectangle("fill", 130, 170, 560, 360, 16)
        G.col(G.C["gold"]); lg.set_line_width(4); lg.rectangle("line", 130, 170, 560, 360, 16)
        G.text(T("name_" + d["mode"]), 410, 180, G.F["sign34"], G.C["yellow"], 540, 3)
        G.text(T("level_line", T("diff_" + S.difficulty)), 410, 212, G.F["ui14"], G.C["pink"], 540, 1)
        lines = [
            (T("r_score"), str(d["score"])),
            (T("r_hits"), "%d / %d" % (d["hits"], d["shots"])),
            (T("r_acc"), "%d%%" % floor(self.acc * 100 + 0.5)),
            (T("r_combo"), str(d["bestCombo"])),
            (T("r_bonus"), "+%d" % self.bonus),
        ]
        if self.duel:
            for p in (1, 2):
                r = self.duel[p]
                x = 290 if p == 1 else 530
                win = self.winner == p
                if self.revealed >= p:
                    G.text(T("p%d" % p), x, 236, G.F["sign26"], G.C["yellow"] if win else G.C["cream"], 220, 2)
                    G.text(str(r["score"]), x, 262, G.F["ui34"], G.C["white"], 220, 2)
                    G.text(T("r_acc") + " %d%%" % floor(self.duelTotals[p][1] * 100 + 0.5), x, 306, G.F["ui16"], G.C["cream"], 220, 1)
                    G.text(T("r_total") + ": %d" % self.duelTotals[p][0], x, 332, G.F["ui26"], G.C["yellow"] if win else G.C["cream"], 220, 2)
                    if win:
                        G.star(x, 384, 22, G.C["gold"], G.T)
            if self.revealed >= 3:
                msg = T("draw_game") if self.winner == 0 else T("wins", T("p%d" % self.winner))
                s = 1 + 0.06 * sin(G.T * 5)
                lg.push(); lg.translate(410, 450); lg.scale(s, s)
                G.text(msg, 0, -26, G.F["sign46"], G.C["yellow"], 520, 3)
                lg.pop()
            lines = []
        f26 = G.F["ui26"]
        for i, l in enumerate(lines):
            if self.revealed >= i + 1:
                y = 238 + i * 38
                G.text(l[0], 160, y, f26, G.C["cream"], None, 2)
                G.text(l[1], 660 - f26.getWidth(l[1]), y, f26, G.C["white"], None, 2)
        if self.revealed >= 6 and not self.duel:
            G.col(G.C["gold"]); lg.rectangle("fill", 160, 432, 500, 3)
            G.text(T("r_total"), 160, 446, G.F["ui46"], G.C["yellow"], None, 3)
            s = str(int(floor(self.shown + 0.5)))
            G.text(s, 660 - G.F["ui46"].getWidth(s), 446, G.F["ui46"], G.C["yellow"], None, 3)
        if self.tourDone:
            G.text(T("you_win") if self.landed else T("prize_is"), 940, 170, G.F["sign34"], G.C["cream"], 460, 3)
            if self.landed:
                G.text(T("prize_%d" % self.tier) + "!", 940, 206, G.F["sign34"], G.C["yellow"], 480, 3)
            P.drawPrize(self.tier, 940, self.prizeY, 0.8 + self.tier * 0.05)
        else:
            if self.toy:
                G.text(T("for_daughter") if self.landed else T("prize_is"), 940, 168, G.F["sign34"], G.C["cream"], 460, 3)
                if self.landed:
                    tierName = T("tier_grand") if self.grand else T("tier_%d" % P.ITEMS[self.toy]["tier"])
                    G.text(T(self.toy) + "!", 940, 204, G.F["sign34"], G.C["gold"] if self.grand else G.C["yellow"], 470, 3)
                    extra = ("   " + T("more_won", len(self.won) - 1)) if len(self.won) > 1 else ""
                    G.text(tierName + extra, 940, 242, G.F["ui16"], G.C["gold"] if self.grand else G.C["pink"], 470, 2)
                P.draw(self.toy, 940, self.prizeY, 165, False, 0, True)
            else:
                G.text(T("no_new"), 940, 168, G.F["ui26"], G.C["cream"], 460, 2)
                G.text(T("try_challenge"), 940, 204, G.F["ui20"], G.C["yellow"], 460, 2)
                P.drawPrize(0, 940, self.prizeY, 0.55)
            newSet = set(self.won)
            for t in range(1, 6):
                id_ = "%s%d" % (d["mode"], t)
                y = 432 + (t - 1) * 22
                x = 740
                ch = T("ch_" + id_)
                if id_ in newSet:
                    G.star(x, y + 10, 10, G.C["yellow"], G.T * 3)
                    txt = T("ch_new") + " " + ch
                    G.text(txt, x + 16, y, G.fit(txt, G.F["ui16"], 410), G.C["yellow"], None, 1)
                elif C.has(id_):
                    G.star(x, y + 10, 9, G.C["green"], 0)
                    G.text(ch, x + 16, y, G.fit(ch, G.F["ui16"], 410), (0.7, 0.95, 0.7), None, 1)
                else:
                    lg.set_color(0, 0, 0, 0.4); lg.circle("fill", x, y + 10, 7)
                    G.text(ch, x + 16, y, G.fit(ch, G.F["ui16"], 410), (0.85, 0.85, 0.9), None, 1)
        if self.t > 2.6:
            for b in self.buttons:
                b.draw(Game.aim[0], Game.aim[1])
        G.counter()
        if self.ticketsWon > 0 and self.revealed >= 6:
            n = min(self.ticketShown, 14)
            lg.set_line_width(1)
            for i in range(1, n + 1):
                x = 1170 - (i - 1) * 9
                lg.set_color(1, 0.55, 0.2); lg.rectangle("fill", x - 18, 600 + i * 1.5, 36, 20, 2)
                lg.set_color(0.7, 0.3, 0.1); lg.rectangle("line", x - 15, 603 + i * 1.5, 30, 14)
            lg.set_color(0.2, 0.2, 0.22); lg.rectangle("fill", 1130, 612, 70, 10, 3)
            G.text(T("tickets_won", self.ticketShown), 1090, 672, G.F["ui20"], G.C["orange"], 220, 2)
        if self.tour:
            tt = self.tour
            line = T("tour_total", tt["total"]) if self.tourDone else T("tour_progress", tt["idx"], len(tt["list"]), tt["total"])
            G.text(line, 560, 640, G.F["ui26"], G.C["yellow"], 880, 3)
            if self.landed and self.newBest and (G.T * 3) % 1 < 0.65:
                G.text(T("new_tour_best"), 560, 678, G.F["ui26"], G.C["pink"], 880, 3)
        elif self.landed and self.newBest:
            if (G.T * 3) % 1 < 0.65:
                G.text(T("new_best"), 560, 652, G.F["ui34"], G.C["pink"], 880, 3)
        else:
            G.text(T("every_player"), 560, 662, G.F["ui20"], G.C["cream"], 880, 2)

    def shoot(self, x, y, off):
        if off:
            return
        A.play("shot", 0.7)
        G.FX.mark(x, y)
        if self.t > 2.6:
            for b in self.buttons:
                if b.shoot(x, y):
                    return
        else:
            self.t = 2.6
            self.revealed = 6
            self.shown = self.total

    def back(self):
        Game.tour = None
        Game.switch("menu")
