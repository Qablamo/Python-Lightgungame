"""Your prizes: every toy you have won (2 pages of 4 stands)."""
import math
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from .. import challenges as C
from .. import prizes as P
from ..ui import Button
from ..lang import T

X0, CW = 312, 172
Y0, RH = 146, 118


def cellPos(r, t):
    plank = Y0 + (r - 1) * RH + 104
    return X0 + (t - 0.5) * CW, plank


class Shelf:
    page = 1

    def pageModes(self):
        return C.MODES[(self.page - 1) * 4:(self.page - 1) * 4 + 4]

    def enter(self):
        A.music("menu")
        self.wob = {}

        def flip():
            self.page = 3 - self.page
            A.play("swish", 0.6)
            self.buttons[1].label = ">" if self.page == 1 else "<"
        self.buttons = [
            Button(92, 640, 116, 62, T("back"), G.F["sign22"], G.C["red"], onShoot=lambda: Game.switch("menu")),
            Button(214, 640, 92, 62, ">" if self.page == 1 else "<", G.F["sign34"], G.C["blue"], onShoot=flip),
            Button(752, 640, 160, 62, T("counter"), G.F["sign22"], G.C["orange"], onShoot=lambda: Game.switch("counter")),
            Button(918, 640, 136, 62, T("room"), G.F["sign22"], G.C["pink"], onShoot=lambda: Game.switch("room")),
            Button(1060, 640, 136, 62, T("album"), G.F["sign22"], G.C["purple"], onShoot=lambda: Game.switch("album")),
        ]

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)
        for id_ in list(self.wob):
            self.wob[id_] -= dt * 1.5
            if self.wob[id_] <= 0:
                del self.wob[id_]

    def cellAt(self, x, y):
        for r, mode in enumerate(self.pageModes(), 1):
            for t in range(1, 6):
                cx, plank = cellPos(r, t)
                if abs(x - cx) < CW / 2 and plank - RH + 8 < y < plank + 6:
                    return mode, t
        return None, None

    def draw(self):
        G.blit_cached("shelf_bg", self._paint_bg)
        G.boothFront(T("shelf"), G.T)
        hm, ht = self.cellAt(Game.aim[0], Game.aim[1])
        for r, mode in enumerate(self.pageModes(), 1):
            _, plank = cellPos(r, 1)
            G.text(T("name_" + mode), 200, plank - 74, G.F["sign22"], G.C["cream"], 210, 2)
            G.text("%d / 5" % C.count(mode), 200, plank - 42, G.F["ui20"], G.C["yellow"], 210, 2)
            lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", X0 - 4, plank + 4, CW * 5 + 8, 10)
            lg.set_color(0.72, 0.5, 0.3); lg.rectangle("fill", X0 - 6, plank - 2, CW * 5 + 12, 10, 3)
            lg.set_color(0.85, 0.65, 0.42); lg.rectangle("fill", X0 - 6, plank - 2, CW * 5 + 12, 3)
            for t in range(1, 6):
                id_ = "%s%d" % (mode, t)
                cx, _ = cellPos(r, t)
                got = C.has(id_)
                if hm == mode and ht == t:
                    lg.set_color(1, 1, 1, 0.12); lg.rectangle("fill", cx - CW / 2 + 4, plank - RH + 10, CW - 8, RH - 10, 8)
                if P.ITEMS[id_].get("grand"):
                    G.col(G.C["gold"], 0.5 + 0.3 * math.sin(G.T * 3)); lg.set_line_width(3)
                    lg.rectangle("line", cx - CW / 2 + 6, plank - RH + 12, CW - 12, RH - 14, 10)
                w = self.wob.get(id_, 0)
                P.drawOn(id_, cx, plank - 1, 100, not got, math.sin(w * 20) * w * 0.3, True)
        G.counter()
        for b in self.buttons:
            b.draw(Game.aim[0], Game.aim[1])
        ix, iw = 528, 430
        if hm:
            id_ = "%s%d" % (hm, ht)
            got = C.has(id_)
            tier = T("tier_grand") if P.ITEMS[id_].get("grand") else T("tier_%d" % ht)
            G.text(tier + ":  " + (T(id_) if got else "?????"), ix, 640, G.F["ui20"], G.C["yellow"] if got else G.C["cream"], iw, 2)
            line = (T("shelf_got") + "  " + T("ch_" + id_)) if got else T("shelf_locked", T("ch_" + id_))
            G.text(line, ix, 672, G.F["ui16"], G.C["green"] if got else G.C["cream"], iw, 2)
        else:
            G.text(T("shelf_sub"), ix, 640, G.F["ui20"], G.C["pink"], iw, 2)
            G.text(T("shelf_count", C.count()) + "  -  " + T("tickets", S.tickets) + "  -  " + T("page", self.page, 2),
                   ix, 672, G.F["ui16"], G.C["cream"], iw, 2)

    @staticmethod
    def _paint_bg():
        lg.set_color(0.42, 0.2, 0.32); lg.rectangle("fill", 0, 0, G.W, G.H)
        for i in range(23):
            lg.set_color(0.46 + (i % 2) * 0.03, 0.22, 0.35)
            lg.rectangle("fill", 80 + i * 52, 140, 50, 500)

    def shoot(self, x, y, off):
        if off:
            A.play("reload", 0.7)
            return
        A.play("shot", 0.7)
        for b in self.buttons:
            if b.shoot(x, y):
                return
        mode, t = self.cellAt(x, y)
        if mode:
            id_ = "%s%d" % (mode, t)
            if C.has(id_):
                self.wob[id_] = 1.0
                A.play("squeak", 0.8, 0.8 + t * 0.1)
                G.FX.burst(x, y, 10, [G.C["pink"], G.C["white"], G.C["yellow"]], 200, "star")
            else:
                A.play("tick", 0.6)
        else:
            G.FX.mark(x, y)

    def back(self):
        Game.switch("menu")
