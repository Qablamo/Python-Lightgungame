"""The shooting round: ammo / pump action, scoring, combos, intro, 2-player turns and the attract demo."""
import math
import random
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from .. import challenges as C
from .. import prizes as Toys
from ..ui import Button
from ..lang import T
from ..modes import registry

floor, sin = math.floor, math.sin
INF = float("inf")


def quit_demo():
    Game.demo = None
    Game.switch("menu")


def cork(x, y, full):
    if full:
        lg.set_color(0.85, 0.65, 0.4); lg.rectangle("fill", x - 7, y - 14, 14, 24, 4)
        lg.set_color(0.65, 0.45, 0.25); lg.rectangle("fill", x - 7, y - 14, 14, 6, 3)
        lg.set_color(1, 1, 1, 0.3); lg.rectangle("fill", x - 5, y - 6, 3, 14)
    else:
        lg.set_line_width(1)
        lg.set_color(0.3, 0.2, 0.12, 0.6); lg.rectangle("line", x - 7, y - 14, 14, 24, 4)


def shotFX(x, y):
    Game.flash = 0.08
    G.FX.shot(x, y)


class Play:
    mode = None
    ownsShotFX = True

    def enter(self, modeId):
        self.def_ = registry.find(modeId)
        self.mode = registry.module(self.def_["id"]).new()
        self.demo = Game.demo is not None
        self.kids = G.kids and not self.demo
        self.duel = Game.duel if not self.demo else None
        self.score = self.shots = self.hits = self.combo = self.bestCombo = 0
        self.misses = self.penalties = 0
        self.time = getattr(self.mode, "time", None) or 60
        self.mag = getattr(self.mode, "mag", None) or 8
        total = getattr(self.mode, "totalShots", None)
        if Game.tour:
            self.time = min(self.time, 40)
            if total:
                total = 25
        if self.kids:
            self.time = floor(self.time * 1.5)
            if total:
                total = floor(total * 1.5)
        if self.demo:
            self.time = 16
        self.pump = (S.reload == "pump") and not self.demo
        if self.pump:
            self.mag = 1
        self.limited = total is not None
        self.ammo = min(self.mag, total if total is not None else self.mag)
        self.reserve = (total - self.ammo) if total is not None else INF
        self.reloading, self.reloadLen = 0.0, 0.55
        self.autoDelay = 0.0
        self.kick = self.pumpAnim = self.pumpNag = 0.0
        if self.demo:
            self.phase, self.timer = "intro", 1.2
        elif self.duel:
            self.phase, self.timer = "ready", 0.0
        else:
            self.phase, self.timer = "intro", 4.4
        self.lastCount = 4
        self.lastSec = None
        self.paused = False
        self.overText = ""
        self.scoreShown = 0.0
        self.multPulse = 0.0
        self.demoT = 1.0
        G.FX.clear()
        A.music("game")
        if not self.demo:
            A.play("whistle", 0.6)

        def resume():
            self.paused = False

        def to_menu():
            Game.tour = None
            Game.duel = None
            Game.switch("menu")
        self.pauseButtons = [
            Button(400, 340, 220, 80, T("resume"), None, G.C["green"], onShoot=resume),
            Button(660, 340, 220, 80, T("menu"), None, G.C["red"], onShoot=to_menu),
        ]

    def leave(self):
        if self.mode is not None and hasattr(self.mode, "destroy"):
            self.mode.destroy()

    def multiplier(self):
        return min(5, 1 + self.combo // 4)

    def startReload(self):
        if self.reloading > 0 or self.ammo >= self.mag or self.reserve <= 0:
            return
        if self.pump:
            self.reloadLen = 0.28
            self.pumpAnim = 1.0
            A.play("pump", 1)
        else:
            self.reloadLen = 0.55
            A.play("reload", 0.9)
        self.reloading = self.reloadLen

    def reload(self):
        if self.demo:
            return quit_demo()
        if self.paused or self.phase != "play":
            return
        self.startReload()

    def finishRound(self):
        data = {"mode": self.def_["id"], "score": self.score, "shots": self.shots, "hits": self.hits,
                "bestCombo": self.bestCombo, "misses": self.misses, "penalties": self.penalties,
                "m": dict(getattr(self.mode, "stats", None) or {}), "kids": self.kids}
        if self.demo:
            Game.nextDemo()
        elif self.duel and self.duel["round"] == 1:
            self.duel["res"][1] = data
            self.duel["round"] = 2
            Game.switch("play", self.def_["id"])
        elif self.duel:
            self.duel["res"][2] = data
            d = self.duel
            Game.duel = None
            Game.switch("results", {"mode": self.def_["id"], "duel": d["res"], "score": 0, "shots": 0, "hits": 0,
                                    "bestCombo": 0, "misses": 0, "penalties": 0, "m": {}, "kids": self.kids})
        else:
            Game.switch("results", data)

    def update(self, dt):
        if self.paused:
            for b in self.pauseButtons:
                b.update(dt)
            return
        self.multPulse = max(0.0, self.multPulse - dt * 3)
        self.kick = max(0.0, self.kick - dt * 6)
        self.pumpAnim = max(0.0, self.pumpAnim - dt / 0.28)
        self.scoreShown += (self.score - self.scoreShown) * min(1, dt * 12)
        self.mode.update(dt * 0.7 if self.kids else dt, self.phase == "play")
        bonus = getattr(self.mode, "bonus", None)
        if bonus:
            for b in bonus:
                self.score += b["pts"]
                G.FX.popup(b.get("label") or ("+%d" % b["pts"]), b.get("x", G.W / 2), b.get("y", 300), G.C["yellow"], True)
            self.mode.bonus = None

        if self.phase == "ready":
            return
        elif self.phase == "intro":
            self.timer -= dt
            c = floor(self.timer) + 1
            if c < self.lastCount and 1 <= c <= 3 and not self.demo:
                A.play("tick", 0.9)
                self.lastCount = c
            if self.timer <= 0:
                self.phase = "play"
                if not self.demo:
                    A.play("bell", 0.8)
                    G.FX.popup(T("go"), G.W / 2, 380, G.C["white"], True)
        elif self.phase == "play":
            self.time -= dt
            sec = floor(self.time)
            if self.time < 5 and sec != self.lastSec and not self.demo:
                self.lastSec = sec
                A.play("tick", 0.7, 1.3)
            if self.reloading > 0:
                self.reloading -= dt
                if self.reloading <= 0:
                    self.reloading = 0
                    take = min(self.mag - self.ammo, self.reserve)
                    self.ammo += int(take)
                    self.reserve -= take
            elif self.ammo == 0 and self.reserve > 0 and (S.reload == "auto" or self.demo) and not self.pump:
                self.autoDelay += dt
                if self.autoDelay > 0.2:
                    self.autoDelay = 0
                    self.startReload()
            self.pumpNag = max(0.0, self.pumpNag - dt)
            if self.demo:
                self.demoT -= dt
                if self.demoT <= 0:
                    self.demoT = 0.4 + random.random() * 0.35
                    x, y = 640, 360
                    if hasattr(self.mode, "demoTarget"):
                        t = self.mode.demoTarget()
                        if t:
                            x, y = t
                    x += (random.random() - 0.5) * 8
                    y += (random.random() - 0.5) * 8
                    Game.aim[0], Game.aim[1] = x, y
                    self.fire(x, y)
            outOfShots = self.limited and self.ammo == 0 and self.reserve == 0 and self.reloading == 0
            finished = getattr(self.mode, "finished", False)
            if self.time <= 0 or outOfShots or finished:
                self.time = max(0, self.time)
                self.phase = "over"
                self.timer = 1.2 if self.demo else 2.6
                if finished:
                    self.overText = getattr(self.mode, "finishText", None) or T("all_clear")
                else:
                    self.overText = T("out_of_shots") if outOfShots else T("times_up")
                if not self.demo:
                    A.play("buzzer", 0.7)
                    A.music(None)
        elif self.phase == "over":
            self.timer -= dt
            if self.timer <= 0:
                self.finishRound()

    def award(self, res, x, y):
        if res.get("penalty"):
            self.penalties += 1
            self.score = max(0, self.score + res["pts"])
            self.combo = 0
            G.FX.popup(str(res["pts"]), x, y, G.C["red"], True)
            if res.get("label"):
                G.FX.popup(res["label"], x, y - 50, G.C["red"], False)
            return
        self.hits += 1
        before = self.multiplier()
        self.combo += 1
        self.bestCombo = max(self.bestCombo, self.combo)
        mult = self.multiplier()
        pts = floor(res["pts"] * mult)
        self.score += pts
        G.FX.popup("+%d" % pts, x, y, res.get("color") or G.C["yellow"], res.get("big", False))
        if res.get("label"):
            G.FX.popup(res["label"], x, y - 46, G.C["cream"], False)
        if mult > before:
            self.multPulse = 1.0
            A.play("combo", 0.8)
            G.FX.pops = [p for p in G.FX.pops if not p.get("combo")]
            p = G.FX.popup(T("combo", mult), G.W / 2, 560, G.C["orange"], True)
            p["combo"] = True

    def fire(self, x, y):
        if self.reloading > 0:
            A.play("empty", 0.8)
            return
        if self.ammo <= 0:
            A.play("empty", 0.9)
            if self.pump:
                self.pumpNag = 1.0
            elif S.reload == "auto":
                self.startReload()
            return
        self.ammo -= 1
        self.shots += 1
        shotFX(x, y)
        self.kick = 1.0
        A.play("shot", 0.75, 0.95 + random.random() * 0.1)
        G.FX.burst(x, y, 4, None, 60, "dust", -40)
        res = self.mode.shoot(x, y)
        if res:
            self.award(res, res.get("x", x), res.get("y", y))
        else:
            G.FX.mark(x, y)
            self.misses += 1
            if self.combo >= 4:
                G.FX.popup(T("combo_lost"), x, y, (0.8, 0.8, 0.8))
            self.combo = 0

    def shoot(self, x, y, off):
        if self.demo:
            return quit_demo()
        if self.paused:
            if not off:
                shotFX(x, y)
            for b in self.pauseButtons:
                if b.shoot(x, y):
                    return
            return
        if self.phase == "ready":
            if not off:
                shotFX(x, y)
            self.phase, self.timer = "intro", 4.4
            A.play("bell", 0.6)
            return
        if self.phase != "play":
            return
        if off:
            self.startReload()
            return
        self.fire(x, y)

    def back(self):
        if self.demo:
            return quit_demo()
        if self.phase == "over":
            return
        self.paused = not self.paused
        A.play("blip", 0.6)

    # ------------------------------------------------------------------
    def drawRifle(self, x, y):
        k = self.kick
        p = self.pumpAnim
        slide = (1 - p) * 2 if p > 0.5 else p * 2
        lg.push()
        lg.translate(x - k * 14, y - k * 4)
        lg.rotate(-k * 0.06)
        lg.set_color(0.45, 0.26, 0.12)
        lg.polygon("fill", 0, 6, 70, 0, 92, 4, 92, 22, 70, 18, 0, 34)
        lg.set_color(0.6, 0.38, 0.2); lg.polygon("fill", 4, 10, 66, 4, 66, 10, 4, 16)
        lg.set_color(0.25, 0.25, 0.28); lg.rectangle("fill", 90, 0, 60, 18, 3)
        lg.set_color(0.35, 0.35, 0.4); lg.rectangle("fill", 148, 4, 160, 8)
        lg.set_color(0.6, 0.6, 0.65); lg.rectangle("fill", 148, 4, 160, 2)
        lg.set_color(0.2, 0.2, 0.22); lg.rectangle("fill", 300, 1, 10, 14, 2)
        sx = 190 - slide * 34
        lg.set_color(0.5, 0.3, 0.15); lg.rectangle("fill", sx, 13, 70, 14, 5)
        lg.set_color(0.35, 0.2, 0.1)
        for i in range(6):
            lg.rectangle("fill", sx + 8 + i * 10, 15, 3, 10)
        if self.ammo > 0 and self.reloading <= 0:
            lg.set_color(0.85, 0.65, 0.4); lg.circle("fill", 312, 8, 6)
        lg.pop()

    def drawHUD(self):
        x0 = 110
        if self.pump:
            self.drawRifle(x0 + 20, 652)
            nag = self.ammo == 0 and self.reloading <= 0 and self.phase == "play"
            if nag and ((G.T * 3) % 1 < 0.6 or self.pumpNag > 0):
                s = 1 + self.pumpNag * 0.4
                lg.push(); lg.translate(x0 + 175, 646); lg.scale(s, s)
                G.text(T("pump"), 0, -14, G.F["ui26"], G.C["red"], 200, 3)
                lg.pop()
            if self.limited:
                G.text(T("shots_left", int(self.ammo + self.reserve)), x0 - 10, 690, G.F["ui16"], G.C["yellow"], None, 2)
        else:
            G.text(T("ammo"), x0 - 10, 640, G.F["ui16"], G.C["cream"], None, 2)
            for i in range(self.mag):
                cork(x0 + 70 + i * 22, 662, i < self.ammo)
            if self.limited:
                G.text(T("shots_left", int(self.ammo + self.reserve)), x0 - 10, 684, G.F["ui20"], G.C["yellow"], None, 2)
            if self.reloading > 0:
                G.text(T("reloading"), x0 + 175, 684, G.F["ui20"], G.C["cream"], None, 2)
            elif self.ammo == 0 and self.reserve > 0 and self.phase == "play" and (G.T * 3) % 1 < 0.6:
                G.text(T("reload_now"), x0 + 175, 684, G.F["ui20"], G.C["red"], None, 2)
        px, pw = 480, 320
        G.col(G.C["darkred"]); lg.rectangle("fill", px, 638, pw, 74, 12)
        G.col(G.C["gold"]); lg.set_line_width(3); lg.rectangle("line", px, 638, pw, 74, 12)
        label = T("score")
        if self.duel:
            label = T("player_turn", self.duel["round"]) + "  -  " + label
        G.text(label, px + pw / 2, 640, G.F["ui16"], G.C["cream"], pw, 1)
        G.text(str(int(floor(self.scoreShown + 0.5))), px + pw / 2, 656, G.F["ui46"], G.C["yellow"], pw, 3)
        mult = self.multiplier()
        if mult > 1:
            s = 1 + self.multPulse * 0.6
            lg.push(); lg.translate(px + pw + 50, 675); lg.scale(s, s)
            G.text("x%d" % mult, 0, -26, G.F["ui46"], G.C["orange"], 120, 3)
            lg.pop()
        t = int(math.ceil(max(0, self.time)))
        tc = G.C["red"] if (t <= 10 and (G.T * 4) % 1 < 0.5) else G.C["cream"]
        G.text(T("time"), 1050, 640, G.F["ui16"], G.C["cream"], 200, 2)
        G.text("%d:%02d" % (t // 60, t % 60), 1050, 656, G.F["ui46"], tc, 200, 3)
        if self.kids:
            G.text(T("kids_on"), 1050, 618, G.F["ui16"], G.C["pink"], 200, 2)

    def drawChallenges(self, y0):
        lg.set_color(0.08, 0.04, 0.08, 0.85); lg.rectangle("fill", 330, y0, 620, 158, 12)
        G.col(G.C["gold"]); lg.set_line_width(2); lg.rectangle("line", 330, y0, 620, 158, 12)
        mid = self.def_["id"]
        for t in range(1, 6):
            id_ = "%s%d" % (mid, t)
            y = y0 + 6 + (t - 1) * 30
            got = C.has(id_)
            locked = self.kids and t > 2
            Toys.drawOn(id_, 360, y + 27, 34, not got, 0, True)
            txt = T("ch_" + id_) + "  >  " + T(id_)
            colr = (0.7, 0.95, 0.7) if got else ((0.55, 0.5, 0.6) if locked else G.C["cream"])
            G.text(txt, 386, y + 2, G.fit(txt, G.F["ui16"], 540), colr, None, 1)
            if got:
                G.star(928, y + 14, 9, G.C["green"], 0)

    def draw(self):
        m = self.mode
        m.draw()
        G.FX.drawMarks()
        if hasattr(m, "drawFront"):
            m.drawFront()
        G.boothFront(T("name_" + self.def_["id"]), G.T)
        G.counter()
        self.drawHUD()
        if hasattr(m, "drawOverlay"):
            m.drawOverlay()

        if self.demo:
            if (G.T * 1.5) % 1 < 0.7:
                lg.set_color(0, 0, 0, 0.55); lg.rectangle("fill", 200, 520, 880, 56, 12)
                G.text(T("demo"), G.W / 2, 530, G.F["sign34"], G.C["yellow"], 860, 3)
            return

        if self.phase == "ready":
            lg.set_color(0, 0, 0, 0.45); lg.rectangle("fill", 0, 0, G.W, G.H)
            r = self.duel["round"]
            s = 1 + 0.04 * sin(G.T * 4)
            lg.push(); lg.translate(G.W / 2, 300); lg.scale(s, s)
            G.sign(-330, -90, 660, 180, None, None, G.C["blue"] if r == 1 else G.C["red"], None, G.T)
            G.text(T("player_turn", r), 0, -78, G.F["sign96"], G.C["yellow"], 640, 4)
            G.text(T("shoot_to_start"), 0, 30, G.F["ui34"], G.C["cream"], 640, 3)
            lg.pop()
            if r == 2:
                G.text(T("hand_gun", 2), G.W / 2, 396, G.F["ui26"], G.C["pink"], 900, 3)
                G.text(T("p1") + ": %d" % self.duel["res"][1]["score"], G.W / 2, 428, G.F["ui26"], G.C["cream"], 900, 3)
            self.drawChallenges(468)
        elif self.phase == "intro":
            lg.set_color(0, 0, 0, 0.35); lg.rectangle("fill", 0, 0, G.W, G.H)
            G.sign(290, 220, 700, 220, None, None, self.def_["color"], None, G.T)
            G.text(T("name_" + self.def_["id"]), G.W / 2, 236, G.F["sign64"], G.C["cream"], 680, 4)
            G.text(T("rule_" + self.def_["id"]), G.W / 2, 322, G.F["ui26"], G.C["yellow"], 660, 2)
            if Game.tour:
                G.text(T("tour_stand", Game.tour["idx"], len(Game.tour["list"])), G.W / 2, 190, G.F["ui26"], G.C["cream"], 700, 3)
            elif self.duel:
                G.text(T("player_turn", self.duel["round"]), G.W / 2, 190, G.F["ui26"], G.C["cream"], 700, 3)
            if self.kids:
                G.text(T("kids_note"), G.W / 2, 447, G.F["ui14"], G.C["pink"], 900, 2)
            if self.pump:
                G.text(T("pump_hint"), G.W / 2, 158, G.F["ui20"], G.C["orange"], 900, 3)
            self.drawChallenges(468)
            c = int(math.ceil(self.timer))
            label = str(min(3, c)) if c >= 1 else T("go")
            k = self.timer % 1
            lg.push(); lg.translate(G.W / 2, 392); lg.scale(1 + k * 0.25, 1 + k * 0.25)
            G.text(label, 0, -48, G.F["ui96"], G.C["white"], 300, 4)
            lg.pop()
        elif self.phase == "over":
            lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", 0, 0, G.W, G.H)
            s = max(0.05, min(1, (2.6 - self.timer) * 4))
            lg.push(); lg.translate(G.W / 2, 330); lg.scale(s, s)
            G.sign(-330, -70, 660, 140, None, None, G.C["red"], None, G.T)
            G.text(self.overText, 0, -48, G.F["sign64"], G.C["yellow"], 640, 4)
            lg.pop()

        if self.paused:
            lg.set_color(0, 0, 0, 0.55); lg.rectangle("fill", 0, 0, G.W, G.H)
            G.text(T("paused"), G.W / 2, 220, G.F["sign96"], G.C["cream"], 600, 4)
            for b in self.pauseButtons:
                b.draw(Game.aim[0], Game.aim[1])
