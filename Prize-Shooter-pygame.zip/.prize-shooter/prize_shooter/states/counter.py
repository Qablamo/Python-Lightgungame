"""The prize counter: trade tickets for toys you haven't won yet (the Grand Prize must be won)."""
import math
from .. import gfx as G
from .. import lg
from .. import audio as A
from .. import settings as S
from .. import game as Game
from .. import challenges as C
from .. import prizes as P
from ..ui import Button
from ..lang import T

PRICES = [15, 30, 60, 120, 250]
COLS, ROWS = 6, 2
CX0, CY0, CWW, CHH = 100, 158, 180, 232


class Counter:
    page = 1

    def refresh(self):
        # Grand Prizes are never for sale: they have to be won
        self.items = ["%s%d" % (m, t) for t in range(1, 6) for m in C.MODES
                      if not C.has("%s%d" % (m, t)) and not P.ITEMS["%s%d" % (m, t)].get("grand")]
        self.pages = max(1, math.ceil(len(self.items) / (COLS * ROWS)))
        self.page = min(self.page, self.pages)

    def enter(self):
        A.music("menu")
        self.page = 1
        self.sel, self.selT = None, 0.0
        self.msg, self.msgT = None, 0.0
        self.jump = {}
        self.refresh()

        def prev():
            self.page = (self.page - 2) % self.pages + 1
            A.play("swish", 0.6)

        def nxt():
            self.page = self.page % self.pages + 1
            A.play("swish", 0.6)
        self.buttons = [
            Button(92, 640, 130, 62, T("back"), G.F["sign22"], G.C["red"], onShoot=lambda: Game.switch("shelf")),
            Button(230, 640, 70, 62, "<", G.F["sign34"], G.C["blue"], onShoot=prev),
            Button(306, 640, 70, 62, ">", G.F["sign34"], G.C["blue"], onShoot=nxt),
        ]

    def cell(self, i):
        k = i - (self.page - 1) * COLS * ROWS
        if k < 0 or k >= COLS * ROWS:
            return None, None
        c, r = k % COLS, k // COLS
        return CX0 + c * CWW, CY0 + r * CHH

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)
        self.selT = max(0.0, self.selT - dt)
        if self.selT <= 0:
            self.sel = None
        self.msgT = max(0.0, self.msgT - dt)
        for id_ in list(self.jump):
            self.jump[id_] -= dt
            if self.jump[id_] <= 0:
                del self.jump[id_]
                self.refresh()

    @staticmethod
    def _paint_bg():
        lg.set_color(0.35, 0.2, 0.12); lg.rectangle("fill", 0, 0, G.W, G.H)
        for i in range(13):
            lg.set_color(0.4 + (i % 2) * 0.03, 0.24, 0.14)
            lg.rectangle("fill", 80, 140 + i * 40, 1120, 38)

    def draw(self):
        G.blit_cached("counter_bg", self._paint_bg)
        G.boothFront(T("counter"), G.T)
        if not self.items:
            G.text(T("all_bought"), G.W / 2, 360, G.F["sign46"], G.C["yellow"], 900, 3)
        ax, ay = Game.aim
        for i, id_ in enumerate(self.items):
            x, y = self.cell(i)
            if x is None:
                continue
            it = P.ITEMS[id_]
            price = PRICES[it["tier"] - 1]
            afford = (S.tickets or 0) >= price
            hot = x < ax < x + CWW - 8 and y < ay < y + CHH - 10
            sel = self.sel == id_
            lg.set_color(0, 0, 0, 0.3); lg.rectangle("fill", x + 4, y + 6, CWW - 10, CHH - 12, 10)
            lg.set_color(0.98, 0.94, 0.85, 1 if sel else 0.92); lg.rectangle("fill", x, y, CWW - 10, CHH - 12, 10)
            if sel or hot:
                G.col(G.C["gold"] if sel else G.C["orange"]); lg.set_line_width(4)
                lg.rectangle("line", x, y, CWW - 10, CHH - 12, 10)
            j = self.jump.get(id_)
            jy = -abs(math.sin(j * 12)) * 30 if j else 0
            # like on the prize shelf, toys you haven't won stay a mystery ("?") until you buy them
            P.drawOn(id_, x + CWW / 2 - 5, y + 140 + jy, 120, not j, math.sin(G.T * 12) * 0.08 if sel else 0, True)
            G.text(T(id_) if j else T("tier_%d" % it["tier"]), x + CWW / 2 - 5, y + 148, G.F["ui14"], G.C["darkred"], CWW - 18, 0)
            if it.get("grand"):
                G.text(T("tier_grand"), x + CWW / 2 - 5, y + 178, G.F["ui16"], G.C["gold"], CWW - 18, 1)
            else:
                if afford:
                    lg.set_color(1, 0.55, 0.2)
                else:
                    lg.set_color(0.6, 0.5, 0.45)
                lg.rectangle("fill", x + 18, y + 176, CWW - 46, 30, 5)
                G.text(T("price", price), x + CWW / 2 - 5, y + 180, G.F["ui16"], G.C["white"], CWW - 50, 1)
            if j:
                G.text(T("bought"), x + CWW / 2 - 5, y + 60, G.F["sign26"], G.C["green"], CWW, 3)
        G.counter()
        for b in self.buttons:
            b.draw(ax, ay)
        lg.set_color(1, 0.55, 0.2); lg.rectangle("fill", 1000, 644, 190, 54, 6)
        G.text(T("tickets", S.tickets or 0), 1095, 657, G.F["ui20"], G.C["white"], 180, 2)
        if self.msgT > 0 and self.msg:
            msg = self.msg
        elif self.sel:
            msg = T("buy_confirm", PRICES[P.ITEMS[self.sel]["tier"] - 1])
        else:
            msg = T("counter_sub")
        G.text(msg, 690, 646, G.F["ui20"], G.C["cream"], 560, 2)
        G.text(T("page", self.page, self.pages), 690, 676, G.F["ui16"], G.C["yellow"], 560, 2)

    def shoot(self, x, y, off):
        if off:
            A.play("reload", 0.7)
            return
        A.play("shot", 0.7)
        for b in self.buttons:
            if b.shoot(x, y):
                return
        for i, id_ in enumerate(self.items):
            cx, cy = self.cell(i)
            if cx is not None and cx < x < cx + CWW - 10 and cy < y < cy + CHH - 12 and id_ not in self.jump:
                it = P.ITEMS[id_]
                if it.get("grand"):
                    self.msg, self.msgT = T("must_win"), 2.5
                    A.play("buzzer", 0.4, 1.5)
                    return
                price = PRICES[it["tier"] - 1]
                if (S.tickets or 0) < price:
                    self.msg, self.msgT = T("not_enough"), 2.0
                    A.play("empty", 0.9)
                    return
                if self.sel == id_:
                    S.tickets -= price
                    S.collect.add(id_)
                    S.save()
                    self.sel = None
                    self.jump[id_] = 1.4
                    A.play("register", 1)
                    A.play("squeak", 0.8, 1.1)
                    G.FX.burst(cx + CWW / 2, cy + 80, 50, None, 450, "star")
                else:
                    self.sel, self.selT = id_, 4.0
                    A.play("ding", 0.6)
                return
        G.FX.mark(x, y)

    def back(self):
        Game.switch("shelf")
